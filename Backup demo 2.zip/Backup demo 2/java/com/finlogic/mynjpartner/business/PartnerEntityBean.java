/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.mynjpartner.business;


public class PartnerEntityBean {
    String ddlstate;
    String ddlcity;

    public String getDdlstate() {
        return ddlstate;
    }
    public void setDdlstate(String ddlstate) {
        this.ddlstate = ddlstate;
    }

    public String getDdlcity() {
        return ddlcity;
    }

    public void setDdlcity(String ddlcity) {
        this.ddlcity = ddlcity;
    }

    @Override
    public String toString() {
        return "PartnerEntityBean{" + "ddlstate=" + ddlstate + ", ddlcity=" + ddlcity + '}';
    }
    
}
