
package com.finlogic.mynjpartner.business;

import com.finlogic.util.persistence.SQLUtility;
import java.sql.SQLException;
import java.util.List;


public class PartnerDataManager {
    private static final String CONNECTION_ALIAS = "njindiainvest_offline";
    
    public List getState() throws ClassNotFoundException, SQLException{
        
        SQLUtility sqlUtility = new SQLUtility();
        String sql = "select distinct state from demo_geolocation";
        List ls = sqlUtility.getList(CONNECTION_ALIAS, sql);
        return ls;
    }
    public List getCity(PartnerEntityBean entityBean) throws ClassNotFoundException, SQLException {
        SQLUtility sqlUtility = new SQLUtility();
        System.out.println("State is ....."+entityBean.getDdlstate());
        String sql = "select city from demo_geolocation where state = '"
                +entityBean.getDdlstate()+"';";
        List ls = sqlUtility.getList(CONNECTION_ALIAS, sql);
        System.out.println("City are%%%%%%%%%%%"+ls);
        return ls;
    }    
}

