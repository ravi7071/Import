package com.finlogic.mynjpartner.apps;

public class PartnerFormBean {
    String ddlstate;
    String ddlcity;
    String txtPName;

    public String getTxtPName() {
        return txtPName;
    }

    public void setTxtPName(String txtPName) {
        this.txtPName = txtPName;
    }
    public String getDdlstate() {
        return ddlstate;
    }

    public void setDdlstate(String ddlstate) {
        this.ddlstate = ddlstate;
    }

    public String getDdlcity() {
        return ddlcity;
    }

    public void setDdlcity(String ddlcity) {
        this.ddlcity = ddlcity;
    }

    @Override
    public String toString() {
        return "PartnerFormBean{" + "ddlstate=" + ddlstate + ", ddlcity=" + ddlcity + ", txtPName=" + txtPName + '}';
    }

    
    
}
