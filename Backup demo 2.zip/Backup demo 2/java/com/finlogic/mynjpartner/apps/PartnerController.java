
package com.finlogic.mynjpartner.apps;

import java.sql.SQLException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;


public class PartnerController extends MultiActionController{
    
    PartnerService service = new PartnerService();
    
    public ModelAndView getMenu(HttpServletRequest request,HttpServletResponse response){
        ModelAndView mv = new ModelAndView("Main");
        String finlibpath = finpack.FinPack.getProperty("finlib_path");
        mv.addObject("finlib_path", finlibpath);
        return mv;
    }
    public ModelAndView addMenu(HttpServletRequest request,HttpServletResponse response){
        ModelAndView mv = new ModelAndView("AddMenu");
        try {
            mv.addObject("statelist", service.getState());
        } catch (ClassNotFoundException | SQLException ex) {
            mv.addObject("exception", ex.getMessage());
        }        
        return mv;
    }
    public ModelAndView cityLoader(HttpServletRequest request,
            HttpServletResponse response, PartnerFormBean formBean) {
        ModelAndView modelAndView = new ModelAndView("AddMenu");

        modelAndView.addObject("process", "cityload");
        try {
            System.out.println("Bean is..."+formBean.toString());
            modelAndView.addObject("citylist", service.getCity(formBean));
        } catch (ClassNotFoundException | SQLException ex) {
            modelAndView.addObject("exception", ex.getMessage());
        }
        return modelAndView;
    }

}
