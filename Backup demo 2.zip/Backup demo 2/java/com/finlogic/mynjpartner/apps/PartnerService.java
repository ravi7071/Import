
package com.finlogic.mynjpartner.apps;

import com.finlogic.mynjpartner.business.PartnerDataManager;
import com.finlogic.mynjpartner.business.PartnerEntityBean;
import java.sql.SQLException;
import java.util.List;

public class PartnerService {
    PartnerDataManager dataManager = new PartnerDataManager();
    
    public List getState() throws ClassNotFoundException, SQLException {
        return dataManager.getState();
    }
    public List getCity(PartnerFormBean formBean) throws ClassNotFoundException, SQLException {
        System.out.println("Form bean...."+formBean);
        return dataManager.getCity(convertBean(formBean));
        
    }
    
    public PartnerEntityBean convertBean(PartnerFormBean formBean) {
        
        PartnerEntityBean partnerEntityBean = new PartnerEntityBean();
        partnerEntityBean.setDdlcity(formBean.getDdlcity());
        partnerEntityBean.setDdlstate(formBean.getDdlstate());
        
        return partnerEntityBean;
    }    
}
