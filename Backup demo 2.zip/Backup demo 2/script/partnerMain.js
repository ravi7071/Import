function AddPartner(){
    getSynchronousData('partner.fin?cmdAction=addMenu','','addPartner');
    loadDatePicker("dtdob"); 
}
function loadCity()
{
    var oform = document.getElementById("partnerForm");
    var params = getFormData(oform);
    getSynchronousData('partner.fin?cmdAction=cityLoader', params, 'ddlcity');
    loadComboNew('ddlcity');
}

