function AddPartner(){
    getSynchronousData('partner.fin?cmdAction=addMenu','','addPartner');
}


