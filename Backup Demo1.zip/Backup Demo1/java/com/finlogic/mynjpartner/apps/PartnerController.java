
package com.finlogic.mynjpartner.apps;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;


public class PartnerController extends MultiActionController{
    
    public ModelAndView getMenu(HttpServletRequest request,HttpServletResponse response){
        ModelAndView mv = new ModelAndView("Main");
        String finlibpath = finpack.FinPack.getProperty("finlib_path");
        mv.addObject("finlib_path", finlibpath);
        return mv;
    }
    public ModelAndView addMenu(HttpServletRequest request,HttpServletResponse response){
        ModelAndView mv = new ModelAndView("AddMenu");
        return mv;
    }
    
}
