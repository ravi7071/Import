/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.springwebstore.service;

import com.finlogic.springwebstore.beans.Product;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sohel1
 */
public class ProductServiceImpl implements ProductService {

    @Override
    public List<Product> getProducts() {
        ArrayList<Product> products = new ArrayList<>();

        products.add(new Product("Apple iPhone", 32300));
        products.add(new Product("Macbook Air", 180000));
        products.add(new Product("Macbook Pro", 220000));

        return products;
    }

}
