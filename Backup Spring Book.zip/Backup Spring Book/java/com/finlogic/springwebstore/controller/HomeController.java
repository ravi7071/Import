/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.springwebstore.controller;

import com.finlogic.springwebstore.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author sohel1
 */
@Controller
public class HomeController {

    @Autowired
    ProductService productService;
    
    @RequestMapping("/home.fin")
    public String welcome(Model model) {
        model.addAttribute("greetings", "Hello from Spring MVC!");
        model.addAttribute("products", productService.getProducts());
        return "index";
    }

}
