/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.pwithanno.apps;

import com.finlogic.pwithanno.beans.PartnerInfo;
import com.finlogic.pwithanno.service.PartnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MyPartnerController {

    private PartnerService partnerService;
    
    @Autowired
    public void setPartnerService(PartnerService partnerService) {
            this.partnerService = partnerService;
    }    
    
    @RequestMapping("/index.fin")
    public String showUserForm(ModelMap model) {
        String finlibpath = finpack.FinPack.getProperty("finlib_path");
        PartnerInfo partner = new PartnerInfo();
        model.addAttribute(partner);
        //System.out.println(".....");
        model.addAttribute("finlib_path", finlibpath);
        return "MyHomePage";
    } 

    @RequestMapping(value="/AddPartner.fin", method = RequestMethod.POST, params = "cmdAction=getMenu")
    public String redirect(Model model,PartnerInfo bean)
    {    
        System.out.println("Bean Value are..."+bean.toString());
        partnerService.add(bean);
        return "AddPartner";
    }    
    
    @RequestMapping(value="/AddPartner.fin", method = RequestMethod.POST, params = "cmdAction=insertPartner")
    public String onSubmit(Model model,PartnerInfo bean)
    {  
        //System.out.println("%%%%% Bean..."+bean.toString());
        this.partnerService.add(bean);
        System.out.println("$$$$$$ Partner..."+this.partnerService.get().toString());
        return "PartnerInsert";
    }    
    
}
