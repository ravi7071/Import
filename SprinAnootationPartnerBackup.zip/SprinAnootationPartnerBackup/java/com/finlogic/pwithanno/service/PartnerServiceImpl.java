
package com.finlogic.pwithanno.service;

import com.finlogic.pwithanno.beans.PartnerInfo;

public class PartnerServiceImpl implements PartnerService{

    PartnerInfo partner;
    @Override
    public void add(PartnerInfo partner) {
        this.partner = partner;
        System.out.println("Partner added successfully"+partner.getTxtPName());
    }
    public PartnerInfo get(){
        return this.partner;
    }
}
