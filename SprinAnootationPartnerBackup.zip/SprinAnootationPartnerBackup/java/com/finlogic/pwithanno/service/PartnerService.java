
package com.finlogic.pwithanno.service;

import com.finlogic.pwithanno.beans.PartnerInfo;

public interface PartnerService {
    public void add(PartnerInfo partner);
    public PartnerInfo get();
}
