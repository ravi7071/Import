function AddPartner(){
   //getSynchronousData('AddPartner.fin?cmdAction=getMenu','','loadPartner');
   var param = getFormData(document.partnerForm);
   loadAjaxComboData('AddPartner.fin?cmdAction=getMenu', 'loadPartner', param, false);
}

function loadAjaxComboData(url, divid, data, sync) {
    //showLoadingImg(divid);
    $.ajax({
        url: url,
        data: data,
        type: 'POST',
        async: sync,
        success: function (data) {
            //hideLoadingImg();
            if (data.indexOf("Welcome to eNPS") > 0)
            {
                window.location = '';
            } else
            {
                $("#" + divid).html(data);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            //hideLoadingImg();
        }
    });
}
function validate_data(){
    var param = getFormData(document.partnerForm);
    //getSynchronousData('AddPartner.fin?cmdAction=insertPartner','param','loadPartner'); 
    
    var formObj = $("#partnerForm").get(0);
    var formData = new FormData(formObj);
    loadAjaxComboData('AddPartner.fin?cmdAction=insertPartner', 'loadPartner', getalldatawithoutFile(formObj), false);

}

