var today = new Date();
var year = today.getFullYear() - 19;    // to get year before 18 year
year = "12-12-"+year;   // last date of year before 18 year
var mygrid;
function DhtmlshowReport(rptfor) 
{
    document.getElementById('basicReportDiv').style.display = "";
    if((rptfor=="delete" || rptfor=="utility") && document.getElementById('msgdelete')){
        document.getElementById('msgdelete').style.display = "none";
    }
    showDetailGridReports(rptfor);
    reArrangeColumns();
}
function reArrangeColumns()
{
    var col = document.getElementById("col_cmb1");
    var col2 = document.getElementById("col_cmb2");

    if (col2 !== null && col2.length > 0)
    {
        var val = "";
        for (var i = 0; i < col.length; i++)
        {
            val = col[i].value;
            mygrid.setColumnHidden(parseInt(val), true);
        }
    }
}

function showDetailGridReports(rptfor)
{
    var param = getFormData(document.partnerForm);
    mygrid = new dhtmlXGridObject('gridbox');
    mygrid.setImagesPath(getFinLibPath() + "dhtmlxSuite/dhtmlxGrid/codebase/imgs/");
    if(rptfor=="utility"){
        //Setting header for grid report if report is nedded foo utility module
        mygrid.setHeader("<b>Partner Name</b>,<b>Mobile</b>,<b>Email ID</b>,<b>Gender</b>,\n\
                   <b>PAN</b>,<b>State</b>,<b>City</b>,<b>NJ Center</b>,<b>Spouse Name</b>,\n\
                   <b>DOB</b>,<b>Pin Code</b>,<b>Existing HouseHold</b>,<b>Status</b>,<b>Edit</b>,\n\
                   <b>Delete</b>");
        mygrid.setInitWidths("180,80,180,50,100,90,150,80,80,80,80,40,80,70,80");
        mygrid.setColAlign("center,left,center,left,center,center,center,center,\n\
                            center,center,center,center,center,center,center");

        mygrid.setColSorting("na,na,na,na,na,na,na,na,na,na,na,na,na,na,na");
        mygrid.setColTypes("ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,link,link");
        mygrid.attachHeader(",#numeric_filter,,#select_filter,,#select_filter,,,,#select_filter,#select_filter,#select_filter,,,");
    }
    else{
        mygrid.setHeader("<b>Partner Name</b>,<b>Mobile</b>,<b>Email ID</b>,<b>Gender</b>,\n\
                   <b>PAN</b>,<b>State</b>,<b>City</b>,<b>NJ Center</b>,<b>Spouse Name</b>,\n\
                   <b>DOB</b>,<b>Pin Code</b>,<b>Existing HouseHold</b>,<b>Edit</b>,\n\
                   <b>Delete</b>");
        mygrid.setInitWidths("220,80,210,50,100,90,150,80,80,80,80,40,80,80");
        mygrid.setColAlign("center,left,center,left,center,center,center,center,\n\
                            center,center,center,center,center,center");

        mygrid.setColSorting("na,na,na,na,na,na,na,na,na,na,na,na,na,na");
        mygrid.setColTypes("ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,link,link");
        mygrid.attachHeader(",#numeric_filter,,#select_filter,,#select_filter,,,,#select_filter,#select_filter,#select_filter,,");
    }

    mygrid.enableAutoWidth(true);
    mygrid.enableAutoHeight(true);
    mygrid.enableMultiline(true);
    mygrid.setDateFormat("%D-%m-%y");
    
    mygrid.enableDragAndDrop(false);
    mygrid.enableColumnMove(true);
    mygrid.enableMultiselect(true);
    mygrid.enableColSpan(true);
    mygrid.setSkin("dhx_web");
    document.getElementById("pagingArea").innerHTML = "";
    document.getElementById("recinfoArea").innerHTML = "";
    mygrid.enablePaging(true, 10, 10, "pagingArea", true, "recinfoArea");
    mygrid.setPagingWTMode(true, true, true, [10, 20, 50]);
    mygrid.setPagingSkin("toolbar", "dhx_web");  
    mygrid.init();


    if (rptfor === "edit")
    {
        mygrid.setColumnHidden(13, true);//hiding delete column if report is of type edit
        mygrid.load('partner.fin?cmdAction=getfillGridReports&' + param, hideLoadingImg(), "json");
        console.log(mygrid);
    }
    if (rptfor === "utility")
    {
        mygrid.setColumnHidden(14, true);//hiding edit column if report is of type utility
        mygrid.load('partner.fin?cmdAction=getfillGridReports&utility=getPartner&' + param, hideLoadingImg(), "json");
        console.log(mygrid);
    }    
    if (rptfor === "delete")
    {
        mygrid.setColumnHidden(12, true);//hiding edit column if report is of type delete
        mygrid.load('partner.fin?cmdAction=getfillGridReports&' + param, hideLoadingImg(), "json");
    }
    if (rptfor === "view")
    {
        mygrid.setColumnHidden(12, true);//hiding edit
        mygrid.setColumnHidden(13, true);//hiding delete
        mygrid.load('partner.fin?cmdAction=getfillGridReportsView&viewtype=all&' + param, hideLoadingImg(), "json");
    }
    
}
function hideLoadingImg()
{
    
}
function onEdit(pan){
    document.getElementById('basicReportDiv').style.display = "none";
    getSynchronousData('partner.fin?cmdAction=editPartner&type=edit&txtppan=' + pan ,'', 'loadPartner');
    loadDatePicker("dtdob","73","","01-01-1945",year);//loadning date time from 1945
}
function onDelete(pan){
    getSynchronousData('partner.fin?cmdAction=editPartner&type=delete&txtppan=' + pan ,'', 'loadPartner');
    document.getElementById('basicReportDiv').style.display = "none";
}
function delete_data(){
    var pan = document.getElementById('txtPPAN').value;
    if (!confirm("Are you sure you want to delete Details?"))
    {
        return;
    }
    getSynchronousData('partner.fin?cmdAction=deletePartner&type=delete&pan='+pan,'', 'loadPartner');
}
//called for view partner
function getPartner(){
    if(document.getElementById('radiocenterwie').checked){
        //if centerwise radio button is checked
        showCenterWiseGridReports();
        reArrangeColumns();
    }
}
function onEditUtility(pan){
    //Edit partner status for utility
    getSynchronousData('partner.fin?cmdAction=viewPartnerStatus&pan='+pan,'', 'loadPartner');
    document.getElementById('basicReportDiv').style.display = "none";
}
function showCenterWiseGridReports(){
    //generating report for centerwise partner
    document.getElementById('basicReportDiv').style.display = "";
    var param = getFormData(document.partnerForm);
    mygrid = new dhtmlXGridObject('gridbox');
    mygrid.setImagesPath(getFinLibPath() + "dhtmlxSuite/dhtmlxGrid/codebase/imgs/");
    mygrid.setHeader("<b>Total Partner</b>,<b>State</b>,<b>Center</b>");
    mygrid.setInitWidths("100,250,250");
    mygrid.setColAlign("center,center,center");

    mygrid.setColSorting("na,na,na");
    mygrid.setColTypes("link,ro,ro");
    mygrid.enableAutoWidth(true);
    mygrid.enableAutoHeight(true);
    mygrid.enableMultiline(true);
    mygrid.enableDragAndDrop(false);
    mygrid.enableColumnMove(true);
    mygrid.enableMultiselect(true);
    mygrid.enableColSpan(true);
    mygrid.setSkin("dhx_web");
    document.getElementById("pagingArea").innerHTML = "";
    document.getElementById("recinfoArea").innerHTML = "";
    mygrid.enablePaging(true, 10, 10, "pagingArea", true, "recinfoArea");
    mygrid.setPagingWTMode(true, true, true, [10, 20, 50]);
    mygrid.setPagingSkin("toolbar", "dhx_web");  
    mygrid.init();
    mygrid.load('partner.fin?cmdAction=getfillGridReportsView&' + param, hideLoadingImg(), "json");
}
//When partner is selected from view
function onSelect(center){
    var param = getFormData(document.partnerForm);
    mygrid = new dhtmlXGridObject('gridbox');
    mygrid.setImagesPath(getFinLibPath() + "dhtmlxSuite/dhtmlxGrid/codebase/imgs/");
    mygrid.setHeader("<b>Partner Name</b>,<b>Mobile</b>,<b>Email ID</b>,<b>Gender</b>,\n\
               <b>PAN</b>,<b>State</b>,<b>City</b>,<b>NJ Center</b>,<b>Spouse Name</b>,\n\
               <b>DOB</b>,<b>Pin Code</b>,<b>Existing HouseHold</b>");
    mygrid.setInitWidths("220,80,210,50,100,90,150,80,80,80,80,40");
    mygrid.setColAlign("center,left,center,left,center,center,center,center,\n\
                        center,center,center,center");

    mygrid.setColSorting("na,na,na,na,na,na,na,na,na,na,na,na");
    mygrid.setColTypes("ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro");
    mygrid.enableAutoWidth(true);
    mygrid.enableAutoHeight(true);
    mygrid.enableMultiline(true);
    mygrid.setDateFormat("%D-%m-%y");
    //mygrid.attachHeader(",#numeric_filter,,#select_filter,,#select_filter,,,,#select_filter,#select_filter,#select_filter,,");
    mygrid.enableDragAndDrop(false);
    mygrid.enableColumnMove(true);
    mygrid.enableMultiselect(true);
    mygrid.enableColSpan(true);
    mygrid.setSkin("dhx_web");
    document.getElementById("pagingArea").innerHTML = "";
    document.getElementById("recinfoArea").innerHTML = "";
    mygrid.enablePaging(true, 10, 10, "pagingArea", true, "recinfoArea");
    mygrid.setPagingWTMode(true, true, true, [10, 20, 50]);
    mygrid.setPagingSkin("toolbar", "dhx_web");  
    mygrid.init();

    mygrid.load('partner.fin?cmdAction=getfillGridReportsView&center_id='+center+'&' + param, hideLoadingImg(), "json");
}
//Updating partner request status
function UpdatePartnerStatus(pan){
    var param = getFormData(document.partnerForm);
    getSynchronousData('partner.fin?cmdAction=changePartnerStatus&pan='+pan,param, 'loadPartner');
}