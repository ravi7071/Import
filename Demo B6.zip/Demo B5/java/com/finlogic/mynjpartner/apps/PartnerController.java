
package com.finlogic.mynjpartner.apps;

import com.finlogic.mynjpartner.reports.GenerateExcelReport;
import com.finlogic.mynjpartner.reports.GeneratePDFReport;
import com.finlogic.util.disposition.ContentDisposition;
import com.finlogic.util.disposition.ContentDispositionType;
import com.lowagie.text.DocumentException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;


public class PartnerController extends MultiActionController{
    
    PartnerService service = new PartnerService();
   
    public ModelAndView getMenu(HttpServletRequest request,HttpServletResponse response){
        ModelAndView mv = new ModelAndView("Main");
        String finlibpath = finpack.FinPack.getProperty("finlib_path");
        mv.addObject("finlib_path", finlibpath);
        System.out.println("Hererereere   11111");
        return mv;
    }
    public ModelAndView addMenu(HttpServletRequest request,HttpServletResponse response,PartnerFormBean formBean) throws ClassNotFoundException, SQLException{
        //loading module for adding new partner
        ModelAndView mv = new ModelAndView("AddMenu");
        mv.addObject("process", "stateLoad");
        try {
            mv.addObject("statelist", service.getState());
        } catch (ClassNotFoundException | SQLException ex) {
            mv.addObject("exception", ex.getMessage());
        }
        mv.addObject("cityprocess","nocity");
        mv.addObject("centerprocess", "nocenter");

        return mv;
    }
    public ModelAndView cityLoader(HttpServletRequest request,
            HttpServletResponse response, PartnerFormBean formBean) {
        //Loading City when state is changed
        ModelAndView modelAndView = new ModelAndView("AddMenu");
        modelAndView.addObject("ddlcity",request.getParameter("ddlcity"));
        modelAndView.addObject("cityprocess", "cityload");
        try {
            modelAndView.addObject("citylist", service.getCity(formBean));
        }catch (ClassNotFoundException | SQLException ex) {
            modelAndView.addObject("exception", ex.getMessage());
        }
        return modelAndView;
    }
    public ModelAndView centerLoader(HttpServletRequest request,
            HttpServletResponse response, PartnerFormBean formBean) {
        //Loading center when city is changed
        ModelAndView modelAndView = new ModelAndView("AddMenu");
        modelAndView.addObject("centerprocess", "centerload");
        try{
            modelAndView.addObject("centerlist", service.getCenter(formBean));
        }
        catch(Exception ex){
            System.out.println("ecc........"+ex);
        }
        return modelAndView;
    }
    public ModelAndView insertPartner(HttpServletRequest request,HttpServletResponse response,PartnerFormBean formBean){
        //Inserting partner data and returning status in message
        ModelAndView modelAndView = new ModelAndView("PartnerAdd");
        modelAndView.addObject("process","partnerAdded");
        try {
            modelAndView.addObject("msg", (service.insertPartner(formBean)).get("msg"));
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(PartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return modelAndView;
    }
    public ModelAndView editMenu(HttpServletRequest request,
        HttpServletResponse response, PartnerFormBean formBean) throws ClassNotFoundException, SQLException {
        //Loading edit menu
        ModelAndView modelAndView = new ModelAndView("EditPartner");
        modelAndView.addObject("process","loadPanNo");
        modelAndView.addObject("type", request.getParameter("type"));
        modelAndView.addObject("pannolist", service.getPan());
        return modelAndView;
    }
    public ModelAndView getfillGridReports(HttpServletRequest request,
            HttpServletResponse response, PartnerFormBean formBean
    ) throws ClassNotFoundException, SQLException {
        ModelAndView modelAndView;
        if(request.getParameter("utility")!=null && !request.getParameter("utility").equals("") && request.getParameter("utility").equals("getPartner")){
            //Loading grid data for utility and returning data
            modelAndView = new ModelAndView("EditPartner");
            modelAndView.addObject("process", "util");
            formBean.setTxtPin("utility");
            modelAndView.addObject("json", service.getGridData(formBean));
        }
        else{
            modelAndView = new ModelAndView("EditPartner");
            modelAndView.addObject("process", "view");
            modelAndView.addObject("json", service.getGridData(formBean));
        }
        return modelAndView;
    }
    public ModelAndView editPartner(HttpServletRequest request,
        HttpServletResponse response, PartnerFormBean formBean) throws ClassNotFoundException, SQLException {
        //for edit partner and loading partner details into form
        ModelAndView modelAndView = new ModelAndView("EditPartner");
        String txtPan = request.getParameter("txtppan");
        if (txtPan == null) {
            throw new IllegalArgumentException("PAN NOT FOUND IN REQUEST");
        }
        modelAndView.addObject("process","editPartner");
        modelAndView.addObject("type",request.getParameter("type"));
        formBean.setTxtPPAN(txtPan);
        Map partnerData = service.getPartnerData(formBean);
        modelAndView.addObject("statelist", service.getState());
        modelAndView.addObject("partner", partnerData);
        modelAndView.addObject("selectedState", (String) partnerData.get("state"));
        modelAndView.addObject("selectedCity", (String) partnerData.get("city"));
        modelAndView.addObject("selectedCenter", (String) partnerData.get("center_name"));
        modelAndView.addObject("selectedPan", txtPan);
        formBean.setDdlstate((String) partnerData.get("state"));
        modelAndView.addObject("citylist", service.getCity(formBean));
        formBean.setDdlcity((String) partnerData.get("city"));
        modelAndView.addObject("centerlist", service.getCenter(formBean));
        return modelAndView;
    } 
    public ModelAndView updatePartner(HttpServletRequest request,HttpServletResponse response,PartnerFormBean formBean){
        ModelAndView modelAndView = new ModelAndView("PartnerAdd");
        //When partner is updated
        modelAndView.addObject("process","partnerUpdated");
        try {
            modelAndView.addObject("msg", (service.updatePartner(formBean)).get("msg"));
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(PartnerController.class.getName()).log(Level.SEVERE, null, ex);
            modelAndView.addObject("msg","Sorry Partner not updated, For any "
                    + "queries call on Toll Free number 1800-2000-155");
        }
        return modelAndView;
    }
    public ModelAndView deletePartner(HttpServletRequest request,HttpServletResponse response,PartnerFormBean formBean){
        ModelAndView modelAndView = new ModelAndView("EditPartner");
        //When partner is deleted
        String pan = request.getParameter("pan");
        formBean.setTxtPPAN(pan);
        modelAndView.addObject("process", "loadPanNo");
        modelAndView.addObject("action","deletePartner");
        modelAndView.addObject("type", "delete");
        try {
            modelAndView.addObject("pannolist", service.getPan());
            modelAndView.addObject("updatemsg", service.deletePartner(formBean));            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(PartnerController.class.getName()).log(Level.SEVERE, null, ex);
            modelAndView.addObject("msg","Sorry Partner not updated, For any "
                    + "queries call on Toll Free number 1800-2000-155");            
        }
        return modelAndView;      
    }
    public ModelAndView viewPartner(HttpServletRequest request,HttpServletResponse response,PartnerFormBean formBean){
        ModelAndView modelAndView = new ModelAndView("ViewPartner");
        //For loading view partner module
        modelAndView.addObject("process", "view");
        return modelAndView;
    }
    public ModelAndView getfillGridReportsView(HttpServletRequest request,
            HttpServletResponse response,PartnerFormBean formBean) throws ClassNotFoundException, SQLException {
        //Get grid report data for view partner module
        ModelAndView modelAndView = new ModelAndView("ViewPartner");
        modelAndView.addObject("process", "grid");
        if(request.getParameter("center_id")!=null){
            formBean.setDdlcenter(request.getParameter("center_id"));
            modelAndView.addObject("json",service.getGridDataForSelection(formBean));
        }
        else{
            if(request.getParameter("viewtype")!=null && request.getParameter("viewtype").equals("all")){
                formBean.setDdleditpan("all");
                modelAndView.addObject("json", service.getGridData(formBean));
            }
            else{
                modelAndView.addObject("json", service.getGridDataforView());
            }
        }
        return modelAndView;
    }  
    public ModelAndView partnerUtility(HttpServletRequest request,
        HttpServletResponse response, PartnerFormBean formBean) throws ClassNotFoundException, SQLException {
        ModelAndView modelAndView = new ModelAndView("EditPartner");
        modelAndView.addObject("process","loadPanNo");
        modelAndView.addObject("type", request.getParameter("type"));
        //To get pan no for utility module which exclude rejected and approved partner
        modelAndView.addObject("pannolist", service.getUtilityPan()); 
        return modelAndView;
    } 
    public ModelAndView viewPartnerStatus(HttpServletRequest request,
        HttpServletResponse response, PartnerFormBean formBean) throws ClassNotFoundException, SQLException {
        ModelAndView modelAndView = new ModelAndView("ChnageStatus");
        modelAndView.addObject("process","changeStatus");
        formBean.setTxtPPAN(request.getParameter("pan"));
        modelAndView.addObject("partnerData", service.getPartnerUtility(formBean));
        return modelAndView;
    }
    public ModelAndView changePartnerStatus(HttpServletRequest request,
        HttpServletResponse response, PartnerFormBean formBean){
        //When partner status is updated from utility
        ModelAndView modelAndView = new ModelAndView("EditPartner");
        modelAndView.addObject("process","loadPanNo");
        modelAndView.addObject("action","modified");
        modelAndView.addObject("type", "utility");
        formBean.setTxtPPAN(request.getParameter("pan"));
        try {
            modelAndView.addObject("updatemsg",service.updatePartnerStatus(formBean).get("msg"));
            modelAndView.addObject("pannolist", service.getUtilityPan());
        } catch (ClassNotFoundException | SQLException ex) {
            modelAndView.addObject("updatemsg","Partner status not updated");
            Logger.getLogger(PartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return modelAndView;
    } 
    public ModelAndView partnerReport(HttpServletRequest request,
        HttpServletResponse response, PartnerFormBean formBean) throws ClassNotFoundException, SQLException{
        ModelAndView modelAndView = new ModelAndView("PartnerReport");
        //GenerateExcelReport excel = new GenerateExcelReport();
        modelAndView.addObject("type", "excel");
        //excel.GetExcelReport(service.getDataForReport());
        return modelAndView;
    }
    public ModelAndView getReport(HttpServletRequest request,
        HttpServletResponse response) throws Exception{
        ModelAndView modelAndView = new ModelAndView("PartnerReport");
        GenerateExcelReport excel = new GenerateExcelReport();
        GeneratePDFReport pdf = new GeneratePDFReport();
        modelAndView.addObject("process", "downloadreport");
        if(request.getParameter("type").equals("excel") && request.getParameter("type")!=null){
            String path = excel.GetExcelReport(service.getDataForReport());
            modelAndView.addObject("type", "excel");
        }
        else{
            pdf.getPDFReport(service.getDataForReport());
            modelAndView.addObject("type", "pdf");
        }
        return modelAndView;
    }

    public ModelAndView getReportNew(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException, DocumentException, IOException, FileNotFoundException, InterruptedException
    {
        ModelAndView mv = new ModelAndView();
        GenerateExcelReport excel = new GenerateExcelReport();
        GeneratePDFReport pdf = new GeneratePDFReport();
        if(request.getParameter("type").equals("excel") && request.getParameter("type")!=null){
            String filename = excel.GetExcelReport(service.getDataForReport());
            mv.addObject("fileName", "partner.xls");
            mv.addObject("filePath", filename.substring(0, filename.lastIndexOf("/")));            
        }
        else{
            String filename = pdf.getPDFReport(service.getDataForReport());
            mv.addObject("fileName", "partnerReport.pdf");
            mv.addObject("filePath", filename.substring(0, filename.lastIndexOf("/")));            
        }
        mv.setViewName("FileDownload");
        return mv;
    }    
   
}
/*

 public ModelAndView downloadFile(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView mv = new ModelAndView();
        try
        {

            SBCommonOperation sbcommon = SBCommonOperation.getSBCommonOperation();
            String path = sbcommon.getFile("fas/Budget/" + request.getParameter("fileName"));

            ContentDisposition condis = new ContentDisposition();
            condis.setFilePath(path);
            condis.setRequestType(ContentDispositionType.INLINE);
            condis.setResponse(response);
            condis.process();

            new CommonFunctions().deleteCacheFiles(path);
            return null;
        }
        catch ( Exception e )
        {
            long errId = Calendar.getInstance().getTimeInMillis();
            String errFile = finutils.errorhandler.ErrorHandler.PrintInFile(e, request, "Error generating report : "
                    + " Date = " + Calendar.getInstance().getTime().toString() + " " + " ID = " + errId);
            mv.addObject("ERR_FILE", errFile);
            mv.addObject("ERR_ID", errId);
            mv.setViewName("error");
        }
        return mv;
    }



 public ModelAndView downloadFile(HttpServletRequest request, HttpServletResponse response)
    {
        ModelAndView mv = new ModelAndView();
        try
        {
            String fileName = request.getParameter("fileName");

            SBCommonOperation sbcommon = SBCommonOperation.getSBCommonOperation();
            String filename = sbcommon.getFile("fas/claim/" + fileName);
            mv.addObject("fileName", fileName);
            mv.addObject("filePath", filename.substring(0, filename.lastIndexOf("/")));
            mv.setViewName("FileDownload");
        }
        catch ( Exception e )
        {
            long errId = Calendar.getInstance().getTimeInMillis();
            String errFile = finutils.errorhandler.ErrorHandler.PrintInFile(e, request, "Error generating report : "
                    + " Date = " + Calendar.getInstance().getTime().toString() + " " + " ID = " + errId);
            mv.addObject("ERR_FILE", errFile);
            mv.addObject("ERR_ID", errId);
            mv.setViewName("error");
        }
        return mv;
    }



*/
