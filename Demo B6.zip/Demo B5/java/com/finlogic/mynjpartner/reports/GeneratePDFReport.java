package com.finlogic.mynjpartner.reports;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.Phrase;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class GeneratePDFReport {
    private static String FILE = "/home/raj8/RT/partnerReport.pdf";
    public String getPDFReport(List ls) throws DocumentException, FileNotFoundException, IOException, InterruptedException{
        
        Document document = new Document(PageSize.A4.rotate());
        PdfWriter.getInstance(document, new FileOutputStream(FILE));
        document.open();
        PdfPTable table = new PdfPTable(12);
        table.setWidthPercentage(100.0f);
        table.setWidths(new float[] {1.10f,0.99f,0.99f,0.99f,0.99f,0.99f,0.99f,0.99f,0.99f,0.99f,0.99f,0.80f});
        table.setSpacingBefore(10);
        
        Font font = FontFactory.getFont(FontFactory.HELVETICA,12);
        Font f2 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 8);
        
        PdfPCell cell = new PdfPCell();
        cell.setPadding(5);
        cell.setPhrase(new Phrase("Pan no", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Partner Name", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Mobile", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Email", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Gender", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Date of Birth", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("State", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("City", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Pin code", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Center", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Spouse Name", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("House Hold", font));
        table.addCell(cell);        
        
        for(int i=0;i<ls.size();i++){
            cell.setPhrase(new Phrase(ls.get(i).toString().split(",")[4].split("=")[1], f2));
            table.addCell(cell);
            table.addCell(ls.get(i).toString().split(",")[0].split("=")[1]);
            table.addCell(ls.get(i).toString().split(",")[1].split("=")[1]);
            table.addCell(ls.get(i).toString().split(",")[2].split("=")[1]);
            table.addCell(ls.get(i).toString().split(",")[3].split("=")[1]);
            table.addCell(ls.get(i).toString().split(",")[9].split("=")[1]);
            table.addCell(ls.get(i).toString().split(",")[5].split("=")[1]);
            table.addCell(ls.get(i).toString().split(",")[6].split("=")[1]);
            table.addCell(ls.get(i).toString().split(",")[10].split("=")[1]);
            table.addCell(ls.get(i).toString().split(",")[7].split("=")[1]);
            table.addCell(ls.get(i).toString().split(",")[8].split("=")[1]);
            table.addCell(ls.get(i).toString().split(",")[11].split("=")[1].replaceAll("}", ""));
        } 
        document.add(table);
        document.close();
        if ((new File("/home/raj8/RT/partnerReport.pdf")).exists()){
            if (Desktop.isDesktopSupported()) {
                System.out.println("At desktop...........");
                Desktop.getDesktop().open(new File("/home/raj8/RT/partnerReport.pdf"));
            }
        }
        return FILE;
    }
}
