package com.finlogic.mynjpartner.reports;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;


public class GenerateExcelReport {

    public String GetExcelReport(List ls){
        HSSFWorkbook workbook = new HSSFWorkbook();
        CellStyle style = workbook.createCellStyle();
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        HSSFSheet sheet = workbook.createSheet("User Report");
        sheet.setDefaultColumnWidth(20);
        sheet.setColumnWidth(0, 4000);
        sheet.setColumnWidth(1, 4000);
        sheet.setColumnWidth(2, 3000);
        sheet.setColumnWidth(3, 7000);
        sheet.setColumnWidth(4, 2000);
        sheet.setColumnWidth(5, 4000);
        sheet.setColumnWidth(6, 4000);
        sheet.setColumnWidth(7, 4000);
        sheet.setColumnWidth(8, 3000);
        sheet.setColumnWidth(10, 3000);
        sheet.setColumnWidth(11, 3000);
        HSSFRow header = sheet.createRow(0);
        header.createCell(0).setCellValue("Pan No");
        header.getCell(0).setCellStyle(style);
        header.createCell(1).setCellValue("Paartner name");
        header.getCell(1).setCellStyle(style);
        header.createCell(2).setCellValue("Mobile no");
        header.getCell(2).setCellStyle(style);
        header.createCell(3).setCellValue("Email");
        header.getCell(3).setCellStyle(style);
        header.createCell(4).setCellValue("Gender");
        header.getCell(4).setCellStyle(style);
        header.createCell(5).setCellValue("Date of Birth");
        header.getCell(5).setCellStyle(style);
        header.createCell(6).setCellValue("State");
        header.getCell(6).setCellStyle(style);
        header.createCell(7).setCellValue("City");
        header.getCell(7).setCellStyle(style);
        header.createCell(8).setCellValue("Pin code");
        header.getCell(8).setCellStyle(style);
        header.createCell(9).setCellValue("Center");
        header.getCell(9).setCellStyle(style);
        header.createCell(10).setCellValue("Spouse Name");
        header.getCell(10).setCellStyle(style);
        header.createCell(11).setCellValue("House Hold");
        header.getCell(11).setCellStyle(style);
        int rowNum = 1;
        for(int i=0;i<ls.size();i++){
            HSSFRow row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(ls.get(i).toString().split(",")[4].split("=")[1]);
            row.createCell(1).setCellValue(ls.get(i).toString().split(",")[0].split("=")[1]);
            row.createCell(2).setCellValue(ls.get(i).toString().split(",")[1].split("=")[1]);
            row.createCell(3).setCellValue(ls.get(i).toString().split(",")[2].split("=")[1]);
            row.createCell(4).setCellValue(ls.get(i).toString().split(",")[3].split("=")[1]);
            row.createCell(5).setCellValue(ls.get(i).toString().split(",")[9].split("=")[1]);
            row.createCell(6).setCellValue(ls.get(i).toString().split(",")[5].split("=")[1]);
            row.createCell(7).setCellValue(ls.get(i).toString().split(",")[6].split("=")[1]);
            row.createCell(8).setCellValue(ls.get(i).toString().split(",")[10].split("=")[1]);
            row.createCell(9).setCellValue(ls.get(i).toString().split(",")[7].split("=")[1]);
            row.createCell(10).setCellValue(ls.get(i).toString().split(",")[8].split("=")[1]);
            row.createCell(11).setCellValue(ls.get(i).toString().split(",")[11].split("=")[1].replaceAll("}", ""));
        }
//        try (FileOutputStream outputStream = new FileOutputStream("Partner.xls")) {
        try (FileOutputStream outputStream = new FileOutputStream(new File("/home/raj8/RT/partner.xls"))) {
            System.out.println("Creating file ...................");
            workbook.write(outputStream);
        } catch (IOException ex) {
            Logger.getLogger(GenerateExcelReport.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "/home/raj8/RT/partner.xls";
    }
}
