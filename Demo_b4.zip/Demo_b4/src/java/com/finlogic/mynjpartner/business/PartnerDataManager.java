
package com.finlogic.mynjpartner.business;

import com.finlogic.util.persistence.SQLUtility;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityNotFoundException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;


public class PartnerDataManager {
    private static final String CONNECTION_ALIAS = "njindiainvest_offline";
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Date date = new Date();
    String curDate = dateFormat.format(date);
    public List getState() throws ClassNotFoundException, SQLException{
        
        SQLUtility sqlUtility = new SQLUtility();
        String sql = "select distinct state from demo_geolocation";
        List ls = sqlUtility.getList(CONNECTION_ALIAS, sql);
        return ls;
    }
    public List getCity(PartnerEntityBean entityBean) throws ClassNotFoundException, SQLException {
        SQLUtility sqlUtility = new SQLUtility();
        System.out.println("State is ....."+entityBean.getDdlstate());
        String sql = "select city from demo_geolocation where state = '"
                +entityBean.getDdlstate()+"';";
        List ls = sqlUtility.getList(CONNECTION_ALIAS, sql);
        System.out.println("City are%%%%%%%%%%%"+ls);
        return ls;
    }

    public List getCenter(PartnerEntityBean entityBean){
       SQLUtility sqlUtility = new SQLUtility();
       StringBuilder stbSQL = new StringBuilder();
       stbSQL.append("select * from njindiainvest.demo_njcenter where status='Active' and state='"+entityBean.getDdlstate()+"'");
       if(entityBean.getDdlcity().equals("")){
           stbSQL.append(";");
       }
       else{
           stbSQL.append(" and city='"+entityBean.getDdlcity()+"'");
       }
        List ls = null;
        try {
            ls = sqlUtility.getList(CONNECTION_ALIAS, stbSQL.toString());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PartnerDataManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(PartnerDataManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ls;
    }
    public Map insertPartner(PartnerEntityBean entityBean) throws ClassNotFoundException, SQLException{
        ArrayList alData = new ArrayList();
        SQLUtility sqlUtility = new SQLUtility();
        Map<String,String>  map= new HashMap<String,String>();
        StringBuilder stbSQL = new StringBuilder();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String curDate = dateFormat.format(date);
        
        String panNo = entityBean.getTxtPPAN();
        String name = entityBean.getTxtPName()+" "+entityBean.getTxtPLastName();
        System.out.println("----------------Pan no is-------"+entityBean.getTxtPPAN());
        stbSQL.append("select is_rejected from njindiainvest.demo_partner where ");
        stbSQL.append("pan='"+panNo+"'");
        List ls=null;
        //List ls = sqlUtility.getList(CONNECTION_ALIAS, stbSQL.toString());
        alData = (ArrayList) sqlUtility.getList(CONNECTION_ALIAS, stbSQL.toString());
        
        //System.out.println("!!!!!!!!!!!!!!!! LS "+alData.size()+".....value.."+alData.get(0)+" contains..."+(alData.get(0).toString().split("=")[1]));
        
        if(alData.size()>0){
            if((alData.get(0).toString().split("=")[1]).contains("yes")){
                stbSQL.setLength(0);
                stbSQL.append("insert into njindiainvest.demo_partner");
                stbSQL.append("(partner_name,mobile,emailid,gender,dob,pan,state,"
                        + "city,pincode,center_id,spouse_name,pan_scan_copy,"
                        + "existing_house_hold,registration_date,is_rejected,status)");
                stbSQL.append(" values");
                
                stbSQL.append("('"+name+"','"+entityBean.getTxtPMobile()+"','"+entityBean.getTxtPEmail()+"',"
                        + "'"+entityBean.getRadiogender()+"',str_to_date('"+entityBean.getDtdob()+"','%d-%m-%Y'),'"+panNo+"',"
                        + "'"+entityBean.getDdlstate()+"','"+entityBean.getDdlcity()+"','"+entityBean.getTxtPin()+"',"
                        + "'"+entityBean.getDdlcenter()+"','"+entityBean.getTxtPSpouse()+"','xyz.jpg','"+entityBean.getTxtPHH()+"','"+curDate+"','no','requested');");
                System.out.println("QUERY.....\n"+stbSQL.toString());
                sqlUtility.persist(CONNECTION_ALIAS, stbSQL.toString());
                map.put("msg", "Thank you for showing interest. Our representative will contact you shortly");
            }
            else{
                System.out.println("Can not insert exsist and not rejected------------------->");
                map.put("msg", "You are already registered with NJ India Invest "
                        + "Pvt. Ltd. For any queries call on Toll Free number 1800-2000-155");
            }
        }
        else{
            System.out.println("New Pan no--------------------->");
            stbSQL.setLength(0);
            stbSQL.append("insert into njindiainvest.demo_partner");
            stbSQL.append("(partner_name,mobile,emailid,gender,dob,pan,state,"
                    + "city,pincode,center_id,spouse_name,pan_scan_copy,"
                    + "existing_house_hold,registration_date,is_rejected,status)");
            stbSQL.append(" values");
            stbSQL.append("('"+name+"','"+entityBean.getTxtPMobile()+"','"+entityBean.getTxtPEmail()+"',"
                    + "'"+entityBean.getRadiogender()+"',str_to_date('"+entityBean.getDtdob()+"','%d-%m-%Y'),'"+panNo+"',"
                    + "'"+entityBean.getDdlstate()+"','"+entityBean.getDdlcity()+"','"+entityBean.getTxtPin()+"',"
                    + "'"+entityBean.getDdlcenter()+"','"+entityBean.getTxtPSpouse()+"','xyz.jpg','"+entityBean.getTxtPHH()+"','"+curDate+"','no','requested');");
            System.out.println("New Partner inserted QUERY.....\n"+stbSQL.toString());
            sqlUtility.persist(CONNECTION_ALIAS, stbSQL.toString());
            map.put("msg", "Thank you for showing interest. Our representative will contact you shortly");
        }
        System.out.println("Final LS....."+map);
        return map;
    }
    public List getPan() throws ClassNotFoundException, SQLException{
        
        SQLUtility sqlUtility = new SQLUtility();
        String sql = "select distinct pan from njindiainvest.demo_partner";
        List ls = sqlUtility.getList(CONNECTION_ALIAS, sql);
        return ls;
    }

    public List getGridData(PartnerEntityBean entityBean) throws ClassNotFoundException,
            SQLException {
        StringBuilder query = new StringBuilder();
        SQLUtility sqlUtility = new SQLUtility();
        if(entityBean.getTxtPin()!=null && entityBean.getTxtPin().equals("utility")){
            query.append("select partner_name,mobile,emailid, gender,pan,p.state,p.city,"
                    + "c.center_name,spouse_name,dob,p.pincode,existing_house_hold,p.status,"
                    + "concat(\"<a href='javascript:onEditUtility(\\\"\",pan,\"\\\")'>EDIT</a>\"),\n"
                    + "concat(\"<a href='javascript:onDelete(\\\"\",pan,\"\\\")'>DELETE</a>\")\n"
                    + "from njindiainvest.demo_partner as p,njindiainvest.demo_njcenter as c "
                    + "where p.center_id=c.center_id and p.status not in('approve','rejected')");  
        }
        else{
            query.append("select partner_name,mobile,emailid, gender,pan,p.state,p.city,"
                    + "p.center_id,spouse_name,dob,p.pincode,existing_house_hold,"
                    + "concat(\"<a href='javascript:onEdit(\\\"\",pan,\"\\\")'>EDIT</a>\"),\n"
                    + "concat(\"<a href='javascript:onDelete(\\\"\",pan,\"\\\")'>DELETE</a>\")\n"
                    + "from njindiainvest.demo_partner as p,njindiainvest.demo_njcenter as c "
                    + "where p.center_id=c.center_id");   
        }
        
        
        if(entityBean.getDdleditpan()==null){
            System.out.println("#####################@@@@@@@@@@@@@@@@@@"+entityBean.toString());
        }
        else if (!entityBean.getDdleditpan().equals("all") && entityBean.getDdleditpan()!= null) {
            query.append(" and pan = '").append(entityBean.getDdleditpan()).append("';");
            System.out.println(entityBean.getDdleditpan());
        }
        
        System.out.println("@@@@@@@@@@@@@@@@@"+query.toString());
        return sqlUtility.getList(CONNECTION_ALIAS, query.toString());
    }  
    public Map getPartnerDetailFromPAN(PartnerEntityBean entityBean) throws ClassNotFoundException, SQLException {

        String sqlQuery = "select partner_name,mobile,emailid,gender,dob,p.state,"
                + "p.city,pincode,c.center_name,if(spouse_name='null' or spouse_name is null, '',spouse_name) as spouse_name"
                + ",existing_house_hold from "
                + "njindiainvest.demo_partner as p,njindiainvest.demo_njcenter as c "
                + "where pan ='"+entityBean.getTxtPPAN()+"' and p.center_id=c.center_id";
        System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!"+sqlQuery);
        
        List<Map> list = new SQLUtility().getList(CONNECTION_ALIAS, sqlQuery, new MapSqlParameterSource().addValue("pan", entityBean.getTxtPPAN()));
        if (list != null && !list.isEmpty()) {
            return list.get(0);
        }
        throw new EntityNotFoundException("RECORD WITH PAN " + entityBean.getTxtPPAN() + " NOT FOUND IN OUR SYSTEM!!");
    }
    public Map updatePartner(PartnerEntityBean entityBean) throws ClassNotFoundException, SQLException{
        SQLUtility sqlUtility = new SQLUtility();
        Map<String,String>  map= new HashMap<String,String>();
        
        StringBuilder stbSQL = new StringBuilder();
        String name = entityBean.getTxtPName()+" "+entityBean.getTxtPLastName();
        stbSQL.append("Update njindiainvest.demo_partner ");
        stbSQL.append("set ");
        stbSQL.append("partner_name='"+name+"',");
        stbSQL.append("mobile='"+entityBean.getTxtPMobile()+"',");
        stbSQL.append("gender='"+entityBean.getRadiogender()+"',");
        stbSQL.append("dob=str_to_date('"+entityBean.getDtdob()+"','%Y-%m-%d'),");
        stbSQL.append("state='"+entityBean.getDdlstate()+"',");
        stbSQL.append("city='"+entityBean.getDdlcity()+"',");
        stbSQL.append("pincode='"+entityBean.getTxtPin()+"',");
        stbSQL.append("center_id='"+entityBean.getDdlcenter()+"',");
        stbSQL.append("spouse_name='"+entityBean.getTxtPSpouse()+"',");
        stbSQL.append("existing_house_hold='"+entityBean.getTxtPHH()+"',");
        stbSQL.append("updation_date='"+curDate+"' ");
        stbSQL.append(" where pan='"+entityBean.getTxtPPAN()+"';");
                
        System.out.println("^^^^^^^^^^^^^^^^ Updation query....."+stbSQL.toString());
        
        sqlUtility.persist(CONNECTION_ALIAS, stbSQL.toString());
        map.put("msg", "Partner Updated successfully");
        return map;
    }
    
    public String deletePartner(PartnerEntityBean entityBean) throws ClassNotFoundException, SQLException{
        SQLUtility sqlUtility = new SQLUtility();
        StringBuilder stbSQL = new StringBuilder();
        stbSQL.append("delete from njindiainvest.demo_partner where ");
        stbSQL.append(" pan='"+entityBean.getTxtPPAN()+"';");
        System.out.println("---------Delet Query------\n"+stbSQL.toString());
        sqlUtility.persist(CONNECTION_ALIAS, stbSQL.toString());
        return "Partner Deleted Successfully";
    }
    public List getGridDataforView() throws ClassNotFoundException, SQLException{
        StringBuilder query = new StringBuilder();
        SQLUtility sqlUtility = new SQLUtility();
        query.append("select \n" +
                    "	concat('<a href=javascript:onSelect(',c.center_id,')>',cast(count(p.partner_id) as char(10)),'</a>') as Total,\n" +
                    "    c.state,\n" +
                    "    c.center_name\n" +
                    "from \n" +
                    "	njindiainvest.demo_njcenter as c left join njindiainvest.demo_partner as p on c.center_id=p.center_id\n" +
                    "group by c.center_id;");        

        return sqlUtility.getList(CONNECTION_ALIAS, query.toString());
    }
    public List getGridDataForSelection(PartnerEntityBean entityBean) throws ClassNotFoundException,
            SQLException {
        StringBuilder query = new StringBuilder();
        SQLUtility sqlUtility = new SQLUtility();
        query.append("select partner_name,mobile,emailid, gender,pan,p.state,p.city,"
                + "p.center_id,spouse_name,dob,p.pincode,existing_house_hold "
                + "from njindiainvest.demo_partner as p,njindiainvest.demo_njcenter as c "
                + "where p.center_id=c.center_id and "
                + "p.center_id="+entityBean.getDdlcenter());   
               
        System.out.println("@@@@@@@@@@@@@@@@@"+query.toString());
        return sqlUtility.getList(CONNECTION_ALIAS, query.toString());
    }
    public List getPartnerUtility(PartnerEntityBean entityBean) throws ClassNotFoundException, SQLException{
        StringBuilder query = new StringBuilder();
        SQLUtility sqlUtility = new SQLUtility();
        query.append("select * from njindiainvest.demo_partner as p where pan='"+entityBean.getTxtPPAN()+"'");
        return sqlUtility.getList(CONNECTION_ALIAS, query.toString());
    }
    public Map updatePartnerStatus(PartnerEntityBean entityBean){
        StringBuilder query = new StringBuilder();
        SQLUtility sqlUtility = new SQLUtility();
        Map<String,String>  map= new HashMap<String,String>();
        query.append("update njindiainvest.demo_partner set status='"+entityBean.getDdlChangeStatus()+"'"
                + " where pan='"+entityBean.getTxtPPAN()+"'");
        map.put("msg", "Partner status updated succesfully to "+entityBean.getDdlChangeStatus());
        System.out.println("%%%%%%^^^^^^^^^^^%%%%%%%%%%"+query.toString());
        return map;
    }
}

