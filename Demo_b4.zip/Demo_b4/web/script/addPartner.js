function validate_data() {
    if (validate_form())
    {
        insert_data();
    } else {
        return false;
    }
}
function update_data(){
    if (validate_form())
    {
        insert_update_data();
    } else {
        return false;
    } 
}
function insert_update_data(){
    var param = getFormData(document.partnerForm);
    getSynchronousData('partner.fin?cmdAction=updatePartner',param,'loadPartner');
}
function insert_data(){
    var param = getFormData(document.partnerForm);
    //getSynchronousData('partner.fin?cmdAction=insertPartner',param,'loadPartner'); 
    
    var formObj = $("#partnerForm").get(0);
    var formData = new FormData(formObj);
    alert("ITS"+formData);
    console.log(formObj)
    $.ajax({
        url: 'partner.fin?cmdAction=insertPartner',
        type: 'POST',
        data: formData,
        mimeType: "multipart/form-data",
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) {
            alert("Record Inserted Sucessfully");
            $("#load").html(data);
            //location.href = "file.fin?cmdAction=getMenu";
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert("error in inserting data");
        }
    });
}
function validate_form() {
//    var fName = document.getElementById("txtPName").value;
//    var lName = document.getElementById("txtPLastName").value;
//    var mobile = document.getElementById("txtPMobile").value;
//    var email = document.getElementById("txtPEmail").value;
//    var dob = document.getElementById("dtdob").value;
//    var state = document.getElementById("ddlstate").value;
//    var city = document.getElementById("ddlcity").value;
//    var pin = document.getElementById("txtPin").value;
//    var center = document.getElementById("ddlcenter").value;
//    var panNo = document.getElementById("txtPPAN").value;
//    var spouseName = document.getElementById("txtPSpouse").value;
//    var houseHold = document.getElementById("txtPHH").value;
//    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
//    var regpan = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
    var oform = document.getElementById("partnerForm");
    
    if(!validate_ind(oform,"txtPName","First Name",true)||!validate_ind(oform,"txtPLastName","Last Name",true)
            ||!validate_only_number(oform,"txtPMobile","Mobile",true)||!validate_phonno(oform,"txtPMobile","Mobile",true)
            ||!validate_email(oform,"txtPEmail","Email",true)||!validate_dropdown(oform,"ddlstate","State",true)
            ||!validate_dropdown(oform,"ddlcity","City",true)||!validate_only_number(oform,"txtPin","Pin-code",true)
            ||!validate_pincode(oform,"txtPin","Pin-code",true)||!validate_dropdown(oform,"ddlcenter","NJ center",true)
            ||!validate_panno(oform,"txtPPAN","PAN no",true)||!validate_only_number(oform,"txtPHH","House hold",true)){
        
        return false;
    }
    else{
        return true;
    }
}


