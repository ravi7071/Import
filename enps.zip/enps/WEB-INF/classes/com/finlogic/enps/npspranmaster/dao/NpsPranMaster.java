/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npspranmaster.dao;

import com.finlogic.enps.npspranmaster.model.NpsPranMasterModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;

/**
 *
 * @author roshan4
 */
public interface NpsPranMaster {

    public void getupdatePran(NpsPranMasterModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException;
}
