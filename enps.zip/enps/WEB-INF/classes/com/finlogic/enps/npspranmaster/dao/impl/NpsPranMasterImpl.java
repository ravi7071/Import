/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npspranmaster.dao.impl;

import com.finlogic.enps.npspranmaster.dao.NpsPranMaster;
import com.finlogic.enps.npspranmaster.model.NpsPranMasterModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "NpsPranMaster")
public class NpsPranMasterImpl implements NpsPranMaster {

    @Override
    public void getupdatePran(NpsPranMasterModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", entbean.getRefno());
        query.append(" UPDATE NPS_PRAN_MASTER ");
        query.append(" SET REF_NO=NULL ");
        query.append(" WHERE REF_NO=:REF_NO ");

        sqltran.persist(query.toString(), new MapSqlParameterSource(map));
    }

}
