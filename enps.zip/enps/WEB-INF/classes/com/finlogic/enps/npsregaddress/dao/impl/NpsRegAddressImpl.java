/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsregaddress.dao.impl;

import com.finlogic.enps.npsregaddress.dao.NpsRegAddress;
import com.finlogic.enps.npsregaddress.model.NpsRegAddressModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "NpsRegAddress")
public class NpsRegAddressImpl implements NpsRegAddress{

    @Override
    public void getDeleteAddressData(NpsRegAddressModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", entbean.getRefno());
        query.append(" DELETE FROM NPS_REG_ADDRESS ");
        query.append(" WHERE REF_NO=:REF_NO ");

        sqltran.persist(query.toString(), new MapSqlParameterSource(map));
    }
    
}
