/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.contributionreport.service.impl;

import com.finlogic.enps.commons.util.CommonFunction;
import com.finlogic.enps.contributionreport.bean.ContributionReportBean;
import com.finlogic.enps.contributionreport.report.ContributionReport;
import com.finlogic.enps.contributionreport.service.ContributionService;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author roshan4
 */
@Service(value = "ContributionService")
public class ContributionServiceImpl implements ContributionService {

    @Autowired
    @Qualifier(value = "ContributionReport")
    private ContributionReport contributionReport;

    @Override
    public List<Map<String, String>> getReportData(ContributionReportBean bean) throws Exception {
        return contributionReport.getReportData(bean);
    }

    @Override
    public void getGenerateFile(HttpServletRequest request, HttpServletResponse response, ContributionReportBean bean) throws Exception {
        List lst = contributionReport.getGenerateFileReport(bean);
        String filename = "eNPS_PRAN_" + (CommonFunction.getCurrentDate(false)).replace("/", "");
        String temppath = CommonFunction.createCsvFile(filename, ",", lst, true, "");
        CommonFunction.getDownloadFileFromStaorageBox(request, response, "", temppath);

    }

}
