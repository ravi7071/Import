/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.contributionreport.service;

import com.finlogic.enps.contributionreport.bean.ContributionReportBean;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author roshan4
 */
public interface ContributionService {

    public List<Map<String, String>> getReportData(ContributionReportBean bean) throws Exception;

    public void getGenerateFile(HttpServletRequest request, HttpServletResponse response, ContributionReportBean bean) throws Exception;

}
