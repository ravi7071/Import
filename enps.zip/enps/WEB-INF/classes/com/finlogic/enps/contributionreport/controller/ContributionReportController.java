/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.contributionreport.controller;

import com.finlogic.enps.commons.util.CommonFunction;
import com.finlogic.enps.contributionreport.bean.ContributionReportBean;
import com.finlogic.enps.contributionreport.service.ContributionService;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author roshan4
 */
@Controller
@RequestMapping(value = "contributionreport.fin")
public class ContributionReportController {

    @Autowired
    @Qualifier(value = "ContributionService")
    private ContributionService contributionService;

    @ModelAttribute
    public void init(Model model) {
        model.addAttribute("currentdate", CommonFunction.getCurrentDate(false));
    }

    @RequestMapping(method = RequestMethod.GET)
    public String defaultMethod() throws Exception {
        String view = "contributionreport/contributionreport";
        return view;
    }

    @RequestMapping(params = "cmdAction=getReportData", method = RequestMethod.POST)
    public String getReportData(Model model, ContributionReportBean bean) throws Exception {
        String view = "contributionreport/contributionreportajax";
        String reportHeaading = "Contribution Transaction Report For " + bean.getTxtfromdate() + " To " + bean.getTxttodate();
        model.addAttribute("reportlist", contributionService.getReportData(bean));
        model.addAttribute("heading", reportHeaading);
        model.addAttribute("action", "getReport");
        return view;
    }

    @RequestMapping(params = "cmdAction=getGenerateFile", method = RequestMethod.GET)
    public void getGenerateFile(HttpServletRequest request, HttpServletResponse response, ContributionReportBean bean) throws Exception {
        contributionService.getGenerateFile(request, response, bean);
    }

}
