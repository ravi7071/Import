package com.finlogic.enps.contributionreport.bean;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author roshan4
 */
public class ContributionReportBean {
    
    public String txtfromdate;
    public String txttodate;
    public String refids;

    public String getTxtfromdate() {
        return txtfromdate;
    }

    public void setTxtfromdate(String txtfromdate) {
        this.txtfromdate = txtfromdate;
    }

    public String getTxttodate() {
        return txttodate;
    }

    public void setTxttodate(String txttodate) {
        this.txttodate = txttodate;
    }

    public String getRefids() {
        return refids;
    }

    public void setRefids(String refids) {
        this.refids = refids;
    }
        
}
