/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.contributionreport.report.impl;

import com.finlogic.enps.contributionreport.bean.ContributionReportBean;
import com.finlogic.enps.contributionreport.report.ContributionReport;
import com.finlogic.util.persistence.SQLUtility;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "ContributionReport")
public class ContributionReportImpl implements ContributionReport {

    @Autowired
    @Qualifier(value = "sqlutility")
    private SQLUtility sqlutil;

    private static String ALIAS;
    private static String ekycpending;
    private static String paymentreceived;

    @Value("${enps_db_alias}")
    public void setDbAlias(String dbAlias) {
        this.ALIAS = dbAlias;
    }

    @Value("${ekyc_pending}")
    public void setEkycpending(String ekyc_pending) {
        this.ekycpending = ekyc_pending;
    }

    @Value("${payment_received}")
    public void setPaymentReceived(String payment_received) {
        this.paymentreceived = payment_received;
    }

    @Override
    public List<Map<String, String>> getReportData(ContributionReportBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map mp = new HashMap();
        mp.put("FROMDATE", bean.getTxtfromdate());
        mp.put("TODATE", bean.getTxttodate());

        query.append(" SELECT NRT.PAYMENT_ID,NRT.REF_NO,NPM.PRAN_NO,NRT.IS_FRESH, ");
        query.append(" NSM.STATUS,DATE_FORMAT(NRT.ENTDATE,'%d-%m-%Y') AS ENTDATE,NRT.STATUS_ID ");
        query.append(" FROM eNPS.NPS_REG_TRXN NRT ");
        query.append(" INNER JOIN eNPS.NPS_REG_MAIN NRM ON NRM.REF_NO = NRT.REF_NO ");
        query.append(" INNER JOIN eNPS.NPS_PRAN_MASTER NPM ON NRM.REF_NO = NPM.REF_NO ");
        query.append(" INNER JOIN eNPS.NPS_STATUS_MASTER NSM ON NRT.STATUS_ID = NSM.STATUS_ID ");
        query.append(" WHERE NRM.ACTIVATION = '1' ");
        query.append(" AND DATE(NRT.ENTDATE) BETWEEN STR_TO_DATE(:FROMDATE, '%d-%m-%Y') AND STR_TO_DATE(:TODATE, '%d-%m-%Y') ");
        query.append(" ORDER BY NRT.REF_NO, NRT.PAYMENT_ID ");
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(mp));
    }

    @Override
    public List getGenerateFileReport(ContributionReportBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("EKYCPENDING", ekycpending);
        map.put("PAYMENTRECIEVED", paymentreceived);

//        query.append(" SELECT @ROWNUM := @ROWNUM + 1 AS SN,T1.*");
//        query.append(" FROM");
        query.append(" SELECT");
        query.append(" DISTINCT IFNULL(L.LOC_NAME,'') AS BRANCH,");
        query.append(" CASE WHEN (GM.NJBRCODE IS NOT NULL AND GM.NAME IS NOT NULL)");
        query.append(" THEN CONCAT(GM.NJBRCODE,'-',GM.NAME)");
        query.append(" WHEN (GM.NJBRCODE IS NULL AND GM.NAME IS NOT NULL)");
        query.append(" THEN GM.NAME");
        query.append(" WHEN (GM.NJBRCODE IS NOT NULL AND GM.NAME IS NULL)");
        query.append(" THEN GM.NJBRCODE");
        query.append(" ELSE ''");
        query.append(" END PARTNER,");
        query.append(" IFNULL(DATE_FORMAT(NSCD1.ENT_DATE, '%d/%m/%Y'),'') AS REGISTRATION_DATE,");
        query.append(" IFNULL(DATE_FORMAT(NRT.ENTDATE, '%d/%m/%Y'),'') AS PAYMENT_RECEIPT_DATE,");
        query.append(" IFNULL(NRM.ENT_BY,'') AS UCC,");
        query.append(" IFNULL(NPM.PRAN_NO,'') AS PRAN,");
        query.append(" CASE WHEN NRT.IS_FRESH = 'Y' THEN 'Initial'");
        query.append(" WHEN NRT.IS_FRESH = 'N' THEN 'Subsequent'");
        query.append(" ELSE ''");
        query.append(" END CONTRIBUTION_TYPE,");
        query.append(" IFNULL(NRP.EKYC_NAME,'') AS SUBSCRIBER_NAME,");
        query.append(" CASE WHEN NRT.IS_FRESH = 'Y' THEN NRM.RECEIPT_NO");
        query.append(" ELSE ''");
        query.append(" END RECEIPT_NO_REGISTARTION,");
        query.append(" IFNULL(NRT.TIER_I_RECEIPT_NO,'') AS RECEIPT_NO_TRXN_TIER_I,");
        query.append(" IFNULL(NRT.TIER_II_RECEIPT_NO,'') AS RECEIPT_NO_TRXN_TIER_II,");
        query.append(" IFNULL(NRM.REF_NO,'') AS MERCHANT_REF_NO,");
        query.append(" CASE WHEN NRT.IS_FRESH = 'Y' THEN IFNULL(NBMI.BANK_NAME,'')");
        query.append(" WHEN (NRT.IS_FRESH = 'N' AND NRT.TIER_II_AMOUNT IS NULL) THEN IFNULL(NBMI.BANK_NAME,'')");
        query.append(" WHEN (NRT.IS_FRESH = 'N' AND NRT.TIER_I_AMOUNT IS NOT NULL AND NRT.TIER_II_AMOUNT IS NOT NULL) THEN IFNULL(NBMI.BANK_NAME,'')");
        query.append(" WHEN (NRT.IS_FRESH = 'N' AND NRT.TIER_I_AMOUNT IS NULL AND NRT.TIER_II_AMOUNT IS NOT NULL) THEN IFNULL(NBMII.BANK_NAME,'')");
        query.append(" END BANK_NAME,");
        query.append(" CASE WHEN NRT.IS_FRESH = 'Y' THEN IFNULL(NRBDI.ACCNO,'')");
        query.append(" WHEN (NRT.IS_FRESH = 'N' AND NRT.TIER_II_AMOUNT IS NULL) THEN IFNULL(NRBDI.ACCNO,'')");
        query.append(" WHEN (NRT.IS_FRESH = 'N' AND NRT.TIER_I_AMOUNT IS NOT NULL AND NRT.TIER_II_AMOUNT IS NOT NULL) THEN IFNULL(NRBDI.ACCNO,'')");
        query.append(" WHEN (NRT.IS_FRESH = 'N' AND NRT.TIER_I_AMOUNT IS NULL AND NRT.TIER_II_AMOUNT IS NOT NULL) THEN IFNULL(NRBDII.ACCNO,'')");
        query.append(" END BANK_ACCOUNT_NO,");
        query.append(" IFNULL(NRT.TIER_I_AMOUNT,'') AS TIER_I_AMT,");
        query.append(" IFNULL(NRT.TIER_II_AMOUNT,'') AS TIER_II_AMT,");
        query.append(" IFNULL(NRTC1.TRXN_CHRG,'') AS ACCOUNT_OPENING_CHARGE,");
        query.append(" IF(IFNULL(NRTC1.IGST_AMT,0.0) + IFNULL(NRTC1.CGST_AMT,0.0) + IFNULL(NRTC1.SGST_AMT,0.0) + IFNULL(NRTC1.UTGST_AMT,0.0)=0,'',IFNULL(NRTC1.IGST_AMT,0.0) + IFNULL(NRTC1.CGST_AMT,0.0) + IFNULL(NRTC1.SGST_AMT,0.0) + IFNULL(NRTC1.UTGST_AMT,0.0)) AS GST_ON_ACCOUNT_OPENING_CHARGE,");
        query.append(" IFNULL(NRTC2.TRXN_CHRG,'') AS TRANSACTION_CHARGE_TIER_I,");
        query.append(" IF(IFNULL(NRTC2.IGST_AMT,0.0) + IFNULL(NRTC2.CGST_AMT,0.0) + IFNULL(NRTC2.SGST_AMT,0.0) + IFNULL(NRTC2.UTGST_AMT,0.0)=0,'',IFNULL(NRTC2.IGST_AMT,0.0) + IFNULL(NRTC2.CGST_AMT,0.0) + IFNULL(NRTC2.SGST_AMT,0.0) + IFNULL(NRTC2.UTGST_AMT,0.0)) AS GST_ON_TRANSACTION_CHARGE_TIER_I,");
        query.append(" IFNULL(NRTC3.TRXN_CHRG,'') AS TRANSACTION_CHARGE_TIER_II,");
        query.append(" IF(IFNULL(NRTC3.IGST_AMT,0.0) + IFNULL(NRTC3.CGST_AMT,0.0) + IFNULL(NRTC3.SGST_AMT,0.0) + IFNULL(NRTC3.UTGST_AMT,0.0)=0,'',IFNULL(NRTC3.IGST_AMT,0.0) + IFNULL(NRTC3.CGST_AMT,0.0) + IFNULL(NRTC3.SGST_AMT,0.0) + IFNULL(NRTC3.UTGST_AMT,0.0) )AS GST_ON_TRANSACTION_CHARGE_TIER_II,");
        query.append(" IFNULL(NRT.NET_AMOUNT,'') AS TOTAL_AMOUNT");
        query.append(" FROM eNPS.NPS_REG_MAIN NRM");
        query.append(" LEFT JOIN eNPS.NPS_STATUS_CHANGE_DTL NSCD1 ON (NSCD1.REF_NO = NRM.REF_NO AND NSCD1.STATUS_ID = :EKYCPENDING AND NSCD1.CHANGE_BY = 'AUTO')");
        query.append(" LEFT JOIN eNPS.NPS_STATUS_CHANGE_DTL NSCD2 ON (NSCD2.REF_NO = NRM.REF_NO AND NSCD2.STATUS_ID = :PAYMENTRECIEVED)");
        query.append(" INNER JOIN eNPS.NPS_PRAN_MASTER NPM ON (NPM.REF_NO = NRM.REF_NO)");
        query.append(" INNER JOIN eNPS.NPS_REG_PERSONAL NRP ON (NRP.REF_NO = NRM.REF_NO)");
        query.append(" INNER JOIN eNPS.NPS_REG_BANK_DTL NRBDI ON (NRBDI.REF_NO = NRM.REF_NO AND NRBDI.NPS_AC_TYPE = '1')");
        query.append(" LEFT JOIN eNPS.NPS_REG_BANK_DTL NRBDII ON (NRBDII.REF_NO = NRM.REF_NO AND NRBDII.NPS_AC_TYPE = '2')");
        query.append(" INNER JOIN eNPS.NPS_BANK_MAST NBMI ON (NBMI.BANK_ID = NRBDI.BANK_ID)");
        query.append(" LEFT JOIN eNPS.NPS_BANK_MAST NBMII ON (NBMII.BANK_ID = NRBDII.BANK_ID)");
        query.append(" INNER JOIN eNPS.NPS_REG_TRXN NRT ON (NRT.REF_NO = NRM.REF_NO AND NRT.STATUS_ID = '7')");
        query.append(" LEFT JOIN eNPS.NPS_REG_TRXNCHRG NRTC1 ON (NRTC1.PAYMENT_ID = NRT.PAYMENT_ID AND NRTC1.TRXN_TYPE = '3')");
        query.append(" INNER JOIN registration.TAC_MAIN TM ON (TM.NJAC_NO = NRM.ENT_BY)");
        query.append(" INNER JOIN registration.TAC_DETAIL TD ON (TM.NJAC_NO = TD.NJAC_NO)");
        query.append(" INNER JOIN njindiainvest.GRPMST GM ON (GM.GRPCODE = TD.BRCODE)");
        query.append(" INNER JOIN NJHR.LOCATION L ON GM.BRNCODE=L.LOC_ID");
        query.append(" LEFT JOIN eNPS.NPS_REG_TRXNCHRG NRTC2 ON (NRTC2.PAYMENT_ID = NRT.PAYMENT_ID AND NRTC2.TRXN_TYPE = '1')");
        query.append(" LEFT JOIN eNPS.NPS_REG_TRXNCHRG NRTC3 ON (NRTC3.PAYMENT_ID = NRT.PAYMENT_ID AND NRTC3.TRXN_TYPE = '2')");
        query.append(" WHERE NRT.PAYMENT_ID IN (").append(bean.getRefids()).append(")");
        query.append(" ORDER BY PAYMENT_RECEIPT_DATE DESC");
//        query.append(" ) T1, (SELECT @ROWNUM := 0) R");
//        CommonMemberLog.appendLog("Query===>" + query.toString());
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }

}
