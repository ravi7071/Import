/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsregmain.model;

/**
 *
 * @author roshan4
 */
public class NpsRegMainModel {

    private String refno;
    private String receiptno;
    private String category;
    private String tierI;
    private String tierII;
    private String pan;
    private String uid;
    private String brcode;
    private String accode;
    private String statusid;
    private String activedate;
    private String entby;
    private String empcode;
    private String editempcode;
    private String entdate;
    private String ekyceligible;
    private String ekycmode;
    private String gstno;
    private String activation;

    public String getRefno() {
        return refno;
    }

    public void setRefno(String refno) {
        this.refno = refno;
    }

    public String getReceiptno() {
        return receiptno;
    }

    public void setReceiptno(String receiptno) {
        this.receiptno = receiptno;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTierI() {
        return tierI;
    }

    public void setTierI(String tierI) {
        this.tierI = tierI;
    }

    public String getTierII() {
        return tierII;
    }

    public void setTierII(String tierII) {
        this.tierII = tierII;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getBrcode() {
        return brcode;
    }

    public void setBrcode(String brcode) {
        this.brcode = brcode;
    }

    public String getAccode() {
        return accode;
    }

    public void setAccode(String accode) {
        this.accode = accode;
    }

    public String getStatusid() {
        return statusid;
    }

    public void setStatusid(String statusid) {
        this.statusid = statusid;
    }

    public String getActivedate() {
        return activedate;
    }

    public void setActivedate(String activedate) {
        this.activedate = activedate;
    }

    public String getEntby() {
        return entby;
    }

    public void setEntby(String entby) {
        this.entby = entby;
    }

    public String getEmpcode() {
        return empcode;
    }

    public void setEmpcode(String empcode) {
        this.empcode = empcode;
    }

    public String getEditempcode() {
        return editempcode;
    }

    public void setEditempcode(String editempcode) {
        this.editempcode = editempcode;
    }

    public String getEntdate() {
        return entdate;
    }

    public void setEntdate(String entdate) {
        this.entdate = entdate;
    }

    public String getEkyceligible() {
        return ekyceligible;
    }

    public void setEkyceligible(String ekyceligible) {
        this.ekyceligible = ekyceligible;
    }

    public String getEkycmode() {
        return ekycmode;
    }

    public void setEkycmode(String ekycmode) {
        this.ekycmode = ekycmode;
    }

    public String getGstno() {
        return gstno;
    }

    public void setGstno(String gstno) {
        this.gstno = gstno;
    }

    public String getActivation() {
        return activation;
    }

    public void setActivation(String activation) {
        this.activation = activation;
    }
   
}
