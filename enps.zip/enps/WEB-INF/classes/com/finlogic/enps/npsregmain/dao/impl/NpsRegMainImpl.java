/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsregmain.dao.impl;

import com.finlogic.enps.npsregmain.dao.NpsRegMain;
import com.finlogic.enps.npsregmain.model.NpsRegMainModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "NpsRegMain")
public class NpsRegMainImpl implements NpsRegMain {

    private static String ekyc_pending;
    private static String active;

    @Value("${ekyc_pending}")
    public void setEkycPending(String ekyc_pending) {
        NpsRegMainImpl.ekyc_pending = ekyc_pending;
    }

    @Value("${active}")
    public void setActive(String active) {
        NpsRegMainImpl.active = active;
    }

    @Override
    public void getUpdateStatus(NpsRegMainModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", entbean.getRefno());
        map.put("STATUS_ID", entbean.getStatusid());
        map.put("ACTIVEDATE", entbean.getActivedate());
        query.append(" UPDATE NPS_REG_MAIN ");
        query.append(" SET STATUS_ID=:STATUS_ID ");
        if (entbean.getStatusid().equalsIgnoreCase(ekyc_pending)) {
            query.append(" , EKYC_MODE=NULL ");
        } else if (entbean.getStatusid().equalsIgnoreCase(active)) {
            query.append(" , ACTIVE_DATE=STR_TO_DATE(:ACTIVEDATE,'%d-%m-%Y') ");
        }
        query.append(" WHERE REF_NO=:REF_NO ");
        sqltran.persist(query.toString(), new MapSqlParameterSource(map));
    }

    @Override
    public String getCountFileExport(NpsRegMainModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", entbean.getRefno());
        query.append(" SELECT COUNT(*) AS CNT ");
        query.append(" FROM NPS_REG_MAIN ");
        query.append(" WHERE  CRA_EXPORT_DATE IS NULL AND REF_NO=:REF_NO ");

        return sqltran.getString(query.toString(), new MapSqlParameterSource(map));
    }

    @Override
    public void getUpdateActivation(NpsRegMainModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", entbean.getRefno());
        query.append(" UPDATE NPS_REG_MAIN ");
        query.append(" SET ACTIVATION='0' ");
        query.append(" WHERE REF_NO=:REF_NO ");

        sqltran.persist(query.toString(), new MapSqlParameterSource(map));
    }

    @Override
    public void getUpdateExportDate(NpsRegMainModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        query.append(" UPDATE NPS_REG_MAIN ");
        query.append(" SET CRA_EXPORT_DATE=SYSDATE() ");
        query.append(" WHERE REF_NO IN(").append(entbean.getRefno()).append(")");

        sqltran.persist(query.toString());
    }

}
