/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsregmain.dao;

import com.finlogic.enps.npsregmain.model.NpsRegMainModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;

/**
 *
 * @author roshan4
 */
public interface NpsRegMain {

    public void getUpdateStatus(NpsRegMainModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException;

    public String getCountFileExport(NpsRegMainModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException;

    public void getUpdateActivation(NpsRegMainModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException;

    public void getUpdateExportDate(NpsRegMainModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException;

}
