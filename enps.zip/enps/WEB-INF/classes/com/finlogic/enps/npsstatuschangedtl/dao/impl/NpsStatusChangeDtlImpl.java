/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsstatuschangedtl.dao.impl;

import com.finlogic.enps.npsstatuschangedtl.dao.NpsStatusChangeDtl;
import com.finlogic.enps.npsstatuschangedtl.model.NpsStatusChangeDtlModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "NpsStatusChangeDtl")
public class NpsStatusChangeDtlImpl implements NpsStatusChangeDtl {

    private static String payment_received;
    private static String payment_failed;
    private static String active;
    private static String rejected_by_nj;
    private static String rejected_by_cra;

    @Value("${payment_received}")
    public void setPaymentReceived(String payment_received) {
        NpsStatusChangeDtlImpl.payment_received = payment_received;
    }

    @Value("${payment_failed}")
    public void setPaymentFailed(String payment_failed) {
        NpsStatusChangeDtlImpl.payment_failed = payment_failed;
    }

    @Value("${active}")
    public void setActive(String active) {
        NpsStatusChangeDtlImpl.active = active;
    }

    @Value("${rejected_by_nj}")
    public void setRejectedByNj(String rejected_by_nj) {
        NpsStatusChangeDtlImpl.rejected_by_nj = rejected_by_nj;
    }

    @Value("${rejected_by_cra}")
    public void setRejectedByCRA(String rejected_by_cra) {
        NpsStatusChangeDtlImpl.rejected_by_cra = rejected_by_cra;
    }

    @Override
    public void getInsertStatusDtl(NpsStatusChangeDtlModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", entbean.getRefno());
        map.put("STATUS_ID", entbean.getStatusid());
        map.put("EMP_CODE", entbean.getEmpcode());
        map.put("REJECT_REASON", entbean.getRejectreason());
        map.put("STATUSDATE", entbean.getTxtstatusdate());
        query.append(" INSERT INTO NPS_STATUS_CHANGE_DTL(REF_NO,STATUS_ID,ENT_DATE,CHANGE_BY,EMP_CODE,REJECT_REASON) ");
        query.append(" VALUES(:REF_NO,:STATUS_ID,");
        if (entbean.getStatusid().equalsIgnoreCase(payment_received) || entbean.getStatusid().equalsIgnoreCase(payment_failed) || entbean.getStatusid().equalsIgnoreCase(active) || entbean.getStatusid().equalsIgnoreCase(rejected_by_nj) || entbean.getStatusid().equalsIgnoreCase(rejected_by_cra)) {
            query.append("STR_TO_DATE(:STATUSDATE,'%d-%m-%Y')");
        } else {
            query.append("SYSDATE()");
        }
        query.append(",'MANUAL',:EMP_CODE,:REJECT_REASON)");

        sqltran.persist(query.toString(), new MapSqlParameterSource(map));
    }

}
