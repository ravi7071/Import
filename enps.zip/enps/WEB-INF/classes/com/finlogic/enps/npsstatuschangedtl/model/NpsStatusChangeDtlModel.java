/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsstatuschangedtl.model;

/**
 *
 * @author roshan4
 */
public class NpsStatusChangeDtlModel {

    private String refno;
    private String statusid;
    private String entdate;
    private String rejectreason;
    private String changeby;
    private String empcode;
    private String txtstatusdate;

    public String getRefno() {
        return refno;
    }

    public void setRefno(String refno) {
        this.refno = refno;
    }

    public String getStatusid() {
        return statusid;
    }

    public void setStatusid(String statusid) {
        this.statusid = statusid;
    }

    public String getEntdate() {
        return entdate;
    }

    public void setEntdate(String entdate) {
        this.entdate = entdate;
    }

    public String getRejectreason() {
        return rejectreason;
    }

    public void setRejectreason(String rejectreason) {
        this.rejectreason = rejectreason;
    }

    public String getChangeby() {
        return changeby;
    }

    public void setChangeby(String changeby) {
        this.changeby = changeby;
    }

    public String getEmpcode() {
        return empcode;
    }

    public void setEmpcode(String empcode) {
        this.empcode = empcode;
    }

    public String getTxtstatusdate() {
        return txtstatusdate;
    }

    public void setTxtstatusdate(String txtstatusdate) {
        this.txtstatusdate = txtstatusdate;
    }
}
