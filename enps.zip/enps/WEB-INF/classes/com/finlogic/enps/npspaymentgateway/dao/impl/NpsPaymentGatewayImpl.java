/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npspaymentgateway.dao.impl;

import com.finlogic.enps.commons.util.CommonMemberLog;
import com.finlogic.enps.npspaymentgateway.dao.NpsPaymentGateway;
import com.finlogic.enps.npspaymentgateway.model.NpsPaymentGatewayModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "NpsPaymentGateway")
public class NpsPaymentGatewayImpl implements NpsPaymentGateway {

    @Override
    public int getUpdatePayment(NpsPaymentGatewayModel entbean, SQLTranUtility sqltran) throws Exception {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();

        map.put("PAYSTATUS", entbean.getPaymentStatus());
        map.put("PAYREFNO", entbean.getPaymentRefNo());
        map.put("REMARKS", entbean.getRemarks());
        map.put("PAYMENTID", entbean.getPaymentid());

        query.append(" UPDATE NPS_PAYMENTGATEWAY ");
        query.append(" SET PAYMENT_STATUS=:PAYSTATUS , PAYMENT_REF_NO=:PAYREFNO , REMARKS=:REMARKS ");
        query.append(" WHERE PAYMENT_ID=:PAYMENTID ");

        return sqltran.persist(query.toString(), new MapSqlParameterSource(map));
    }

}
