/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npspaymentgateway.dao;

import com.finlogic.enps.npspaymentgateway.model.NpsPaymentGatewayModel;
import com.finlogic.util.persistence.SQLTranUtility;

/**
 *
 * @author roshan4
 */
public interface NpsPaymentGateway {

    public int getUpdatePayment(NpsPaymentGatewayModel entbean,SQLTranUtility sqltran) throws Exception;

}
