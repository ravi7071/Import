/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.communication.mail;

import com.finlogic.eai.ws.consumer.ecommunication.EmailConsumer;
import java.util.Map;

/**
 *
 * @author roshan4
 */
public class EmailSender {

    public String sendEmail(Map mp) throws Exception {

        String mailSucess = "0";
        EmailConsumer econsumer = new EmailConsumer();
        try {
            String[] key
                    = {
                        "templateId", "to", "subjectValues", "mailFromServer",
                        "attachment", "contentValues", "bcc", "cc"
                    };
            String[] values
                    = {
                        mp.get("emailtempId").toString(),
                        mp.get("to").toString(),
                        mp.get("subjectValue") != null ? mp.get("subjectValue").toString() : null,
                        mp.get("mailFromServer").toString(),
                        mp.get("attachment") != null && !mp.get("attachment").toString().equalsIgnoreCase("") ? mp.get("attachment").toString() : null,
                        mp.get("content").toString(),
                        mp.get("bcc") != null && !mp.get("bcc").toString().equalsIgnoreCase("") ? mp.get("bcc").toString() : null,
                        mp.get("cc") != null && !mp.get("cc").toString().equalsIgnoreCase("") ? mp.get("cc").toString() : null
                    };

            econsumer.sendEmail(key, values);

        } catch (Exception ex) {
            throw ex;
        }
        return mailSucess;
    }
}
