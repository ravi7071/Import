/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.common.dao;

import com.finlogic.enps.craexportutility.bean.CRAExportUtilityBean;
import java.util.List;
import java.util.Map;

/**
 *
 * @author roshan4
 */
public interface OtherSchemaDataDao {

    public List<Map<String, String>> getBranchList() throws Exception;

    public List<Map<String, String>> getPartnerList(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> getBankDetailList(String bankcode, String njacno) throws Exception;
}
