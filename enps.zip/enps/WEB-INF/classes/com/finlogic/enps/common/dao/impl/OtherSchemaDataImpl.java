/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.common.dao.impl;

import com.finlogic.enps.common.dao.OtherSchemaDataDao;
import com.finlogic.enps.craexportutility.bean.CRAExportUtilityBean;
import com.finlogic.util.persistence.SQLUtility;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "OtherSchemaDataDao")
public class OtherSchemaDataImpl implements OtherSchemaDataDao {

    @Autowired
    @Qualifier(value = "sqlutility")
    private SQLUtility sqlutil;

    private static String ALIAS;
    private static String segmentid;
    private static String lvlid;

    @Value("${enps_db_alias}")
    public void setDbAlias(String dbAlias) {
        OtherSchemaDataImpl.ALIAS = dbAlias;
    }

    @Value("${segment_id}")
    public void setSegmentId(String segid) {
        OtherSchemaDataImpl.segmentid = segid;
    }

    @Value("${lvl_id}")
    public void setLvltId(String lvlid) {
        OtherSchemaDataImpl.lvlid = lvlid;
    }

    @Override
    public List<Map<String, String>> getBranchList() throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();

        Map map = new HashMap();
        map.put("SEG_ID", segmentid);
        map.put("LVL_ID", lvlid);

        query.append(" SELECT LOC_ID,LOC_NAME ")
                .append(" FROM NJHR.LOCATION ")
                .append(" WHERE LOC_ACTIVE=1 AND LVL_ID = :LVL_ID AND SEG_ID = :SEG_ID ")
                .append(" ORDER BY LOC_NAME ");

        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }

    @Override
    public List<Map<String, String>> getPartnerList(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();

        query.append(" SELECT NJBRCODE,NAME ");
        query.append(" FROM njindiainvest.GRPMST ");
        query.append(" WHERE CATCODE = 'Partner'");
        if (bean.getTxttextlike() != null && !bean.getTxttextlike().trim().equalsIgnoreCase("")) {
            query.append(" AND (NJBRCODE LIKE '%").append(bean.getTxttextlike()).append("%' OR NAME LIKE '%").append(bean.getTxttextlike()).append("%')");
            if (bean.getCmbbranch() != null && !bean.getCmbbranch().equalsIgnoreCase("")) {
                query.append(" AND BRNCODE IN('").append(bean.getCmbbranch().replace(",", "\',\'")).append("')");
            }
        }
        query.append(" ORDER BY NAME ");
        return sqlutil.getList(ALIAS, query.toString());
    }

    @Override
    public List<Map<String, String>> getBankDetailList(String bankcode, String njacno) throws Exception {
        StringBuilder query = new StringBuilder();

        Map map = new HashMap();
        map.put("BANKCODE", bankcode);
        map.put("NJACNO", njacno);
        query.append(" SELECT IFNULL(TBM.IFSC,'NA') AS IFSC,IFNULL(TBM.MICR,'NA') AS MICR,IFNULL(TBM.BANKACCNO,'NA') AS BANKACCNO, ");
        query.append(" IFNULL(TBM.BANK_NAME,'NA') AS BANK_NAME,IFNULL(TBM.BANK_ADD,'NA') AS BANK_ADD, ");
        query.append(" IFNULL(TBM.BANKBRANCH,'NA') AS BANKBRANCH,IFNULL(TBM.BANKACCTYPE,'NA') AS BANKACCTYPE, ");
        query.append(" IFNULL(TBM.PINCODE,'NA') AS PINCODE,IFNULL(GM.PAR_GEO_ID,'NA') AS STATE_CODE, ");
        query.append(" IFNULL(GM1.PAR_GEO_ID ,'NA') AS COUNTRY_CODE ");
        query.append(" FROM registration.TAC_BANK_MST TBM ");
        query.append(" INNER JOIN NJHR.GEO_MAST GM ON GM.GEO_ID=TBM.CITY_ID ");
        query.append(" INNER JOIN NJHR.GEO_MAST GM1 ON GM1.GEO_ID=GM.PAR_GEO_ID ");
        query.append(" WHERE  TBM.BANK_CODE = :BANKCODE AND  TBM.NJAC_NO= :NJACNO AND TBM.IS_DEFAULT='Y' ");

        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
}
