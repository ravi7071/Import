/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.home.controller;

import com.finlogic.enps.commons.util.CommonFunction;
import com.finlogic.enps.commons.util.CommonMemberLog;
import com.finlogic.enps.session.model.SessionBean;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author ankur7
 */
@Controller
@RequestMapping(value = "home.fin")
public class HomeController {
    
    @RequestMapping(method = RequestMethod.POST)
    public void sessionHandler(HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        
        SessionBean sessionBean = CommonFunction.getSessionBean(request);
        HttpSession session = request.getSession(true);
        
        sessionBean.setUsername(request.getParameter("username"));
        sessionBean.setUserId(request.getParameter("userid"));
        sessionBean.setMecode(request.getParameter("mecode"));
        sessionBean.setAclUrl(request.getParameter("aclurl"));
        sessionBean.setSessionId(request.getParameter("sessionId"));
        sessionBean.setLoginName(request.getParameter("loginName"));
        sessionBean.setType(request.getParameter("Type"));
        
        session.setAttribute("username", sessionBean.getUsername());
        session.setAttribute("ACLEmpCode", request.getParameter("mecode"));
        session.setAttribute("aclurl", request.getParameter("aclurl"));
        session.setAttribute("sid", request.getParameter("sessionId"));
        session.setAttribute("projectName", request.getParameter("projectName"));        
        session.setAttribute("email", request.getParameter("email"));
        session.setAttribute("preferencelink", request.getParameter("preferencelink"));
        session.setAttribute("helplink", request.getParameter("helplink"));
        session.setAttribute("changepasswordlink", request.getParameter("changepasswordlink"));
        session.setAttribute("userphotolink", request.getParameter("userphotolink"));
        
        response.sendRedirect("home.fin");
        
    }
    
    @RequestMapping(method = RequestMethod.GET)
    public String defaultMethod() {
        return "home";
    }
    
    @RequestMapping(params = "cmdAction=logOut", method = RequestMethod.GET)
    public void logOut(HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        
        SessionBean sessionBean = CommonFunction.getSessionBean(request);
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        response.sendRedirect(sessionBean.getAclUrl());
        
    }
    
}
