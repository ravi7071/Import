/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.commons.util;

import com.lowagie.text.BadElementException;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;
import java.util.Map;

/**
 *
 * @author roshan4
 */
public class NpsInvoiceGenerator {

    private static final String[] units = {"", " One", " Two", " Three", " Four", " Five", " Six", " Seven", " Eight", " Nine"};
    private static final String[] teen = {" Ten", " Eleven", " Twelve", " Thirteen", " Fourteen", " Fifteen", " Sixteen", " Seventeen", " Eighteen", " Nineteen"};
    private static final String[] tens = {" Twenty", " Thirty", " Forty", " Fifty", " Sixty", " Seventy", " Eighty", " Ninety"};
    private static final String[] maxs = {"", "", " Hundred", " Thousand", " Lakh", " Crore"};
    PdfPCell cell;
    String caption = "";

    private String njNpsGstIn;
    private String hsnSacCode;

    public String generatePdf(List invoiceDataList,
            File objFile, String njnpsgstin, String hsnsaccode) throws Exception {
        try {
            NpsPdfFileGenerator objPdfGen = new NpsPdfFileGenerator();
            njNpsGstIn = njnpsgstin;
            hsnSacCode = hsnsaccode;
            Map mapInvoiceData = null;
            Font font6 = new Font();
            font6.setSize(6);
            font6.setFamily("arial");

            Font font6Bold = new Font();
            font6Bold.setSize(6);
            font6Bold.setStyle(Font.BOLD);
            font6Bold.setFamily("arial");

            NumberFormat nf = NumberFormat.getInstance();
            nf.setMaximumFractionDigits(2);
            nf.setMinimumFractionDigits(2);
            nf.setGroupingUsed(false);

            objPdfGen.open(objFile);
            objPdfGen.document.setPageSize(PageSize.A4);
            objPdfGen.document.setMargins(20, 20, 47, 47);//left,right,top,bottom

            mapInvoiceData = (Map) invoiceDataList.get(0);

            //for (int main = 0; main < 3; main++) {
            objPdfGen.document.newPage();
            //System.out.println(" GSTIN -- 3");

            //For header 
            setHeader(objPdfGen);
            //For header end
            //
            setCompanyTaxDesc(mapInvoiceData, objPdfGen);

            //     
            //Blank rwo start
            setBlankRow(objPdfGen);
            //Blank rwo end

            //2nd rwo started
            PdfPTable subbilltorwo = new PdfPTable(1);
            subbilltorwo.addCell(writeContentToBorderLessCell("Details of Receiver (Billed to)  ", Element.ALIGN_LEFT, 2, 1));
            PdfPTable billtorwo = new PdfPTable(1);
            billtorwo.addCell(subbilltorwo);
            objPdfGen.addTable(billtorwo);
            //2nd rwo Done

            //2nd rwo started
            setReceiverDetail(mapInvoiceData, objPdfGen);

            //2nd rwo Done
            //Main content
            int[] contentWidth = {1, 15, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3};

            PdfPTable table = new PdfPTable(16);
            setMainTableHeader(table);

            setMainTableContent(table, mapInvoiceData, objPdfGen);

            cell = new PdfPCell(new Phrase(""));
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setFixedHeight(16);
            cell.setColspan(16);
            table.addCell(cell);
            table.setWidths(contentWidth);
            objPdfGen.addTable(table);

            //End Main content
            setInvoiceAmountDesc(mapInvoiceData, objPdfGen);

            //Start Terms & condition block
            serTermsConBloc(mapInvoiceData, objPdfGen);

            //Terms & condition block end
            //IF data available then Only display START
            //Start adderess block
            setFooter(mapInvoiceData, objPdfGen);

            //adderess blockend
            objPdfGen.document.close();
            objPdfGen.mPdfWriter.close();
            objPdfGen.close();
        } catch (Exception e) {
            throw e;
        }
        return null;
    }

    public void setHeader(NpsPdfFileGenerator objPdfGen) throws DocumentException, BadElementException, IOException, ClassNotFoundException {
        PdfPTable companySubDetail = new PdfPTable(2);

        float[] widthmainDetail = new float[]{
            10, 90
        };

        PdfPTable imgDetail = new PdfPTable(1);

        Image img = Image.getInstance("/opt/apache-tomcat1/webapps/enps/includes/img/nps_invoice_img.jpg");
        img.setWidthPercentage(20);
        img.scaleToFit(20, 20);
        cell = new PdfPCell(img);
        cell.setRowspan(4);
        cell.setBorder(0);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        imgDetail.addCell(cell);

        caption = "NJ India Invest Private Limited";
        companySubDetail.addCell(writeContentToBorderLessCell("Name : " + caption, Element.ALIGN_LEFT, 2, 1));

        caption = "Block No 901& 902, 6th Floor B Tower, Udhna Udhyognagar Sangh Commercial Complex, Central Road No 10, Udhna, Surat-394210";
        companySubDetail.addCell(writeContentToBorderLessCell("Address : " + caption, Element.ALIGN_LEFT, 2, 1));

        PdfPTable companyDetail = new PdfPTable(2);
        companyDetail.addCell(imgDetail);
        companyDetail.addCell(companySubDetail);
        companyDetail.setWidths(widthmainDetail);
        objPdfGen.addTable(companyDetail);

    }

    public PdfPCell writeContentToBorderLessCell(String content, int alignment, int colspan, int rowspan) {
        Font objFont6 = new Font();
        objFont6.setSize(6);
        objFont6.setFamily("arial");
        PdfPCell cell = new PdfPCell(new Phrase(content, objFont6));
        if (content.equalsIgnoreCase("")) {
            cell.setFixedHeight(15);
        }
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setRowspan(rowspan);
        cell.setColspan(colspan);
        cell.setBorder(0);
        cell.setHorizontalAlignment(alignment);
        return cell;
    }

    public void setCompanyTaxDesc(Map mp, NpsPdfFileGenerator objPdfGen) throws Exception {

        PdfPTable cmpnytxtdtl = new PdfPTable(3);
        caption = njNpsGstIn;

        cmpnytxtdtl.addCell(createHeaderCell("GSTIN", objPdfGen.ALIGN_LEFT));
        cmpnytxtdtl.addCell(createHeaderCell(": ", objPdfGen.ALIGN_LEFT));
        cmpnytxtdtl.addCell(createHeaderCell(caption, objPdfGen.ALIGN_LEFT));

        cmpnytxtdtl.addCell(createHeaderCell("Invoice No", objPdfGen.ALIGN_LEFT));

        caption = mp.get("INVOICE_NUM") != null ? mp.get("INVOICE_NUM").toString() : "-";
        cmpnytxtdtl.addCell(createHeaderCell(": ", objPdfGen.ALIGN_LEFT));
        cmpnytxtdtl.addCell(createHeaderCell(caption, objPdfGen.ALIGN_LEFT));

        cmpnytxtdtl.addCell(createHeaderCell("Invoice Date", objPdfGen.ALIGN_LEFT));

        caption = mp.get("ENT_DATE") != null ? mp.get("ENT_DATE").toString() : "-";
        cmpnytxtdtl.addCell(createHeaderCell(": ", objPdfGen.ALIGN_LEFT));
        cmpnytxtdtl.addCell(createHeaderCell(caption, objPdfGen.ALIGN_LEFT));

        cmpnytxtdtl.addCell(createHeaderCell("Tax is payable on reverse charge", objPdfGen.ALIGN_LEFT));
        //caption = mp.get("GST_NO") != null ? "Yes" : "No";
        caption = "No";
        cmpnytxtdtl.addCell(createHeaderCell(": ", objPdfGen.ALIGN_LEFT));
        cmpnytxtdtl.addCell(createHeaderCell(caption, objPdfGen.ALIGN_LEFT));

        cmpnytxtdtl.setWidths(new int[]{18, 3, 80});
        PdfPTable cmpnyMstDetail = new PdfPTable(1);
        cmpnyMstDetail.addCell(cmpnytxtdtl);
        objPdfGen.addTable(cmpnyMstDetail);

    }

    public PdfPCell createHeaderCell(String content, int alignment) throws Exception {
        Font font6Bold = new Font();
        font6Bold.setSize(6);
        font6Bold.setFamily("arial");
        PdfPCell cell = new PdfPCell();
        cell.setBorder(0);
        cell.setHorizontalAlignment(alignment);
        cell.setPaddingTop(5);
        cell.setPaddingLeft(3);
        cell.setPhrase(new Phrase(content, font6Bold));
        return cell;
    }

    public void setBlankRow(NpsPdfFileGenerator objPdfGen) throws Exception {
        PdfPTable subblankrwo = new PdfPTable(1);
        subblankrwo.addCell(writeContentToBorderLessCell("", Element.ALIGN_LEFT, 2, 1));
        PdfPTable blankrwo = new PdfPTable(1);
        blankrwo.addCell(subblankrwo);
        objPdfGen.addTable(blankrwo);
    }

    public void setReceiverDetail(Map mp, NpsPdfFileGenerator objPdfGen) throws Exception {
        PdfPTable subbilltodetailrwo = new PdfPTable(3);

        subbilltodetailrwo.addCell(createHeaderCell("Name", objPdfGen.ALIGN_LEFT));
        caption = mp.get("EKYC_NAME") != null ? mp.get("EKYC_NAME").toString() : "-";
        subbilltodetailrwo.addCell(createHeaderCell(": ", objPdfGen.ALIGN_LEFT));
        subbilltodetailrwo.addCell(createHeaderCell(caption, objPdfGen.ALIGN_LEFT));

        subbilltodetailrwo.addCell(createHeaderCell("Address", objPdfGen.ALIGN_LEFT));
        caption = mp.get("Address") != null ? mp.get("Address").toString() : "-";
        subbilltodetailrwo.addCell(createHeaderCell(": ", objPdfGen.ALIGN_LEFT));
        subbilltodetailrwo.addCell(createHeaderCell(caption, objPdfGen.ALIGN_LEFT));

        subbilltodetailrwo.addCell(createHeaderCell("State", objPdfGen.ALIGN_LEFT));
        caption = mp.get("GEO_NAME") != null ? mp.get("GEO_NAME").toString() : "-";
        subbilltodetailrwo.addCell(createHeaderCell(": ", objPdfGen.ALIGN_LEFT));
        subbilltodetailrwo.addCell(createHeaderCell(caption, objPdfGen.ALIGN_LEFT));

        subbilltodetailrwo.addCell(createHeaderCell("State Code", objPdfGen.ALIGN_LEFT));
        caption = mp.get("GSTIN") != null ? mp.get("GSTIN").toString() : "-";
        subbilltodetailrwo.addCell(createHeaderCell(": ", objPdfGen.ALIGN_LEFT));
        subbilltodetailrwo.addCell(createHeaderCell(caption, objPdfGen.ALIGN_LEFT));

        subbilltodetailrwo.addCell(createHeaderCell("GSTIN", objPdfGen.ALIGN_LEFT));
        caption = mp.get("GST_NO") != null ? mp.get("GST_NO").toString() : "-";
        subbilltodetailrwo.addCell(createHeaderCell(": ", objPdfGen.ALIGN_LEFT));
        subbilltodetailrwo.addCell(createHeaderCell(caption, objPdfGen.ALIGN_LEFT));

        subbilltodetailrwo.setWidths(new int[]{18, 3, 80});
        PdfPTable mstbilltodetailrwo = new PdfPTable(1);
        mstbilltodetailrwo.addCell(subbilltodetailrwo);
        objPdfGen.addTable(mstbilltodetailrwo);
    }

    public PdfPTable setMainTableHeader(PdfPTable table) throws Exception {

        table.addCell(createCell("Sr. No.", 1, 2, Element.ALIGN_CENTER));
        table.addCell(createCell("Description of Service", 1, 2, Element.ALIGN_CENTER));
        table.addCell(createCell("SAC", 1, 2, Element.ALIGN_CENTER));
        table.addCell(createCell("Place of Supply", 1, 2, Element.ALIGN_CENTER));
        table.addCell(createCell("Amount (INR)", 1, 2, Element.ALIGN_CENTER));
        table.addCell(createCell("Discount (INR)", 1, 2, Element.ALIGN_CENTER));
        table.addCell(createCell("Taxable value (INR)", 1, 2, Element.ALIGN_CENTER));

        table.addCell(createCell("CGST", 2, 1, PdfPCell.TOP));
        table.addCell(createCell("SGST", 2, 1, PdfPCell.TOP));
        table.addCell(createCell("IGST", 2, 1, PdfPCell.TOP));
        table.addCell(createCell("UTGST", 2, 1, PdfPCell.TOP));
        table.addCell(createCell("TOTAL", 1, 1, PdfPCell.TOP));

        table.addCell(createCell("Tax Rate", 1, 1, Element.ALIGN_CENTER));
        table.addCell(createCell("Amount", 1, 1, Element.ALIGN_CENTER));
        table.addCell(createCell("Tax Rate", 1, 1, Element.ALIGN_CENTER));
        table.addCell(createCell("Amount", 1, 1, Element.ALIGN_CENTER));
        table.addCell(createCell("Tax Rate", 1, 1, Element.ALIGN_CENTER));
        table.addCell(createCell("Amount", 1, 1, Element.ALIGN_CENTER));
        table.addCell(createCell("Tax Rate", 1, 1, Element.ALIGN_CENTER));
        table.addCell(createCell("Amount", 1, 1, Element.ALIGN_CENTER));
        table.addCell(createCell("Amount", 1, 1, Element.ALIGN_CENTER));

        return table;
    }

    public PdfPCell createCell(String content, int colspan, int rowspan, int alignment) {
        Font objFont8Bold = new Font();
        objFont8Bold.setSize(5);
        objFont8Bold.setStyle(Font.BOLD);
        objFont8Bold.setFamily("arial");
        PdfPCell cell = new PdfPCell(new Phrase(content, objFont8Bold));
        cell.setColspan(colspan);
        cell.setRowspan(rowspan);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setHorizontalAlignment(alignment);
        return cell;
    }

    public PdfPTable setMainTableContent(PdfPTable table, Map mp, NpsPdfFileGenerator objPdfGen) throws Exception {

        DecimalFormat df2 = new DecimalFormat(".##");
        double discount = 0.00;
        double igstRate, cgstRate, sgstRate, utgstRate, igstAmt, cgstAmt, sgstAmt, utgstAmt, totalAmount, trxn_chrg, taxableValue;
        double totalIGST = 0, totalCGST = 0, totalSGST = 0, totalUTGST = 0, totalTrxnChrg = 0, totalTaxableValue = 0, grandTotal = 0;

        if (mp.containsKey("InvoiceType") && mp.get("InvoiceType") != null
                && mp.get("InvoiceType").toString().equalsIgnoreCase("NPS_CONTRIBUTION")) {

            int limit = (mp.get("Tier1_TRXN_CHRG") != null && mp.get("Tier2_TRXN_CHRG") != null)
                    ? 2 : 1;
            for (int i = 1; i <= limit; i++) {
                table.addCell(writeContentToTableCell(Integer.toString(i), objPdfGen.ALIGN_CENTRE, 1, 1));

                if (i == 1) {
                    if (mp.get("Tier1_TRXN_CHRG") != null
                            && mp.get("Tier2_TRXN_CHRG") == null) {
                        caption = "NPS Transaction Charges for Tier I";
                    } else if (mp.get("Tier1_TRXN_CHRG") == null
                            && mp.get("Tier2_TRXN_CHRG") != null) {
                        caption = "NPS Transaction Charges for Tier II";
                        i = 2;// to get data from map for tier 2 trxn
                    } else {
                        caption = "NPS Transaction Charges for Tier I";
                    }
                } else if (i == 2) {
                    caption = "NPS Transaction Charges for Tier II";
                }
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_LEFT, 1, 1));
                caption = hsnSacCode;
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));
                caption = mp.get("GEO_NAME") != null ? mp.get("GEO_NAME").toString() : "-";
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_LEFT, 1, 1));

                trxn_chrg = Double.parseDouble(mp.get("Tier" + i + "_TRXN_CHRG") != null ? mp.get("Tier" + i + "_TRXN_CHRG").toString() : "0");
                totalTrxnChrg += trxn_chrg;
                caption = make2DecimalPoint(trxn_chrg);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                caption = make2DecimalPoint(discount);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                taxableValue = trxn_chrg - discount;
                totalTaxableValue += taxableValue;
                caption = make2DecimalPoint(taxableValue);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                cgstRate = Double.parseDouble(mp.get("Tier" + i + "_CGST_RATE") != null ? mp.get("Tier" + i + "_CGST_RATE").toString() : "0");
                caption = make2DecimalPoint(cgstRate);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                cgstAmt = Double.parseDouble(mp.get("Tier" + i + "_CGST_AMT") != null ? mp.get("Tier" + i + "_CGST_AMT").toString() : "0");
                totalCGST += cgstAmt;
                caption = make2DecimalPoint(cgstAmt);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                sgstRate = Double.parseDouble(mp.get("Tier" + i + "_SGST_RATE") != null ? mp.get("Tier" + i + "_SGST_RATE").toString() : "0");
                caption = make2DecimalPoint(sgstRate);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                sgstAmt = Double.parseDouble(mp.get("Tier" + i + "_SGST_AMT") != null ? mp.get("Tier" + i + "_SGST_AMT").toString() : "0");
                totalSGST += sgstAmt;
                caption = make2DecimalPoint(sgstAmt);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                igstRate = Double.parseDouble(mp.get("Tier" + i + "_IGST_RATE") != null ? mp.get("Tier" + i + "_IGST_RATE").toString() : "0");
                caption = make2DecimalPoint(igstRate);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                igstAmt = Double.parseDouble(mp.get("Tier" + i + "_IGST_AMT") != null ? mp.get("Tier" + i + "_IGST_AMT").toString() : "0");
                totalIGST += igstAmt;
                caption = make2DecimalPoint(igstAmt);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                utgstRate = Double.parseDouble(mp.get("Tier" + i + "_UTGST_RATE") != null ? mp.get("Tier" + i + "_UTGST_RATE").toString() : "0");
                caption = make2DecimalPoint(utgstRate);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                utgstAmt = Double.parseDouble(mp.get("Tier" + i + "_UTGST_AMT") != null ? mp.get("Tier" + i + "_UTGST_AMT").toString() : "0");
                totalUTGST += utgstAmt;
                caption = make2DecimalPoint(utgstAmt);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                totalAmount = trxn_chrg + cgstAmt + sgstAmt + igstAmt + utgstAmt;
                grandTotal += totalAmount;
                caption = make2DecimalPoint(totalAmount);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

            }

        } else {
            for (int i = 0; i <= (mp.get("Tier2_TRXN_CHRG") != null
                    ? 2 : 1); i++) {

                table.addCell(writeContentToTableCell(Integer.toString(i + 1), objPdfGen.ALIGN_CENTRE, 1, 1));

                if (i == 0) {
                    caption = "NPS Account Opening Charges";
                } else if (i == 1) {
                    caption = "NPS Transaction Charges for Tier I";
                } else {
                    caption = "NPS Transaction Charges for Tier II";
                }
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_LEFT, 1, 1));
                caption = hsnSacCode;
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));
                caption = mp.get("GEO_NAME") != null ? mp.get("GEO_NAME").toString() : "-";
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_LEFT, 1, 1));

                trxn_chrg = Double.parseDouble(mp.get("Tier" + i + "_TRXN_CHRG") != null ? mp.get("Tier" + i + "_TRXN_CHRG").toString() : "0");
                totalTrxnChrg += trxn_chrg;
                caption = make2DecimalPoint(trxn_chrg);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                caption = make2DecimalPoint(discount);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                taxableValue = trxn_chrg - discount;
                totalTaxableValue += taxableValue;
                caption = make2DecimalPoint(taxableValue);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                cgstRate = Double.parseDouble(mp.get("Tier" + i + "_CGST_RATE") != null ? mp.get("Tier" + i + "_CGST_RATE").toString() : "0");
                caption = make2DecimalPoint(cgstRate);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                cgstAmt = Double.parseDouble(mp.get("Tier" + i + "_CGST_AMT") != null ? mp.get("Tier" + i + "_CGST_AMT").toString() : "0");
                totalCGST += cgstAmt;
                caption = make2DecimalPoint(cgstAmt);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                sgstRate = Double.parseDouble(mp.get("Tier" + i + "_SGST_RATE") != null ? mp.get("Tier" + i + "_SGST_RATE").toString() : "0");
                caption = make2DecimalPoint(sgstRate);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                sgstAmt = Double.parseDouble(mp.get("Tier" + i + "_SGST_AMT") != null ? mp.get("Tier" + i + "_SGST_AMT").toString() : "0");
                totalSGST += sgstAmt;
                caption = make2DecimalPoint(sgstAmt);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                igstRate = Double.parseDouble(mp.get("Tier" + i + "_IGST_RATE") != null ? mp.get("Tier" + i + "_IGST_RATE").toString() : "0");
                caption = make2DecimalPoint(igstRate);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                igstAmt = Double.parseDouble(mp.get("Tier" + i + "_IGST_AMT") != null ? mp.get("Tier" + i + "_IGST_AMT").toString() : "0");
                totalIGST += igstAmt;
                caption = make2DecimalPoint(igstAmt);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                utgstRate = Double.parseDouble(mp.get("Tier" + i + "_UTGST_RATE") != null ? mp.get("Tier" + i + "_UTGST_RATE").toString() : "0");
                caption = make2DecimalPoint(utgstRate);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                utgstAmt = Double.parseDouble(mp.get("Tier" + i + "_UTGST_AMT") != null ? mp.get("Tier" + i + "_UTGST_AMT").toString() : "0");
                totalUTGST += utgstAmt;
                caption = make2DecimalPoint(utgstAmt);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

                totalAmount = trxn_chrg + cgstAmt + sgstAmt + igstAmt + utgstAmt;
                grandTotal += totalAmount;
                caption = make2DecimalPoint(totalAmount);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));

            }
        }

        for (int i = 2; i < 4; i++) {
            if (i == 2) {
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_CENTRE, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_LEFT, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_LEFT, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_CENTRE, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_CENTRE, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_CENTRE, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_CENTRE, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_RIGHT, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_RIGHT, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_RIGHT, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_RIGHT, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_RIGHT, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_RIGHT, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_RIGHT, 1, 1));
                table.addCell(writeContentToTableCell("", objPdfGen.ALIGN_RIGHT, 1, 1));
            } else if (i == 3) {

                caption = "";
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_LEFT, 1, 1));
                caption = "";
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_LEFT, 1, 1));
                caption = "TOTAL";
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 3, 1));
                caption = make2DecimalPoint(totalTrxnChrg);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));
                caption = make2DecimalPoint(Double.parseDouble("0"));
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));
                caption = make2DecimalPoint(totalTaxableValue);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 1, 1));
                caption = make2DecimalPoint(totalCGST);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 2, 1));
                caption = make2DecimalPoint(totalSGST);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 2, 1));
                caption = make2DecimalPoint(totalIGST);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 2, 1));
                caption = make2DecimalPoint(totalUTGST);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 2, 1));
                caption = make2DecimalPoint(grandTotal);
                table.addCell(writeContentToTableCell(caption, objPdfGen.ALIGN_RIGHT, 2, 1));

            }

        }
        mp.put("TotalAMount", grandTotal);
        return table;
    }

    public PdfPCell writeContentToTableCell(String content, int alignment, int colspan, int rowspan) {
        Font objFont6 = new Font();
        objFont6.setSize(5);
        objFont6.setFamily("arial");
        PdfPCell cell = new PdfPCell(new Phrase(content, objFont6));
        if (content.equalsIgnoreCase("")) {
            cell.setFixedHeight(15);
        }
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setRowspan(rowspan);
        cell.setColspan(colspan);
        cell.setHorizontalAlignment(alignment);
        return cell;
    }

    public String make2DecimalPoint(double value) {
        return String.format("%.2f", value);
    }

    public void setInvoiceAmountDesc(Map mp, NpsPdfFileGenerator objPdfGen) throws Exception {

        PdfPTable totaldescdtl = new PdfPTable(2);

        caption = make2DecimalPoint(Double.parseDouble(mp.get("TotalAmount").toString()));
        totaldescdtl.addCell(writeContentToBorderLessCell("Invoice Total (INR) :  "
                + caption, Element.ALIGN_RIGHT, 2, 1));
        caption = getAmountToText(caption);
        totaldescdtl.addCell(writeContentToBorderLessCell("Invoice Total (in words) : "
                + caption, Element.ALIGN_RIGHT, 2, 1));

        PdfPTable msttotaldescdtl = new PdfPTable(1);
        msttotaldescdtl.addCell(totaldescdtl);
        objPdfGen.addTable(msttotaldescdtl);
    }

    public String getAmountToText(String caption) {

        double num = Double.parseDouble(caption);
        String[] amount = String.valueOf(make2DecimalPoint(num)).split("\\.");
        String rupees = convertNumberToWords(amount[0]) + " rupees ";
        String paisa = amount.length > 1 && Integer.parseInt(amount[1]) > 0 ? "and " + convertNumberToWords(amount[1]) + " paisa only" : "only";
        String number = (rupees + paisa);

        return number;
    }

    public String convertNumberToWords(String num) {
        int n = Integer.parseInt(num);
        String input = numToString(n);

        String converted = "";

        int pos = 1;

        boolean hun = false;
        while (input.length() > 0) {
            if (pos == 1) // TENS AND UNIT POSITION
            {
                if (input.length() >= 2) // TWO DIGIT NUMBERS
                {

                    String temp = input.substring(input.length() - 2, input.length());
                    input = input.substring(0, input.length() - 2);
                    converted += digits(temp);
                } else if (input.length() == 1) // 1 DIGIT NUMBER
                {
                    converted += digits(input);

                    input = "";
                }
                pos++;
            } else if (pos == 2) // HUNDRED POSITION
            {

                String temp = input.substring(input.length() - 1, input.length());
                input = input.substring(0, input.length() - 1);
                if (converted.length() > 0 && digits(temp) != "") {
                    converted = (digits(temp) + maxs[pos] + " ") + converted;

                    hun = true;
                } else {
                    if (digits(temp) == ""); else {
                        converted = (digits(temp) + maxs[pos]) + converted;
                    }
                    hun = true;
                }
                pos++;
            } else if (pos > 2) // REMAINING NUMBERS PAIRED BY TWO
            {
                if (input.length() >= 2) // EXTRACT 2 DIGITS
                {

                    String temp = input.substring(input.length() - 2, input.length());
                    input = input.substring(0, input.length() - 2);
                    if (!hun && converted.length() > 0) {
                        converted = digits(temp) + maxs[pos] + " " + converted;
                    } else if (digits(temp) == "")  ; else {
                        converted = digits(temp) + maxs[pos] + converted;
                    }
                } else if (input.length() == 1) // EXTRACT 1 DIGIT
                {

                    if (!hun && converted.length() > 0) {
                        converted = digits(input) + maxs[pos] + " " + converted;
                    } else {
                        if (digits(input) == "")  ; else {
                            converted = digits(input) + maxs[pos] + converted;
                        }
                        input = "";
                    }
                }
                pos++;
            }
        }
        return converted;
    }

    private String numToString(int x) {
        String num = "";
        while (x != 0) {
            num = ((char) ((x % 10) + 48)) + num;
            x /= 10;
        }
        return num;
    }

    private String digits(String temp) {
        String converted = "";
        for (int i = temp.length() - 1; i >= 0; i--) {
            int ch = temp.charAt(i) - 48;
            if (i == 0 && ch > 1 && temp.length() > 1) {
                converted = tens[ch - 2] + converted; // IF TENS DIGIT STARTS WITH 2 OR MORE IT FALLS UNDER TENS
            } else if (i == 0 && ch == 1 && temp.length() == 2) // IF TENS DIGIT STARTS WITH 1 IT FALLS UNDER TEENS
            {
                int sum = 0;
                for (int j = 0; j < 2; j++) {
                    sum = (sum * 10) + (temp.charAt(j) - 48);
                }
                return teen[sum - 10];
            } else if (ch > 0) {
                converted = units[ch] + converted;
            } // IF SINGLE DIGIT PROVIDED
        }
        return converted;
    }

    public void serTermsConBloc(Map mp, NpsPdfFileGenerator objPdfGen) throws Exception {

        Font font6 = new Font();
        font6.setSize(6);
        font6.setFamily("arial");

        PdfPTable termsBlock = new PdfPTable(2);

        PdfPTable signatureBlock = new PdfPTable(1);

        PdfPTable finalBlock = new PdfPTable(1);

        cell = new PdfPCell();
        cell.setHorizontalAlignment(objPdfGen.ALIGN_LEFT);
        cell.setPaddingTop(5);
        cell.setPaddingLeft(4);
        cell.setFixedHeight(20);
        cell.setPhrase(new Phrase("Terms & Conditions : \n\n Certified that the details as mentioned above are true and correct.\n\n Subject to Surat jurisdiction.", font6));
        cell.setBorder(0);
        termsBlock.addCell(cell);
        termsBlock.setWidths(new int[]{75, 25});
        caption = "NJ India Invest Private Limited";  //Supplier Name  
        cell = writeContentToCell("For," + caption, Element.ALIGN_LEFT, 1, 1);
        cell.setBorder(0);
        cell.setFixedHeight(20);
        signatureBlock.addCell(cell);

        cell = writeContentToCell("Authorised Signatory", Element.ALIGN_LEFT, 1, 1);
        cell.setBorder(0);

        signatureBlock.addCell(cell);

        caption = "";
        cell = writeContentToCell("", Element.ALIGN_LEFT, 1, 1);
        cell.setBorder(0);
        cell.setFixedHeight(20);
        signatureBlock.addCell(cell);

        signatureBlock.setWidths(new int[]{100});
        cell = new PdfPCell(signatureBlock);
        cell.setBorder(0);
        termsBlock.addCell(cell);

        finalBlock.addCell(termsBlock);

        objPdfGen.addTable(finalBlock);
    }

    public PdfPCell writeContentToCell(String content, int alignment, int colspan, int rowspan) {
        Font objFont6 = new Font();
        objFont6.setSize(6);
        objFont6.setFamily("arial");
        PdfPCell cell = new PdfPCell(new Phrase(content, objFont6));
        if (content.equalsIgnoreCase("")) {
            cell.setFixedHeight(15);
        }
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setRowspan(rowspan);
        cell.setColspan(colspan);
        cell.setHorizontalAlignment(alignment);
        return cell;
    }

    public void setFooter(Map mp, NpsPdfFileGenerator objPdfGen) throws Exception {

        PdfPTable adddescdtl = new PdfPTable(2);

        caption = "";
        adddescdtl.addCell(writeContentToBorderLessCell("Head Office Address", Element.ALIGN_CENTER, 2, 1));
        caption = "Block No 901& 902, 6th Floor B Tower, Udhna Udhyognagar Sangh Commercial Complex, Central Road No 10, Udhna, Surat-394210";
        adddescdtl.addCell(writeContentToBorderLessCell(caption, Element.ALIGN_CENTER, 2, 1));

        PdfPTable mstadddescdtl = new PdfPTable(1);
        mstadddescdtl.addCell(adddescdtl);
        objPdfGen.addTable(mstadddescdtl);
    }
}
