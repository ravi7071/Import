/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.commons.util;

import finpack.FinPack;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 * @author roshan4
 */
public class CommonMemberLog {

    //No of records to be displayed
//    public static String strErrorLogFilePath = "/home/roshan4/NetBeansProjects/enpstest/";
    public static String strErrorLogFilePath = System.getProperty("catalina.home") + "/webapps/enps/";
//    public static String strErrorTempLogFilePathNormalData = System.getProperty("catalina.home") + "/webapps/eNPS/EODNormalData";
    //Function for writing to file

    public static void appendLog(String data) {
        finutils.errorhandler.ErrorHandler.PrintInLog(strErrorLogFilePath, data);
    }

    public static void appendLog(String data, boolean logFlag) {
        if (logFlag) {
            finutils.errorhandler.ErrorHandler.PrintInLog(strErrorLogFilePath, data);
        }
    }

    public static void appendLogFile(String data) {
        appendLog(data);
    }

    public static void appendLogFile(String data, boolean logFlag) {
        appendLog(data, logFlag);
    }

    public static void appendLog(Exception e, String data) {
        finutils.errorhandler.ErrorHandler.PrintInFile(e, strErrorLogFilePath, data);
    }

//    public static void appendLogTempNormalData(String data)
//    {
//        PrintInLogTempNormal(strErrorTempLogFilePathNormalData, data);
//    }
    public static void appendLogFileWithReplaceSPStoMAP(String data, final Map mp) {
        Iterator it = mp.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            data = data.replaceAll(":" + pair.getKey(), "'" + pair.getValue() + "'");
        }
        finutils.errorhandler.ErrorHandler.PrintInLog(strErrorLogFilePath, data);
    }

    public static void appendLogFileWithReplaceSPStoMAP(String data, final Map mp, boolean logFlag) {
        if (logFlag) {
            Iterator it = mp.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry) it.next();
                data = data.replaceAll(":" + pair.getKey(), "'" + pair.getValue() + "'");
            }
            finutils.errorhandler.ErrorHandler.PrintInLog(strErrorLogFilePath, data);
        }
    }

    public static void appendLogFileWithReplaceSPStoBean(String data, final Object obj) throws SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Field[] fields = obj.getClass().getDeclaredFields();
        Map<String, Object> map = new HashMap<>();
        for (Field f : fields) {
            String sString = f.getName();
            Method declaredMethod = obj.getClass().getDeclaredMethod("get" + Character.toString(sString.charAt(0)).toUpperCase() + sString.substring(1));
            map.put(f.getName(), declaredMethod.invoke(obj));
        }
        appendLogFileWithReplaceSPStoMAP(data, map);
    }

    public static void appendLogFileWithReplaceSPStoBean(String data, final Object obj, boolean logFlag) throws SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        if (logFlag) {
            Field[] fields = obj.getClass().getDeclaredFields();
            Map<String, Object> map = new HashMap<>();
            for (Field f : fields) {
                String sString = f.getName();
                Method declaredMethod = obj.getClass().getDeclaredMethod("get" + Character.toString(sString.charAt(0)).toUpperCase() + sString.substring(1));
                map.put(f.getName(), declaredMethod.invoke(obj));
            }
            appendLogFileWithReplaceSPStoMAP(data, map);
        }
    }

    private static String getDateTemp() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.DAY_OF_MONTH) + "-" + (c.get(Calendar.MONTH) + 1) + "-" + c.get(Calendar.YEAR);
    }

    public static void PrintInLogTempNormal(String strFileName, String strData) {
        String path = null;
        try {
            String[] pathArray = strFileName.split("/");
            path = FinPack.getProperty("tomcat1_path") + "/webapps/log/log/" + pathArray[5] + "-log-" + getDateTemp() + ".txt";
            File f = new File(path);

            FileWriter fw = new FileWriter(f, true);

            PrintWriter pw = new PrintWriter(fw);
            pw.println("---------- Date : " + Calendar.getInstance().getTime());
            pw.println(strData);
            pw.close();
            fw.close();
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
    }
}
