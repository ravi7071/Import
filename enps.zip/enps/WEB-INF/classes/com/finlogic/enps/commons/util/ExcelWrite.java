package com.finlogic.enps.commons.util;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.*;
import jxl.Workbook;
import jxl.write.*;

/**
 *
 * @author njuser
 */
public class ExcelWrite extends ExcelWriteMulti
{

    String filename;
    //--added by rutvij
    //--added by rutvij ends
    public WritableSheet sheet;
    public File _file = null;
    public WritableWorkbook workbook = null;

    public ExcelWrite() throws IOException
    {
        super();
    }

    public ExcelWrite(String fileName) throws IOException
    {

        this.filename = fileName;
        _file = new File(fileName);
        workbook = Workbook.createWorkbook(_file);
        super.ExcelWriteMulti(workbook, _file, 0);
    }

    public void ExcelWrite(String fileName, int i) throws IOException
    {

//        this.filename = fileName;
        super.ExcelWriteMulti(workbook, _file, i);
    }

    public void extend()
    {
    }

    public WritableSheet getSheet()
    {
        return sheet;
    }

    public void setSheet(WritableSheet sheet)
    {
        this.sheet = sheet;
    }

    public String getFilename()
    {
        return filename;
    }

    public void setFilename(String filename)
    {
        this.filename = filename;
    }

    public File getFile()
    {
        return _file;
    }

    public void setFile(File _file)
    {
        this._file = _file;
    }
    //finally write the prepared  workbook to the file and close the object

    public void writeworkbook() throws IOException, WriteException
    {
        workbook.write();
        workbook.close();
    }
}
