/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.commons.config;

import com.finlogic.enps.commons.util.CommonMemberLog;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author ankur7
 */
public class GlobalExceptionHandler implements HandlerExceptionResolver, Ordered {

    @Override
    public ModelAndView resolveException(HttpServletRequest request,
            HttpServletResponse response, Object controllerClass, Exception exception) {
        ModelAndView mav = new ModelAndView("apperror");
        CommonMemberLog.appendLog("Exception in eNps==>" + Pagging.CommonFunctions.getErrorStack(exception));
        return mav;
    }

    @Override
    public int getOrder() {
        return -1;
    }

}
