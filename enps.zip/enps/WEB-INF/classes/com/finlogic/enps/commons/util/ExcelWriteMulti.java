package com.finlogic.enps.commons.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.imageio.ImageIO;
import jxl.CellView;
import jxl.WorkbookSettings;
import jxl.write.DateTime;
import jxl.write.Label;
import jxl.write.NumberFormat;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableImage;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author njuser
 */
public class ExcelWriteMulti {

    private String filename;
    private WorkbookSettings ws;
//    private WritableWorkbook workbook;
    private WritableSheet sheet;
    private WritableCellFormat subtitlecf;
    private WritableCellFormat bottomnumbercf_right;
    private WritableCellFormat bottomnumbercfCenter;
    private WritableCellFormat contentnumbercf_right2;
    private WritableCellFormat contentnumbercf_right0;
    private WritableCellFormat contentnumbercf_right1;
    private WritableCellFormat contentnumbercf_right3;
    private WritableCellFormat contentnumbercf_left2;
    private WritableCellFormat contentnumbercf_left0;
    private WritableCellFormat contentnumbercf_left1;
    private WritableCellFormat contentnumbercf_left3;
    private WritableCellFormat contentnumbercf_right2fontcolor;
    private WritableCellFormat contentnumbercf_right0fontcolor;
    private WritableCellFormat contentnumbercf_right1fontcolor;
    private WritableCellFormat contentnumbercf_right3fontcolor;
    private WritableCellFormat contentnumbercf_left2fontcolor;
    private WritableCellFormat contentnumbercf_left0fontcolor;
    private WritableCellFormat contentnumbercf_left1fontcolor;
    private WritableCellFormat contentnumbercf_left3fontcolor;
    private WritableCellFormat contentnumbercf_right2_bold;
    private WritableCellFormat contentnumbercf_right0_bold;
    private WritableCellFormat contentnumbercf_right1_bold;
    private WritableCellFormat contentnumbercf_right3_bold;
    private WritableCellFormat contentnumbercfCenter2;
    private WritableCellFormat contentnumbercfCenter3;
    private WritableCellFormat contentnumbercfCenter4;
    private WritableCellFormat contentnumbercfCenter_font_color;
    private WritableCellFormat contentstringcf_left;
    private WritableCellFormat contentstringcf_left_bold;
    private WritableCellFormat contentstringcf_left_font_color;
    private WritableCellFormat contentstringcf_right;
    private WritableCellFormat contentstringcf_right_font_color;
    private WritableCellFormat contentstringcfCenter;
    private WritableCellFormat headercf;//=new WritableCellFormat(new WritableFont(WritableFont.TIMES,10, WritableFont.BOLD));
    private WritableCellFormat titlecf;//=new WritableCellFormat(new WritableFont(WritableFont.TIMES,10, WritableFont.BOLD));
    private WritableCellFormat topstringcf;//=new WritableCellFormat(new WritableFont(WritableFont.TIMES,8, WritableFont.BOLD));
    private WritableCellFormat topnumbercf;//=new WritableCellFormat(new WritableFont(WritableFont.TIMES,8, WritableFont.BOLD));
    private WritableCellFormat bottomstringcf;//=new WritableCellFormat(new WritableFont(WritableFont.TIMES,8, WritableFont.BOLD));
    private WritableCellFormat bottomnumbercf;//=new WritableCellFormat(new WritableFont(WritableFont.TIMES,8, WritableFont.BOLD));
    private WritableCellFormat contentnumbercf;//=new WritableCellFormat(new WritableFont(WritableFont.TIMES,8, WritableFont.NO_BOLD));
    private WritableCellFormat contentstringcf;//=new WritableCellFormat(new WritableFont(WritableFont.TIMES,8, WritableFont.NO_BOLD));
    private WritableCellFormat contentstringfontcolcf;//=new WritableCellFormat(new WritableFont(WritableFont.TIMES,8, WritableFont.NO_BOLD));
    private WritableCellFormat contentcentercf;//=new WritableCellFormat(new WritableFont(WritableFont.TIMES,8, WritableFont.NO_BOLD));
    private WritableCellFormat cf1;
    private WritableCellFormat cffontcolor;
    private WritableCellFormat cf2;
    private WritableCellFormat cf3;
    private WritableCellFormat bold;
    private WritableCellFormat leftcontent;

    public ExcelWriteMulti() throws IOException {
    }

    public void ExcelWriteMulti(WritableWorkbook workbook, File f, int i) throws IOException {
        //initialization of file,wokbook,sheet
        this.filename = filename;
        ws = new WorkbookSettings();
        ws.setLocale(new Locale("en", "EN"));

//        File f = new File(this.filename);
        try {
            //initilization of font formats
            /*
             * ------------------------Added By Rutvij---------------------------
             */
            NumberFormat nf2 = new NumberFormat("0.00");
            NumberFormat nf3 = new NumberFormat("0.000");
            NumberFormat nf4 = new NumberFormat("0");
            NumberFormat nf1 = new NumberFormat("0.0");

            bottomnumbercf_right = new WritableCellFormat(nf2);
            bottomnumbercf_right.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            bottomnumbercf_right.setAlignment(jxl.format.Alignment.RIGHT);
            bottomnumbercf_right.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            bottomnumbercfCenter = new WritableCellFormat(nf2);
            bottomnumbercfCenter.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            bottomnumbercfCenter.setAlignment(jxl.format.Alignment.CENTRE);
            bottomnumbercfCenter.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right2 = new WritableCellFormat(nf2);
            contentnumbercf_right2.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_right2.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right2.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right0 = new WritableCellFormat(nf4);
            contentnumbercf_right0.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_right0.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right0.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right3 = new WritableCellFormat(nf3);
            contentnumbercf_right3.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_right3.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right3.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right1 = new WritableCellFormat(nf1);
            contentnumbercf_right1.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_right1.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right1.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_left2 = new WritableCellFormat(nf2);
            contentnumbercf_left2.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_left2.setAlignment(jxl.format.Alignment.LEFT);
            contentnumbercf_left2.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_left0 = new WritableCellFormat(nf4);
            contentnumbercf_left0.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_left0.setAlignment(jxl.format.Alignment.LEFT);
            contentnumbercf_left0.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_left3 = new WritableCellFormat(nf3);
            contentnumbercf_left3.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_left3.setAlignment(jxl.format.Alignment.LEFT);
            contentnumbercf_left3.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_left1 = new WritableCellFormat(nf1);
            contentnumbercf_left1.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_left1.setAlignment(jxl.format.Alignment.LEFT);
            contentnumbercf_left1.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right2fontcolor = new WritableCellFormat(nf2);
            contentnumbercf_right2fontcolor.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_right2fontcolor.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right2fontcolor.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right0fontcolor = new WritableCellFormat(nf4);
            contentnumbercf_right0fontcolor.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_right0fontcolor.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right0fontcolor.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right3fontcolor = new WritableCellFormat(nf3);
            contentnumbercf_right3fontcolor.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_right3fontcolor.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right3fontcolor.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right1fontcolor = new WritableCellFormat(nf1);
            contentnumbercf_right1fontcolor.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_right1fontcolor.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right1fontcolor.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_left2fontcolor = new WritableCellFormat(nf2);
            contentnumbercf_left2fontcolor.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_left2fontcolor.setAlignment(jxl.format.Alignment.LEFT);
            contentnumbercf_left2fontcolor.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_left0fontcolor = new WritableCellFormat(nf4);
            contentnumbercf_left0fontcolor.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_left0fontcolor.setAlignment(jxl.format.Alignment.LEFT);
            contentnumbercf_left0fontcolor.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_left3fontcolor = new WritableCellFormat(nf3);
            contentnumbercf_left3fontcolor.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_left3fontcolor.setAlignment(jxl.format.Alignment.LEFT);
            contentnumbercf_left3fontcolor.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_left1fontcolor = new WritableCellFormat(nf1);
            contentnumbercf_left1fontcolor.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf_left1fontcolor.setAlignment(jxl.format.Alignment.LEFT);
            contentnumbercf_left1fontcolor.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right2_bold = new WritableCellFormat(nf2);
            contentnumbercf_right2_bold.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            contentnumbercf_right2_bold.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right2_bold.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right0_bold = new WritableCellFormat(nf4);
            contentnumbercf_right0_bold.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            contentnumbercf_right0_bold.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right0_bold.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right3_bold = new WritableCellFormat(nf3);
            contentnumbercf_right3_bold.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            contentnumbercf_right3_bold.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right3_bold.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercf_right1_bold = new WritableCellFormat(nf1);
            contentnumbercf_right1_bold.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            contentnumbercf_right1_bold.setAlignment(jxl.format.Alignment.RIGHT);
            contentnumbercf_right1_bold.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercfCenter2 = new WritableCellFormat(nf2);
            contentnumbercfCenter2.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercfCenter2.setAlignment(jxl.format.Alignment.CENTRE);
            contentnumbercfCenter2.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercfCenter3 = new WritableCellFormat(nf3);
            contentnumbercfCenter3.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercfCenter3.setAlignment(jxl.format.Alignment.CENTRE);
            contentnumbercfCenter3.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercfCenter4 = new WritableCellFormat(nf4);
            contentnumbercfCenter4.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercfCenter4.setAlignment(jxl.format.Alignment.CENTRE);
            contentnumbercfCenter4.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentnumbercfCenter_font_color = new WritableCellFormat(nf4);
            contentnumbercfCenter_font_color.setFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercfCenter_font_color.setAlignment(jxl.format.Alignment.CENTRE);
            contentnumbercfCenter_font_color.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentstringcf_left = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentstringcf_left.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            contentstringcf_left.setAlignment(jxl.format.Alignment.LEFT);

            contentstringcf_left_bold = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            contentstringcf_left_bold.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            contentstringcf_left_bold.setAlignment(jxl.format.Alignment.LEFT);

            contentstringcf_left_font_color = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            contentstringcf_left_font_color.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            contentstringcf_left_font_color.setAlignment(jxl.format.Alignment.LEFT);

            contentstringcf_right = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentstringcf_right.setAlignment(jxl.format.Alignment.RIGHT);
            contentstringcf_right.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentstringcf_right_font_color = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentstringcf_right_font_color.setAlignment(jxl.format.Alignment.RIGHT);
            contentstringcf_right_font_color.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentstringcfCenter = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentstringcfCenter.setAlignment(jxl.format.Alignment.CENTRE);
            contentstringcfCenter.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
            contentstringcfCenter.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            contentstringfontcolcf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentstringfontcolcf.setAlignment(jxl.format.Alignment.CENTRE);
            contentstringfontcolcf.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
            contentstringfontcolcf.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            subtitlecf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            subtitlecf.setAlignment(jxl.format.Alignment.LEFT);
            subtitlecf.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            /*
             * ------------------------Added By Rutvij Ends---------------------------
             */

            headercf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD));
            headercf.setAlignment(jxl.format.Alignment.CENTRE);
            titlecf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD));
            titlecf.setAlignment(jxl.format.Alignment.LEFT);

            topstringcf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            topstringcf.setAlignment(jxl.format.Alignment.CENTRE);
            topstringcf.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
            topstringcf.setWrap(true);
            topstringcf.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);//sets border to header cells

            topnumbercf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            topnumbercf.setAlignment(jxl.format.Alignment.CENTRE);
            topnumbercf.setWrap(true);
            bottomstringcf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            bottomstringcf.setAlignment(jxl.format.Alignment.LEFT);
            bottomnumbercf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            bottomnumbercf.setAlignment(jxl.format.Alignment.RIGHT);

            contentnumbercf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentnumbercf.setAlignment(jxl.format.Alignment.CENTRE);
            contentnumbercf.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            contentstringcf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentstringcf.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            contentstringcf.setAlignment(jxl.format.Alignment.CENTRE);
            contentstringfontcolcf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentstringfontcolcf.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            contentstringfontcolcf.setAlignment(jxl.format.Alignment.CENTRE);
            contentcentercf = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            contentcentercf.setAlignment(jxl.format.Alignment.CENTRE);

            jxl.write.DateFormat df = new jxl.write.DateFormat("dd-MM-yyyy");
            jxl.write.DateFormat df1 = new jxl.write.DateFormat("dd/MM/yyyy");
            cf1 = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD), df1);
            cf1.setAlignment(jxl.format.Alignment.CENTRE);
            cf1.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            cffontcolor = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD), df1);
            cffontcolor.setAlignment(jxl.format.Alignment.CENTRE);
            cffontcolor.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            cf2 = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD), df);
            cf2.setAlignment(jxl.format.Alignment.CENTRE);
            cf2.setBackground(jxl.format.Colour.RED);
            cf2.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            cf3 = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD), df);
            cf3.setAlignment(jxl.format.Alignment.CENTRE);
            cf3.setBackground(jxl.format.Colour.RED);
            cf3.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

            bold = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));
            bold.setAlignment(jxl.format.Alignment.CENTRE);
            leftcontent = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            leftcontent.setAlignment(jxl.format.Alignment.LEFT);
            leftcontent.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        } catch (Exception e) {
            CommonMemberLog.appendLogFile(e.toString());
        }

        sheet = workbook.createSheet("Sheet" + i, i);
    }

    //celladdresses are  passed for merging purpose
    public void writeheadwithlogo(int startcolumn, int startrow, int endcolumn, int endrow, String head, String path) throws WriteException {
        //TODO remove using parameter
        WritableImage wi = new WritableImage(0.5, 0.5, 4, 3, new File(path));
        sheet.addImage(wi);
        WritableCellFormat hcf = new WritableCellFormat();
        hcf.setBackground(jxl.format.Colour.RED);
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, head, hcf));

    }
    //celladdresses are  passed for merging purpose

    public void writefoot(int startcolumn, int startrow, int endcolumn, int endrow, String head) throws WriteException {

        //sheet.addImage(wi);
        WritableCellFormat hcf = new WritableCellFormat();
        hcf.setBackground(jxl.format.Colour.RED);
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, head, hcf));

    }
    //celladdresses are  passed for merging purpose

    public void writeheader(int startcolumn, int startrow, int endcolumn, int endrow, String head) throws WriteException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, head, headercf));
    }
    //celladdresses are  passed for merging purpose

    public void writetitle(int startcolumn, int startrow, int endcolumn, int endrow, String head) throws WriteException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, head, titlecf));
    }

    //top row(without mergin+string)
    public void writestringtop(int column, int row, String content) throws WriteException {
        sheet.addCell(new Label(column, row, content, topstringcf));
    }
    //top row for the report(with merging)

    public void writestringtop(int startcolumn, int startrow, int endcolumn, int endrow, String content) throws WriteException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, content, topstringcf));
    }

    public void writestringCenter(int startcolumn, int startrow, int endcolumn, int endrow, String content) throws WriteException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, content, topstringcf));
    }

    //top row for the report(without merging array)
    public void writestringtop(int startcolumn, int startrow, String[] content) throws WriteException {
        int c = startcolumn;
        for (int i = 0; i < content.length; i++) {
            sheet.addCell(new Label(c, startrow, content[i], topstringcf));
            c++;
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////
    //bottom row for the report(with merging)
    public void writestringbottom(int startcolumn, int startrow, int endcolumn, int endrow, String content) throws WriteException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, content, bottomstringcf));
    }

    // for writing unbold content added by hardik kahar
    public void writestringcontent_unbold(int startcolumn, int startrow, int endcolumn, int endrow, String content) throws WriteException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, content, contentstringcf));
    }

    //bottom row  for the report(without merging+array)
    public void writestringbottom(int startcolumn, int startrow, String[] content) throws WriteException {
        int c = startcolumn;
        for (int i = 0; i < content.length; i++) {
            sheet.addCell(new Label(c, startrow, content[i], bottomstringcf));
            c++;
        }
    }

    //bottom row(without mergin+string)
    public void writestringbottom(int column, int row, String content) throws WriteException {
        sheet.addCell(new Label(column, row, content, bottomstringcf));
    }
    //bottom row for the report(with merging)
    /////////////////////////////////////////////////////////////////////////////////////

    ////////////////////////////////////////////////////////////////////////////////////
    public void writenumberbottom(int startcolumn, int startrow, int endcolumn, int endrow, Double content) throws WriteException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new jxl.write.Number(startcolumn, startrow, content, bottomnumbercf));

        //sheet.addCell(new Label(startcolumn, startrow, content, bottomnumbercf));
    }

    //bottom row  for the report(without merging array)
    public void writenumberbottom(int startcolumn, int startrow, String[] content) throws WriteException {
        int c = startcolumn;
        for (int i = 0; i < content.length; i++) {
            sheet.addCell(new Label(c, startrow, content[i], bottomnumbercf));
            c++;
        }
    }

    //bottom row(without mergin string)
    public void writenumberbottom(int column, int row, Double content) throws WriteException {
        //sheet.addCell(new Label(column, row, content, bottomnumbercf));
        sheet.addCell(new jxl.write.Number(column, row, content, bottomnumbercf));
        //sheet.addCell(new Number(column, row++,content, widecellscf));
    }
    ///////////////////////////////////////////////////////////////////////////////////////

    //actual content
    public void writestringcontent(int column, int row, String content) throws WriteException {
        sheet.addCell(new Label(column, row, content, contentstringcf));
    }

    public void writestringcontentCenter(int column, int row, String content) throws WriteException, IOException {
        Label l = new Label(column, row, "", cellWithoutBorderColor("center")); //contentstringcfCenter
        l.setString(content);
        sheet.addCell(l);
    }

    public void writestringcontentCenterFontColor(int column, int row, String content, String color) throws WriteException, IOException {
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        contentstringfontcolcf.setFont(font);
        Label l = new Label(column, row, "", contentstringfontcolcf);
        l.setString(content);
        sheet.addCell(l);
    }

    public void writestringcontentCenterSingleFontColor(int column, int row, String content, String color) throws WriteException, IOException {
        WritableCellFormat contentstringcf_left_font_color2 = new WritableCellFormat();
        contentstringcf_left_font_color2.setAlignment(jxl.format.Alignment.CENTRE);

        contentstringcf_left_font_color2.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
        contentstringcf_left_font_color2.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        contentstringcf_left_font_color2.setFont(font);
        Label l = new Label(column, row, "", contentstringcf_left_font_color2);
        l.setString(content);

        sheet.addCell(l);
    }

    public void writestringcontentCenterSingleFontColorWithBackGround(int column, int row, String content, String color) throws WriteException, IOException {
        WritableCellFormat contentstringcf_left_font_color2 = new WritableCellFormat();
        contentstringcf_left_font_color2.setAlignment(jxl.format.Alignment.CENTRE);

        contentstringcf_left_font_color2.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
        contentstringcf_left_font_color2.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        contentstringcf_left_font_color2.setBackground(jxl.format.Colour.GRAY_25);
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        contentstringcf_left_font_color2.setFont(font);
        Label l = new Label(column, row, "", contentstringcf_left_font_color2);
        l.setString(content);

        sheet.addCell(l);
    }

    public jxl.format.Colour getColor(String color) {
        jxl.format.Colour col = jxl.format.Colour.WHITE;

        if (color.equalsIgnoreCase("red")) {
            col = jxl.format.Colour.RED;
        } else if (color.equalsIgnoreCase("blue")) {
            col = jxl.format.Colour.BLUE;
        } else if (color.equalsIgnoreCase("green")) {
            col = jxl.format.Colour.GREEN;
        } else if (color.equalsIgnoreCase("white")) {
            col = jxl.format.Colour.WHITE;
        } else if (color.equalsIgnoreCase("black")) {
            col = jxl.format.Colour.BLACK;
        } else if (color.equalsIgnoreCase("orange")) {
            col = jxl.format.Colour.ORANGE;
        } else if (color.equalsIgnoreCase("gray_80")) {
            col = jxl.format.Colour.GRAY_80;
        } else if (color.equalsIgnoreCase("gray_50")) {
            col = jxl.format.Colour.GRAY_50;
        } else if (color.equalsIgnoreCase("gray_25")) {
            col = jxl.format.Colour.GRAY_25;
        } else if (color.equalsIgnoreCase("indigo")) {
            col = jxl.format.Colour.INDIGO;
        } else if (color.equalsIgnoreCase("BRIGHT_GREEN")) {
            col = jxl.format.Colour.BRIGHT_GREEN;
        }
        return col;
    }

    public void writestringcontentcolor(int column, int row, String content, String color) throws WriteException {
        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        format.setAlignment(jxl.format.Alignment.LEFT);
        format.setBackground(getColor(color));
        sheet.addCell(new Label(column, row, content, format));
    }

    public void writenumbercontent(int column, int row, Double content) throws WriteException {
        //sheet.addCell(new Label(column, row, content, contentnumbercf));
        sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf));
    }

    public void writenumbercontentcolor(int column, int row, Double content, String color) throws WriteException {
        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        format.setAlignment(jxl.format.Alignment.RIGHT);
        format.setBackground(getColor(color));
        //sheet.addCell(new Label(column, row, content, contentnumbercf));
        sheet.addCell(new jxl.write.Number(column, row, content, format));
    }

    public void writeLeftAlignedContent(int col, int row, String content) throws WriteException {
        sheet.addCell(new Label(col, row, content, leftcontent));
    }

    public void writecentercontent(int column, int row, String content) throws WriteException {
        //sheet.addCell(new Label(column, row, content, contentnumbercf));
        sheet.addCell(new Label(column, row, content, contentcentercf));
    }
    ///new added

    public void writeBoldContent(int col, int row, String content) throws WriteException {
        sheet.addCell(new Label(col, row, content, bold));
    }

    public void writeHeaderBackGroundColor(int col, int row, String content, String color) throws WriteException, IOException {
        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));

        format.setBackground(this.getColor(color));
        format.setAlignment(jxl.format.Alignment.CENTRE);

//         format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD));
        font.setColour(new ExcelWrite().getColor("white"));
        format.setFont(font);

        sheet.addCell(new Label(col, row, content, format));

    }

    // Added By Nirav Desai
    public void writeHeaderBackGroundColorForDecimal(int col, int row, BigDecimal content, String color) throws WriteException, IOException {
        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));

        format.setBackground(this.getColor(color));
        format.setAlignment(jxl.format.Alignment.RIGHT);

//         format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(new ExcelWrite().getColor("white"));
        format.setFont(font);

        sheet.addCell(new jxl.write.Number(col, row, content.doubleValue(), format));
    }

    // Added by Nirav Desai for Rquest No : 32461 ------- Start --------
    public void writeHeaderBackGroundColor_Colspan_Rowspan(int startcolumn, int startrow, int endcolumn, int endrow, String content, String color) throws WriteException, IOException {
        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));

        format.getNumberFormat();
        format.setBackground(this.getColor(color));
        format.setAlignment(jxl.format.Alignment.CENTRE);
        format.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
        format.setWrap(true);

        format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD));

        font.setColour(new ExcelWrite().getColor("white"));
        format.setFont(font);

        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, content, format));
    }

    public void writeImage(File imgFile, int column, int row, int widthInColumns, int heightInRows) throws WriteException, IOException {
        BufferedImage input = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            input = ImageIO.read(imgFile);
            ImageIO.write(input, "JPG", baos);
            sheet.addImage(new WritableImage(column, row, widthInColumns / 65,
                    heightInRows / 30, baos.toByteArray()));
        } finally {
            if (input != null) {
                input.flush();
            }
            baos.close();
        }
    }
    // Added by Nirav Desai for Rquest No : 32461 ------- End --------

    public void setColumnWidth(int col, int size) //pass value like 10000;sets the width of column number passed
    {
        CellView cv = new CellView();//use this to Increase column span of the column
        cv.setSize(size);
        sheet.setColumnView(col, cv);
    }

    public void addDate1(int col, int row, String dtStr) throws WriteException, java.text.ParseException, java.text.ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        //String dateString = "2010-7-16";
        Date myDate = formatter.parse(dtStr);
        SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy");
        String myDateString = formatter2.format(myDate);
        sheet.addCell(new DateTime(col, row, myDate, contentstringcf));
//        sheet.addCell(new Label(col, row, myDateString, contentstringcf));
    }

    public void addDate_font_Color(int col, int row, String dtStr, String color) throws WriteException, java.text.ParseException, java.text.ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        //String dateString = "2010-7-16";
        Date myDate = formatter.parse(dtStr);
        SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy");
        String myDateString = formatter2.format(myDate);
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        contentstringfontcolcf.setFont(font);
        sheet.addCell(new Label(col, row, myDateString, contentstringfontcolcf));
    }

    public void addDate(int col, int row, String dtStr, String expfor) throws java.text.ParseException, WriteException {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat(expfor);
            Date myDate = formatter.parse(dtStr);
            sheet.addCell(new DateTime(col, row, myDate, cf1));
        } catch (Exception e) {
//            if (expfor.equalsIgnoreCase("Report")) {
//                sheet.addCell(new Label(col, row, "", cf1));
//            } else {
            sheet.addCell(new Label(col, row, "N/A", cf1)); //adds NA when no date or invalid date is present
//            }
        }
    }

    public void addDateFontColor(int col, int row, String dtStr, String expfor, String color) throws java.text.ParseException, WriteException {
        try {
            WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
            font.setColour(this.getColor(color));
            cffontcolor.setFont(font);
            SimpleDateFormat formatter = new SimpleDateFormat(expfor);
            Date myDate = formatter.parse(dtStr);
            sheet.addCell(new DateTime(col, row, myDate, cffontcolor));
        } catch (Exception e) {
//            if (expfor.equalsIgnoreCase("Report")) {
//                sheet.addCell(new Label(col, row, "", cf1));
//            } else {
            sheet.addCell(new Label(col, row, "N/A", cffontcolor)); //adds NA when no date or invalid date is present
//            }
        }
    }

    public void addDateColor(int col, int row, String dtStr, String expfor, String color) throws java.text.ParseException, WriteException {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat(expfor);
            Date myDate = formatter.parse(dtStr);
            sheet.addCell(new DateTime(col, row, myDate, cf2));
        } catch (Exception e) {
//            if (expfor.equalsIgnoreCase("Report")) {
//                sheet.addCell(new Label(col, row, "", cf2));
//            } else {
            sheet.addCell(new Label(col, row, "", cf2)); //adds NA when no date or invalid date is present
//            }
        }
    }

    /*
     * =====Added By Rutvij========
     */
    public void writesubtitle(int startcolumn, int startrow, int endcolumn, int endrow, String head) throws WriteException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, head, subtitlecf));
    }

    public void writestringcontent_left(int column, int row, String content) throws WriteException, IOException {
        sheet.addCell(new Label(column, row, content, cellWithoutBorderColor("left")));//contentstringcf_left
    }

    public void writestringcontent_left_bold(int startcolumn, int startrow, int endcolumn, int endrow, String content) throws WriteException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, content, contentstringcf_left_bold));
    }

    public void writestringcontent_left_font_color(int column, int row, String content, String color) throws WriteException, IOException {
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        contentstringcf_left_font_color.setFont(font);
        sheet.addCell(new Label(column, row, content, contentstringcf_left_font_color));
    }

    public void writestringcontent_Single_left_font_color(int column, int row, String content, String color) throws WriteException, IOException {

        WritableCellFormat contentstringcf_left_font_color2 = new WritableCellFormat();
        contentstringcf_left_font_color2.setAlignment(jxl.format.Alignment.LEFT);

        contentstringcf_left_font_color2.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
        contentstringcf_left_font_color2.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

        WritableFont font = new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD);

        font.setColour(new ExcelWrite().getColor(color));
        contentstringcf_left_font_color2.setFont(font);

        sheet.addCell(new Label(column, row, content, contentstringcf_left_font_color2));
    }

    public void writestringcontent_Single_left_font_color_colspan_rowspan(int startColumn, int startRow, int endColumn, int endRow, String content, String color) throws WriteException, IOException {

        WritableCellFormat contentstringcf_left_font_color2 = new WritableCellFormat();
        contentstringcf_left_font_color2.setAlignment(jxl.format.Alignment.LEFT);

        contentstringcf_left_font_color2.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
        contentstringcf_left_font_color2.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);

        WritableFont font = new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD);

        font.setColour(new ExcelWrite().getColor(color));
        contentstringcf_left_font_color2.setFont(font);

        sheet.mergeCells(startColumn, startRow, endColumn, endRow);
        sheet.addCell(new Label(startColumn, startRow, content, contentstringcf_left_font_color2));
    }

    /**
     * Description : overloded method
     *
     * @param column
     * @param row
     * @param content
     * @param color
     * @throws WriteException
     * @throws IOException
     */
    public void writestringcontent_Single_left_font_color(int column, int row, Double content, String color) throws WriteException, IOException {

        WritableCellFormat contentstringcf_left_font_color2 = new WritableCellFormat(new jxl.write.NumberFormat("#.###############"));
        contentstringcf_left_font_color2.setAlignment(jxl.format.Alignment.LEFT);
        contentstringcf_left_font_color2.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
        contentstringcf_left_font_color2.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        WritableFont font = new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD);

        font.setColour(new ExcelWrite().getColor(color));
        contentstringcf_left_font_color2.setFont(font);

        sheet.addCell(new jxl.write.Number(column, row, content, contentstringcf_left_font_color2));
    }

    public void writestringcontent_Single_left_font_color_with_backGround(int column, int row, String content, String color) throws WriteException, IOException {

        WritableCellFormat contentstringcf_left_font_color2 = new WritableCellFormat();
        contentstringcf_left_font_color2.setAlignment(jxl.format.Alignment.LEFT);

        contentstringcf_left_font_color2.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
        contentstringcf_left_font_color2.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        contentstringcf_left_font_color2.setBackground(jxl.format.Colour.GRAY_25);
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(new ExcelWrite().getColor(color));
        contentstringcf_left_font_color2.setFont(font);
        sheet.addCell(new Label(column, row, content, contentstringcf_left_font_color2));
    }

    public void writestringcontent_right(int column, int row, String content) throws WriteException, IOException {
        sheet.addCell(new Label(column, row, content, cellWithoutBorderColor("right")));
    }

    public void writestringcontent_right_font_color(int column, int row, String content, String color) throws WriteException {
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        contentstringcf_right_font_color.setFont(font);
        sheet.addCell(new Label(column, row, content, contentstringcf_right_font_color));
    }

    public void writenumbercontent_right_bold(int startcolumn, int startrow, int endcolumn, int endrow, Double content, int round_upto) throws WriteException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        if (round_upto == 2) {
            sheet.addCell(new jxl.write.Number(startcolumn, startrow, content, contentnumbercf_right2_bold));
        }
        if (round_upto == 3) {
            sheet.addCell(new jxl.write.Number(startcolumn, startrow, content, contentnumbercf_right3_bold));
        }
        if (round_upto == 0) {
            sheet.addCell(new jxl.write.Number(startcolumn, startrow, content, contentnumbercf_right0_bold));
        }
        if (round_upto == 1) {
            sheet.addCell(new jxl.write.Number(startcolumn, startrow, content, contentnumbercf_right1_bold));
        }

        //sheet.addCell(new Label(startcolumn, startrow, content, bottomnumbercf));
    }

    public void writenumbercontent_right(int column, int row, Double content, int round_upto) throws WriteException {
        if (round_upto == 2) {
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_right2));
        }
        if (round_upto == 3) {
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_right3));
        }
        if (round_upto == 0) {
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_right0));
        }
        if (round_upto == 1) {
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_right1));
        }
    }

    public void writenumbercontent_left(int column, int row, Double content, int round_upto) throws WriteException {
        if (round_upto == 2) {
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_left2));
        }
        if (round_upto == 3) {
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_left3));
        }
        if (round_upto == 0) {
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_left0));
        }
        if (round_upto == 1) {
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_left1));
        }
    }

    public void writenumbercontent_right_font_color(int column, int row, Double content, int round_upto, String color) throws WriteException {
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        if (round_upto == 2) {
            contentnumbercf_right2fontcolor.setFont(font);
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_right2fontcolor));
        }
        if (round_upto == 3) {
            contentnumbercf_right3fontcolor.setFont(font);
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_right3fontcolor));
        }
        if (round_upto == 0) {
            contentnumbercf_right0fontcolor.setFont(font);
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_right0fontcolor));
        }
        if (round_upto == 1) {
            contentnumbercf_right1fontcolor.setFont(font);
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_right1fontcolor));
        }
    }

    public void writenumbercontent_left_font_color(int column, int row, Double content, int round_upto, String color) throws WriteException {
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        if (round_upto == 2) {
            contentnumbercf_left2fontcolor.setFont(font);
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_left2fontcolor));
        }
        if (round_upto == 3) {
            contentnumbercf_left3fontcolor.setFont(font);
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_left3fontcolor));
        }
        if (round_upto == 0) {
            contentnumbercf_left0fontcolor.setFont(font);
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_left0fontcolor));
        }
        if (round_upto == 1) {
            contentnumbercf_left1fontcolor.setFont(font);
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercf_left1fontcolor));
        }
    }

    public void writenumbercontent_right_color(int column, int row, Double content, int round_upto, String color) throws WriteException {
        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        format.setAlignment(jxl.format.Alignment.RIGHT);
        format.setBackground(getColor(color));
        if (round_upto == 2) {
            sheet.addCell(new jxl.write.Number(column, row, content, format));
        }
        if (round_upto == 3) {
            sheet.addCell(new jxl.write.Number(column, row, content, format));
        }
    }

//    public void writenumbercontent_right_font_color(int column, int row, Double content, int round_upto, String color) throws WriteException
//    {
//        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
//        format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
//        format.setAlignment(jxl.format.Alignment.RIGHT);
//        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
//        font.setColour(this.getColor(color));
//        format.setFont(font);
////        format.setBackground(getColor(color));
//        if (round_upto == 2)
//        {
//            sheet.addCell(new Number(column, row, content, format));
//        }
//        if (round_upto == 3)
//        {
//            sheet.addCell(new Number(column, row, content, format));
//        }
//    }
    public void writenumbercontentCenter(int column, int row, Double content, int round_upto) throws WriteException {
        if (round_upto == 2) {
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercfCenter2));
        }
        if (round_upto == 3) {
            sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercfCenter3));
        }
    }

    public void writenumbercontentCenter(int column, int row, Integer content) throws WriteException {
        sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercfCenter4));
    }

    public void writenumbercontentCenter_font_color(int column, int row, Integer content, String color) throws WriteException {
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        contentnumbercfCenter_font_color.setFont(font);
        sheet.addCell(new jxl.write.Number(column, row, content, contentnumbercfCenter_font_color));
    }

    public void writenumbercontentCenter_font_color_colspan_rowspan(int startcolumn, int startrow, int endcolumn, int endrow, Integer content, String color) throws WriteException {
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        contentnumbercfCenter_font_color.setFont(font);
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new jxl.write.Number(startcolumn, startrow, content, contentnumbercfCenter_font_color));
    }

    public void writenumberbottom_right(int column, int row, Double content) throws WriteException {
        sheet.addCell(new jxl.write.Number(column, row, content, bottomnumbercf_right));
    }

    public void writenumberbottomCenter(int column, int row, Double content) throws WriteException {
        sheet.addCell(new jxl.write.Number(column, row, content, bottomnumbercfCenter));
    }

    /*
     * =====Added By Rutvij Ends========
     */
    public String readCellValue(int column, int row) throws Exception {
//        CommonMember.appendLogFile(sheet.getCell(column, row).getContents());
//        CommonMember.appendLogFile("row=>"+row);
//        CommonMember.appendLogFile("column=>"+column);
        return sheet.getCell(column, row).getContents();
    }

    public void writeContenttocellWithColor(int column, int row, Object content, String color) throws WriteException, IOException {
        if (content != null && content.getClass() != null) {
//            CommonMember.appendLogFile(content.getClass() + "");
            if (content.getClass() == Integer.class) {
                this.writenumbercontentCenter_font_color(column, row, ((Integer) content), color);
            } else if (content.getClass() == BigDecimal.class) {
                this.writeBigdecimalWithColor(column, row, new BigDecimal(content.toString()), color);
            } else if (content.getClass() == String.class) {
                this.writestringcontent_Single_left_font_color(column, row, content.toString(), color);
            }
        }
    }

    public void writeContenttocellWithColor_Colspan_Rowspan(int startColumn, int startRow, int endColumn, int endRow, Object content, String color) throws WriteException, IOException {
        if (content != null && content.getClass() != null) {
//            CommonMember.appendLogFile(content.getClass() + "");
            if (content.getClass() == Integer.class) {
                this.writenumbercontentCenter_font_color_colspan_rowspan(startColumn, startRow, endColumn, endRow, ((Integer) content), color);
            } else if (content.getClass() == BigDecimal.class) {
                this.writeBigdecimalWithColor_colspan_rowspan(startColumn, startRow, endColumn, endRow, new BigDecimal(content.toString()), color);
            } else if (content.getClass() == String.class) {
                this.writestringcontent_Single_left_font_color_colspan_rowspan(startColumn, startRow, endColumn, endRow, content.toString(), color);
            }
        }
    }

    public void writeBigdecimalWithColor(int column, int row, BigDecimal content, String color) throws WriteException {
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        contentstringcf_right_font_color.setFont(font);
        sheet.addCell(new jxl.write.Number(column, row, content.doubleValue(), contentstringcf_right_font_color));
    }

    public void writeBigdecimalWithColor_colspan_rowspan(int startcolumn, int startrow, int endcolumn, int endrow, BigDecimal content, String color) throws WriteException {
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        font.setColour(this.getColor(color));
        contentnumbercfCenter_font_color.setFont(font);
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new jxl.write.Number(startcolumn, startrow, content.doubleValue(), contentnumbercfCenter_font_color));
    }

    public void writeHeaderBackGroundColor_Colspan_Rowspan_SetAlign(int startcolumn, int startrow, int endcolumn, int endrow, String content, String color, String align) throws WriteException, IOException {
        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));

        format.getNumberFormat();
        format.setBackground(this.getColor(color));
        if (align.equalsIgnoreCase("left")) {
            format.setAlignment(jxl.format.Alignment.LEFT);
        }

        if (align.equalsIgnoreCase("right")) {
            format.setAlignment(jxl.format.Alignment.RIGHT);
        }

        format.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
        format.setWrap(true);

        format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD));

        font.setColour(new ExcelWrite().getColor("BLACK"));
        format.setFont(font);

        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, content, format));
    }

    public void writeHeaderBackGroundColorAndFontColor(int col, int row, String content, String color, String fontColor) throws WriteException, IOException {
        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.BOLD));

        format.setBackground(this.getColor(color));
        format.setAlignment(jxl.format.Alignment.CENTRE);

//         format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        WritableFont font = new WritableFont(new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD));
        font.setColour(new ExcelWrite().getColor(fontColor));
        format.setFont(font);

        sheet.addCell(new Label(col, row, content, format));

    }

    //*Column and Rowspan without bold font with left right and Center alignment*//
    //*START*//
    public void writeStringCenter_Colspan_Rowspan(int startcolumn, int startrow, int endcolumn, int endrow, String content) throws WriteException, IOException {
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, content, cellWithoutBorderColor("center")));//contentstringcfCenter
    }

    public void writeStringLeft_Colspan_Rowspan(int startcolumn, int startrow, int endcolumn, int endrow, String content) throws WriteException, IOException {

//        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
//        format.setAlignment(jxl.format.Alignment.LEFT);
//        format.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
//        format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, content, cellWithoutBorderColor("left")));
    }

    public void writeStringRight_Colspan_Rowspan(int startcolumn, int startrow, int endcolumn, int endrow, String content) throws WriteException, IOException {

//        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));;
//        format.setAlignment(jxl.format.Alignment.RIGHT);
//        format.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
//        format.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
        sheet.mergeCells(startcolumn, startrow, endcolumn, endrow);
        sheet.addCell(new Label(startcolumn, startrow, content, cellWithoutBorderColor("right")));
    }
    //*END*//

    public WritableCellFormat cellWithoutBorderColor(String align) throws WriteException, IOException {
        WritableCellFormat format = new WritableCellFormat(new WritableFont(WritableFont.TIMES, 8, WritableFont.NO_BOLD));
        if (align.equalsIgnoreCase("left")) {
            format.setAlignment(jxl.format.Alignment.LEFT);
        } else if (align.equalsIgnoreCase("right")) {
            format.setAlignment(jxl.format.Alignment.RIGHT);
        } else {
            format.setAlignment(jxl.format.Alignment.CENTRE);
        }
        format.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
        return format;
    }
}
