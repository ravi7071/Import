/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.commons.util;

import com.finlogic.enps.session.model.SessionBean;
import com.finlogic.util.disposition.ContentDisposition;
import com.finlogic.util.disposition.ContentDispositionType;
import com.finlogic.util.sbutility.PutFileBean;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.context.ApplicationContext;
import org.springframework.web.servlet.support.RequestContextUtils;

/**
 *
 * @author roshan4
 */
public class CommonFunction {

    public static void transferFileToStorageBox(File sourceFile,
            String destPath) throws Exception {
        SBCommonOperation sbCommon = SBCommonOperation.getSBCommonOperation();
        PutFileBean putBean = new PutFileBean();
        putBean.setSourceFile(sourceFile);
        putBean.setSbDestPath(destPath);
        putBean.setRemoveFromSource(true);
        sbCommon.putFile(putBean);
    }

    public static SessionBean getSessionBean(HttpServletRequest request) {
        ApplicationContext context = RequestContextUtils.getWebApplicationContext(request);
        return context.getBean(SessionBean.class);
    }

    public static void getDownloadFileFromStaorageBox(HttpServletRequest request, HttpServletResponse response, String contenttype, String temp_path) throws Exception {
        if (temp_path != null && !temp_path.equalsIgnoreCase("")) {
            File f = new File(temp_path);
            if (f.exists()) {
                ContentDisposition dis = new ContentDisposition();
                dis.setFilePath(temp_path);
                dis.setResponse(response);
                if (contenttype.equalsIgnoreCase("inline")) {
                    dis.setRequestType(ContentDispositionType.INLINE);
                } else {
                    dis.setRequestType(ContentDispositionType.ATTACHMENT);
                }
                dis.process();
            }
        } else {
            response.setContentType("text/html");
            response.getWriter().println("<div align='center'><b>File Not Found</b></div>");
        }
    }

    public static String getCurrentDate(boolean withtime) {
        Date date = new Date();
        String format = "";
        if (withtime) {
            format = "yyyy/MM/ddHHmmss";
        } else {
            format = "dd/MM/yyyy";
        }
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        return formatter.format(date);
    }

    public static String getIpAddr(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }

        StringBuilder ips = new StringBuilder();
        if (null != ip
                && !"".equals(ip.trim())
                && !"unknown".equalsIgnoreCase(ip)) {
            // get all ips from proxy ip
            String ipArr[] = ip.split(",");

            for (String ipArr1 : ipArr) {
                if ((ips.length() + ipArr1.length()) < 50) {
                    ips.append(ipArr1).append(",");
                }
            }
        }

        if (ips.toString().isEmpty()) {
            ips.append("N/A");
        } else {
            ips = new StringBuilder(ips.substring(0, ips.length() - 1));
        }
        return ips.toString();
    }

    public static void convertImageToFixSize(String inputImagePath,
            String outputImagePath, int scaledWidth, int scaledHeight)
            throws IOException {
        File inputFile = new File(inputImagePath);
        BufferedImage inputImage = ImageIO.read(inputFile);

        BufferedImage outputImage = new BufferedImage(scaledWidth,
                scaledHeight, inputImage.getType());

        byte[] imageBytes = ((DataBufferByte) outputImage.getData().getDataBuffer()).getData();

        Graphics2D g2d = outputImage.createGraphics();
        g2d.drawImage(inputImage, 0, 0, scaledWidth, scaledHeight, null);
        g2d.dispose();

        String formatName = outputImagePath.substring(outputImagePath.lastIndexOf(".") + 1);

        ImageIO.write(outputImage, formatName, new File(outputImagePath));

    }

    public static void deleteFileWithFolder(File file) throws Exception {
        if (file.isDirectory()) {

            //directory is empty, then delete it
            if (file.list().length == 0) {
                file.delete();
            } else {
                //list all the directory contents
                String files[] = file.list();
                for (String temp : files) {
                    //construct the file structure
                    File fileDelete = new File(file, temp);
                    //recursive delete
                    deleteFileWithFolder(fileDelete);
                }
                //check the directory again, if empty then delete it
                if (file.list().length == 0) {
                    file.delete();
                }
            }

        } else {
            //if file, then delete it
            file.delete();

        }
    }

    public static String createCsvFile(String filename, String seperater, List lstdata, boolean withColumnHeader, String columnheader) throws Exception {
        int i = 0, j;
        Map mp = new HashMap();
        ArrayList columnList = new ArrayList();
        String sourceFile = finpack.FinPack.getProperty("tempfiles_path") + "NPS/" + filename + ".csv";
        final FileWriter fileWriter = new FileWriter(sourceFile);
        final PrintWriter printWriter = new PrintWriter(fileWriter);

        if (columnheader.trim().isEmpty()) {
            List<Map<String, String>> lstreport = lstdata;
            if (withColumnHeader) {
                printWriter.print("SN");
                printWriter.print(seperater);
            }

            for (Map<String, String> map : lstreport) {
                for (Map.Entry<String, String> mapEntry : map.entrySet()) {
                    if (withColumnHeader) {
                        printWriter.print(mapEntry.getKey());
                        if (i < map.entrySet().size() - 1) {
                            printWriter.print(seperater);
                        }
                    }
                    columnList.add(mapEntry.getKey());
                    i++;
                }
                break;
            }
        } else {
            String columnarray[] = columnheader.split(",");
            if (withColumnHeader) {
                printWriter.print("SN");
                printWriter.print(seperater);
                for (i = 0; i < columnarray.length; i++) {
                    printWriter.print(columnarray[i]);
                    if (i + 1 < columnarray.length) {
                        printWriter.print(seperater);
                    }
                }
            }
            columnList = new ArrayList(Arrays.asList(columnarray));
        }

        if (withColumnHeader) {
            printWriter.println();
        }
        for (i = 0; i < lstdata.size(); i++) {
            mp = (Map) lstdata.get(i);
            printWriter.print(i + 1);
            printWriter.print(seperater);
            for (j = 0; j < columnList.size(); j++) {
                printWriter.print(mp.get(columnList.get(j)));
                if (j + 1 < columnList.size()) {
                    printWriter.print(seperater);
                }
            }
            printWriter.println();

        }
        printWriter.flush();
        printWriter.close();
        fileWriter.close();
        return sourceFile;
    }

}
