/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.commons.util;

import com.finlogic.util.sbutility.PutFileBean;
import com.finlogic.util.sbutility.SBFileBean;
import com.finlogic.util.sbutility.StorageBoxImpl;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

/**
 *
 * @author roshan4
 */
public class SBCommonOperation extends StorageBoxImpl {

    private static SBCommonOperation sbCommon = new SBCommonOperation();

    private SBCommonOperation() {
        super(120);// Must- provide project id
    }

    public static SBCommonOperation getSBCommonOperation() {
        return sbCommon;
    }

    @Override
    public String getFile(String sbFilePath) throws IllegalArgumentException, UnsupportedEncodingException, IOException {
        return super.getFile(sbFilePath);
    }

    @Override
    public void putFile(PutFileBean putFileBean) throws Exception {
        super.putFile(putFileBean);
    }

    @Override
    public boolean deleteFile(String sbFilePath) throws Exception {
        return super.deleteFile(sbFilePath);
    }

    @Override
    public boolean isFileExist(String sbFilePath) throws Exception {
        return super.isFileExist(sbFilePath);
    }

    @Override
    public List<SBFileBean> getList(String sbFilePath) throws IllegalArgumentException, IOException {
        return super.getList(sbFilePath);
    }
}
