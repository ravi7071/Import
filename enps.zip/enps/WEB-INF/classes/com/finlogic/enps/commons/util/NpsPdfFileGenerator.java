/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.commons.util;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import org.apache.log4j.Logger;

/**
 *
 * @author roshan4
 */
public class NpsPdfFileGenerator {
    public final int ALIGN_LEFT = 0;
    public final int ALIGN_CENTRE = 1;
    public final int ALIGN_RIGHT = 2;

    public Document document;
    public PdfWriter mPdfWriter;

    String p1 = "";
    String p2 = "";

    private static final Logger loger = Logger.getLogger(NpsPdfFileGenerator.class);

    /**
     * Methods
     */
    // --------------------------------------------------------------------------------------------------------------------    
    public NpsPdfFileGenerator() {
    }

    // --------------------------------------------------------------------------------------------------------------------            
    // --------------------------------------------------------------------------------------------------------------------    

    public boolean open(File fileObj) {
        return open(fileObj, false);
    }

    // --------------------------------------------------------------------------------------------------------------------        
    // --------------------------------------------------------------------------------------------------------------------    

    public boolean open(String filename) {
        return open(filename, false);
    }

    // --------------------------------------------------------------------------------------------------------------------    
    // --------------------------------------------------------------------------------------------------------------------    

    public boolean open(OutputStream opStrm) {
        return open(opStrm, false);
    }

    // --------------------------------------------------------------------------------------------------------------------    
    // --------------------------------------------------------------------------------------------------------------------    

    public boolean open(File fileObj, boolean isLandScape) {
    // --------------------------------------------------------------------------------------------------------------------    

        try {
            open(new FileOutputStream(fileObj), isLandScape);
        } catch (IOException ioe) {
            loger.error(" Exception i pdfFileGenerator.java file : Constuctor pdfFileGenerator :" + ioe.getMessage());
            return false;
        }

        return true;

    } // --------------------------------------------------------------------------------------------------------------------       
    // --------------------------------------------------------------------------------------------------------------------    

    public boolean open(String filename, boolean isLandScape) {
    // --------------------------------------------------------------------------------------------------------------------    

        try {
            open(new FileOutputStream(filename), isLandScape);
        } catch (IOException ioe) {
            loger.error(" Exception i pdfFileGenerator.java file : open :" + ioe.getMessage());
            return false;
        }

        return true;

    } // --------------------------------------------------------------------------------------------------------------------    

    // --------------------------------------------------------------------------------------------------------------------    
    public boolean open(OutputStream opStrm, boolean isLandScape) {
    // -------------- ------------------------------------------------------------------------------------------------------    

        document = new Document();

        if (isLandScape) {

            Rectangle rct = document.getPageSize();
            document.setPageSize(new Rectangle(rct.getHeight(), rct.getWidth()));

        }

        try {

            mPdfWriter = PdfWriter.getInstance(document, opStrm);
            if (!(p1.equalsIgnoreCase("") || p1.length() == 0 || p1 == null)) {
                mPdfWriter.setEncryption(true, p1, "FinlogicMasterPassword", PdfWriter.AllowPrinting + PdfWriter.AllowCopy);
                //mPdfWriter.setEncryption(true,p1,"FinlogicMasterPassword",PdfWriter.AllowCopy);
                //mPdfWriter.setEncryption(PdfWriter.STRENGTH128BITS, "hus","hus",0);
                //mPdfWriter.setEncryption(p1.getBytes(),p2.getBytes(),0,true);
            }

            document.open();
        } catch (DocumentException de) {
            loger.error(" Exception i pdfFileGenerator.java file : open :" + de.getMessage());
            return false;
        }

        return true;

    } // --------------------------------------------------------------------------------------------------------------------    

    public void setPassword(String s1, String s2) {

        p1 = s1;
        p2 = s2;
    }

    // --------------------------------------------------------------------------------------------------------------------    

    public void close() {
        document.close();
    }
    // --------------------------------------------------------------------------------------------------------------------    

    // --------------------------------------------------------------------------------------------------------------------    
    public void setPageSize(int width, int height) {
        document.setPageSize(new Rectangle(width, height));
    }
    // --------------------------------------------------------------------------------------------------------------------        

    public void setPageSizeHalf() {
        Rectangle pageSize = new Rectangle(595, 421);
        document.setPageSize(pageSize);
    }

    // --------------------------------------------------------------------------------------------------------------------    
    public void setNewPage() {
    // --------------------------------------------------------------------------------------------------------------------    

        try {
            document.newPage();
        } catch (Exception de) {
            loger.error(" Exception i pdfFileGenerator.java file : setNewPage :" + de.getMessage());
        }
    } // -------------------------------------------------------------------------------------------------------------------    

    // --------------------------------------------------------------------------------------------------------------------    
    public void addLine(String textLine) {
        addLine(textLine, ALIGN_LEFT);
    }

    // --------------------------------------------------------------------------------------------------------------------    
    // --------------------------------------------------------------------------------------------------------------------    

    public void addLine(String textLine, int alignment) {
    // --------------------------------------------------------------------------------------------------------------------    

        try {

            Paragraph p = new Paragraph(textLine);

            switch (alignment) {

                case ALIGN_LEFT:
                    p.setAlignment(p.ALIGN_LEFT);
                    break;
                case ALIGN_RIGHT:
                    p.setAlignment(p.ALIGN_RIGHT);
                    break;
                case ALIGN_CENTRE:
                    p.setAlignment(p.ALIGN_CENTER);
                    break;
            }

            document.add(p);
        } catch (DocumentException de) {
            loger.error(" Exception i pdfFileGenerator.java file : addLine :" + de.getMessage());
        }
    } // -------------------------------------------------------------------------------------------------------------------    

    // --------------------------------------------------------------------------------------------------------------------    
    public void addImage(String filename) {
    // --------------------------------------------------------------------------------------------------------------------            

        try {

            Image imgJpg = Image.getInstance(filename);
            imgJpg.setAlignment(imgJpg.ALIGN_CENTER);
            document.add(imgJpg);       // add image              
        } catch (DocumentException de) {
            loger.error(" Exception i pdfFileGenerator.java file : addImage :" + de.getMessage());
        } catch (Exception e) {
        }

    } // -------------------------------------------------------------------------------------------------------------------    

    // --------------------------------------------------------------------------------------------------------------------    
    public void addImage(java.awt.Image img) {
    // --------------------------------------------------------------------------------------------------------------------            

        try {
            Image imgJpg = Image.getInstance(mPdfWriter, img, 1);
            imgJpg.setAlignment(imgJpg.ALIGN_CENTER);
            document.add(imgJpg);       // add image              
        } catch (DocumentException de) {
            loger.error(" Exception i pdfFileGenerator.java file : addImage :" + de.getMessage());
        } catch (Exception e) {
        }

    } // -------------------------------------------------------------------------------------------------------------------    

    // --------------------------------------------------------------------------------------------------------------------    
    public void addTable(String tabletitle, String[] colTitles, String rowTitle, double[] rowValues) {
        // --------------------------------------------------------------------------------------------------------------------            
        String[][] strRowVals = new String[1][colTitles.length];
        String[] rowTitles = new String[1];

        rowTitles[0] = rowTitle;

        for (int i = 0; i < colTitles.length; i++) {
            strRowVals[0][i] = String.valueOf((int) rowValues[i]);
        }

        addTable(tabletitle, colTitles, rowTitles, strRowVals);
    } // -------------------------------------------------------------------------------------------------------------------    

    // --------------------------------------------------------------------------------------------------------------------    
    public void addTable(String tabletitle, String[] colTitles, String[] rowTitles, double[][] rowValues) {
    // --------------------------------------------------------------------------------------------------------------------            

        String[][] strRowVals = new String[rowValues.length][rowValues[0].length];

        for (int i = 0; i < rowTitles.length; i++) {
            for (int j = 0; j < colTitles.length; j++) {
                strRowVals[i][j] = String.valueOf((int) rowValues[i][j]);
            }
        }

        addTable(tabletitle, colTitles, rowTitles, strRowVals);

    } // -------------------------------------------------------------------------------------------------------------------            

    // --------------------------------------------------------------------------------------------------------------------    
    public void addTable(String tabletitle, String[] colTitles, String[] rowTitles, String[][] rowValues) {
    // --------------------------------------------------------------------------------------------------------------------            

        int rowCnt = rowTitles.length;       // rowValues.length;
        int colCnt = colTitles.length;

        PdfPTable table = new PdfPTable(colCnt + 1);

        PdfPCell cell = new PdfPCell(new Paragraph(tabletitle));
        cell.setColspan(colCnt + 1);
        cell.setHorizontalAlignment(cell.ALIGN_CENTER);

        table.addCell(cell);

        cell = new PdfPCell(new Paragraph("  "));
        cell.setBackgroundColor(new Color(225, 225, 225));
        cell.setHorizontalAlignment(cell.ALIGN_CENTER);
        table.addCell(cell);

        for (int i = 0; i < colCnt; i++) {
            cell = new PdfPCell(new Paragraph(colTitles[i]));
            cell.setBackgroundColor(new Color(225, 225, 225));
            cell.setHorizontalAlignment(cell.ALIGN_CENTER);
            table.addCell(cell);
        }

        for (int i = 0; i < rowCnt; i++) {
            cell = new PdfPCell(new Paragraph(rowTitles[i]));
            cell.setBackgroundColor(new Color(225, 225, 225));
            cell.setHorizontalAlignment(cell.ALIGN_CENTER);
            table.addCell(cell);

            for (int j = 0; j < colCnt; j++) {
                cell = new PdfPCell(new Paragraph(rowValues[i][j]));
                cell.setHorizontalAlignment(cell.ALIGN_RIGHT);
                table.addCell(cell);
            }
        }

        table.setWidthPercentage(100);
        try {
            //addLine(" ");
            document.add(table);
            //addLine(" ");                
        } catch (DocumentException de) {
            loger.error(" Exception i pdfFileGenerator.java file : addTable :" + de.getMessage());
        }

    } // -------------------------------------------------------------------------------------------------------------------        

    // --------------------------------------------------------------------------------------------------------------------    
    public void addTable(PdfPTable table) {
    // --------------------------------------------------------------------------------------------------------------------            

        table.setWidthPercentage(100);
        table.setSpacingAfter(0);
        table.setSpacingBefore(0);
        try {

            document.add(table);

        } catch (DocumentException de) {
            loger.error(" Exception i pdfFileGenerator.java file : addTable :" + de.getMessage());
        }
    }
        
    public boolean open(File fileObj, boolean isLandScape,Map mp) {
    // --------------------------------------------------------------------------------------------------------------------    

        try {
            open(new FileOutputStream(fileObj), isLandScape,mp);
        } catch (IOException ioe) {
            loger.error(" Exception i pdfFileGenerator.java file : Constuctor pdfFileGenerator :" + ioe.getMessage());
            return false;
        }

        return true;

    }
    public boolean open(OutputStream opStrm, boolean isLandScape,Map mp) {
    // -------------- ------------------------------------------------------------------------------------------------------    
        document = new Document();
       
        if (isLandScape) {

            Rectangle rct = document.getPageSize();
            document.setPageSize(new Rectangle(rct.getHeight(), rct.getWidth()));

        }

        try {

            mPdfWriter = PdfWriter.getInstance(document, opStrm);
            if (!(p1.equalsIgnoreCase("") || p1.length() == 0 || p1 == null)) {
                mPdfWriter.setEncryption(true, p1, "FinlogicMasterPassword", PdfWriter.AllowPrinting + PdfWriter.AllowCopy);
                //mPdfWriter.setEncryption(true,p1,"FinlogicMasterPassword",PdfWriter.AllowCopy);
                //mPdfWriter.setEncryption(PdfWriter.STRENGTH128BITS, "hus","hus",0);
                //mPdfWriter.setEncryption(p1.getBytes(),p2.getBytes(),0,true);
            }
        
            document.setPageSize(PageSize.A4);
            document.setMargins(20, 20, 47, 95);//left,right,top,bottom
            
//            mPdfWriter.setPageEvent(new HeaderContent(mp));
            document.open();
    
        
        } catch (DocumentException de) {
            loger.error(" Exception i pdfFileGenerator.java file : open :" + de.getMessage());
            return false;
        }

        return true;

    } 
}
