/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.craexportutility.report;

import com.finlogic.enps.craexportutility.bean.CRAExportUtilityBean;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 *
 * @author roshan4
 */
public interface CRAExportUtilityReport {

    public List<Map<String, String>> getStatusList() throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getReportData(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getStatusDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getPrimaryAddressContactOtherFatcaDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> geteKycAndeSignDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getFatcaTinDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getTierDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getNomineeDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getPaymentDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getBankProof(CRAExportUtilityBean bean, String tier) throws ClassNotFoundException, SQLException;

    public String getReceiptNumber(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getAllowedStatusList(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getDataUsingRefNo(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getEmailData(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List CheckUpdateValidStatus(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getReportPaymentDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getNpsInvoiceAmntDetailContent(Map mp, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getnpsInvoiceDetailContent(Map mp, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException;

    public String getpartner(Map mp) throws ClassNotFoundException, SQLException;

    public String getnpsresgistrationTOemailid(Map mp) throws ClassNotFoundException, SQLException;

    public String getnpsresgistrationCCemailid(Map mp) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getGenerateFileReport(String finalrefid) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getPersonalDtl(String refids) throws ClassNotFoundException, SQLException;

    public List<Map<String, String>> getNpsRegTrxnData(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException;

    public String getAckNumber(String refid) throws ClassNotFoundException, SQLException;
}
