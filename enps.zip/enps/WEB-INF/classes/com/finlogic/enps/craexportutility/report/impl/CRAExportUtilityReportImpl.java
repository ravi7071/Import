/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.craexportutility.report.impl;

import com.finlogic.enps.craexportutility.bean.CRAExportUtilityBean;
import com.finlogic.enps.craexportutility.report.CRAExportUtilityReport;
import com.finlogic.util.persistence.SQLTranUtility;
import com.finlogic.util.persistence.SQLUtility;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "CRAExportUtilityReport")
public class CRAExportUtilityReportImpl implements CRAExportUtilityReport {
    
    @Autowired
    @Qualifier(value = "sqlutility")
    private SQLUtility sqlutil;
    
    private static String ALIAS;
    private static String ekyc_done;
    private static String esign_done;
    private static String payment_received;
    private static String payment_failed;
    private static String payment_pending;
    
    @Value("${enps_db_alias}")
    public void setDbAlias(String dbAlias) {
        CRAExportUtilityReportImpl.ALIAS = dbAlias;
    }
    
    @Value("${ekyc_done}")
    public void setEkycDone(String ekyc_done) {
        CRAExportUtilityReportImpl.ekyc_done = ekyc_done;
    }
    
    @Value("${esign_done}")
    public void setEsignDone(String esign_done) {
        CRAExportUtilityReportImpl.esign_done = esign_done;
    }
    
    @Value("${payment_received}")
    public void setPaymentReceived(String payment_received) {
        CRAExportUtilityReportImpl.payment_received = payment_received;
    }
    
    @Value("${payment_failed}")
    public void setPaymentFailed(String payment_failed) {
        CRAExportUtilityReportImpl.payment_failed = payment_failed;
    }
    
    @Value("${payment_pending}")
    public void setPaymentPending(String payment_pending) {
        CRAExportUtilityReportImpl.payment_pending = payment_pending;
    }
    
    @Override
    public List<Map<String, String>> getStatusList() throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        
        query.append(" SELECT STATUS_ID,STATUS FROM NPS_STATUS_MASTER ")
                .append(" ORDER BY DISPLAY_ORDER ");
        
        return sqlutil.getList(ALIAS, query.toString());
    }
    
    @Override
    public List<Map<String, String>> getReportData(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        
        Map map = new HashMap();
        map.put("SEARCHBY", bean.getTxtinputtext());
        map.put("TIER", bean.getRdotierchoice());
        map.put("FROMDATE", bean.getTxtfromdate());
        map.put("TODATE", bean.getTxttodate());
        map.put("PAYRECEIVED", payment_received);
        
        query.append(" SELECT  ");
        query.append(" CASE   ");
        query.append(" WHEN PRF.NPS_AC_TYPE=1 THEN 'TIER I'  ");
        query.append(" WHEN PRF.NPS_AC_TYPE=2 THEN 'TIER II'  ");
        query.append(" ELSE 'NA'   ");
        query.append(" END TIER,  ");
        query.append(" DATE_FORMAT(NRM.ENTDATE,'%d-%m-%Y') AS ENTDATE,IFNULL(CONCAT(GM.NJBRCODE,'-',GM.NAME),'NA') AS PTN_NAME, IFNULL(LM.LOC_NAME,'NA') AS LOC_NAME ,  ");
        query.append(" CASE   ");
        query.append(" WHEN NRP.FNAME IS NULL AND NRP.MNAME IS NULL AND NRP.LNAME IS NULL THEN 'NA'   ");
        query.append(" ELSE CONCAT(IFNULL(NRP.FNAME,''),' ',IFNULL(NRP.MNAME,''),' ',IFNULL(NRP.LNAME,''))  ");
        query.append(" END AS SUBS_NAME,  ");
        query.append(" NRM.REF_NO, NRM.PAN, NRM.UID, IFNULL(PM.PRAN_NO,'NA') AS PRAN_NO, IFNULL(SM.SCHEME_NAME,'NA') AS SCHEME_NAME,  ");
        query.append(" IFNULL(CONCAT(NRA.CORR_ADD1,'',NRA.CORR_ADD2,'',NRA.CORR_ADD3),'NA') AS CORR_ADDRESS,  ");
        query.append(" IFNULL(NRA.CORR_CITY,'NA') AS CORR_CITY , IFNULL(NRA.CORR_STATE,'NA') AS CORR_STATE ,   ");
        query.append(" 'INDIA' AS CORR_CNTRY,  ");
        query.append(" IFNULL((SELECT BANK_NAME FROM  NPS_BANK_MAST WHERE BANK_ID=BD.BANK_ID),'NA') AS BANK_NAME,  ");
        query.append(" IFNULL(BD.ACCNO,'NA') AS ACCNO, ");
        query.append(" IF(NSM.STATUS_ID >= :PAYRECEIVED,IFNULL(DATE_FORMAT(TXN.TRXN_DATE,'%d-%m-%Y'),'NA'),'NA')AS PAYMENT_DATE,  ");
        query.append(" IF(NSM.STATUS_ID >= :PAYRECEIVED, ");
        query.append(" CASE   ");
        query.append(" WHEN PRF.NPS_AC_TYPE=1 THEN IFNULL(TXN.TIER_I_AMOUNT,'NA')  ");
        query.append(" WHEN PRF.NPS_AC_TYPE=2 THEN IFNULL(TXN.TIER_II_AMOUNT,'NA')  ");
        query.append(" ELSE 'NA'  ");
        query.append(" END,'NA') AS INVEST_AMOUNT,   ");
        query.append(" IF(NSM.STATUS_ID >= :PAYRECEIVED,IFNULL(CHRG_TR1.TRXN_CHRG,'NA'),'NA') AS TRXN_CHARGE,  ");
        query.append(" IF(NSM.STATUS_ID >= :PAYRECEIVED,IF(TXN.TRXN_DATE IS NOT NULL,  ");
        query.append(" (IFNULL(CHRG_TR1.IGST_AMT,0) +  IFNULL(CHRG_TR1.CGST_AMT,0) + IFNULL(CHRG_TR1.SGST_AMT,0) + IFNULL(CHRG_TR1.UTGST_AMT,0)),'NA'),'NA') AS  TXN_GST,  ");
        query.append(" IF(NSM.STATUS_ID >= :PAYRECEIVED,IFNULL(CHRG_REG.TRXN_CHRG,'NA'),'NA') AS REG_CHARGE,  ");
        query.append(" IF(NSM.STATUS_ID >= :PAYRECEIVED,IF(TXN.TRXN_DATE IS NOT NULL,  ");
        query.append(" (IFNULL(CHRG_REG.IGST_AMT,0) + IFNULL(CHRG_REG.CGST_AMT,0) + IFNULL(CHRG_REG.SGST_AMT,0) + IFNULL(CHRG_REG.UTGST_AMT,0)),'NA'),'NA') AS  REG_GST,  ");
        query.append(" IF(NSM.STATUS_ID >= :PAYRECEIVED,IFNULL(TXN.NET_AMOUNT,'NA'),'NA') AS NET_AMOUNT,  ");
        query.append(" NSM.STATUS,NRM.STATUS_ID  ");
        query.append(" FROM NPS_REG_MAIN NRM ");
        if ((bean.getTxtinputtext() == null || bean.getTxtinputtext().trim().equalsIgnoreCase("")) && bean.getRdoreportchoice() != null && bean.getRdoreportchoice().equalsIgnoreCase("paymentreceived")) {
            query.append(" INNER JOIN (SELECT DISTINCT REF_NO FROM eNPS.NPS_STATUS_CHANGE_DTL ");
            query.append(" WHERE DATE(ENT_DATE) BETWEEN STR_TO_DATE(:FROMDATE, '%d-%m-%Y') AND STR_TO_DATE(:TODATE, '%d-%m-%Y') AND STATUS_ID=:PAYRECEIVED ");
            query.append(" )SCD ON SCD.REF_NO= NRM.REF_NO ");
//            query.append(" INNER JOIN NPS_STATUS_CHANGE_DTL NSCD ON NRM.REF_NO= NSCD.REF_NO AND NSCD.STATUS_CHANGE_ID=( ");
//            query.append(" SELECT STATUS_CHANGE_ID FROM NPS_STATUS_CHANGE_DTL WHERE REF_NO=NRM.REF_NO AND STATUS_ID= :PAYRECEIVED ");
//            query.append(" DATE(ENT_DATE) BETWEEN STR_TO_DATE(:FROMDATE, '%d-%m-%Y') AND STR_TO_DATE(:TODATE, '%d-%m-%Y')  LIMIT 1 ) ");
        }
        query.append(" INNER JOIN NPS_STATUS_MASTER NSM ON NRM.STATUS_ID= NSM.STATUS_ID ");
        query.append(" INNER JOIN NPS_REG_PERSONAL NRP ON NRP.REF_NO= NRM.REF_NO  ");
        query.append(" INNER JOIN njindiainvest.GRPMST GM ON GM.GRPCODE=NRM.BRCODE  ");
        query.append(" INNER JOIN NJHR.LOCATION LM ON LM.LOC_ID = GM.BRNCODE  ");
        query.append(" LEFT JOIN NPS_REG_PREFERENCES PRF ON PRF.REF_NO=NRM.REF_NO   ");
        query.append(" LEFT JOIN NPS_SCHEME_MASTER SM ON SM.SCHEME_ID=PRF.SCHEME_ID    ");
        query.append(" LEFT JOIN NPS_REG_ADDRESS NRA ON NRA.REF_NO=NRM.REF_NO    ");
        query.append(" LEFT JOIN NPS_REG_BANK_DTL BD ON BD.REF_NO=NRM.REF_NO AND BD.NPS_AC_TYPE=PRF.NPS_AC_TYPE  ");
        query.append(" LEFT JOIN NPS_PRAN_MASTER PM ON PM.REF_NO= NRM.REF_NO  ");
        query.append(" LEFT JOIN NPS_REG_TRXN as TXN ON TXN.PAYMENT_ID= (SELECT MAX(PAYMENT_ID) FROM NPS_REG_TRXN Tx Where Tx.REF_NO = NRM.REF_NO  AND Tx.IS_FRESH='Y')    ");
        query.append(" LEFT JOIN NPS_REG_TRXNCHRG CHRG_TR1 ON CHRG_TR1.PAYMENT_ID= TXN.PAYMENT_ID  AND CHRG_TR1.TRXN_TYPE=1  ");
        query.append(" LEFT JOIN NPS_REG_TRXNCHRG CHRG_REG ON CHRG_REG.PAYMENT_ID= TXN.PAYMENT_ID  AND CHRG_REG.TRXN_TYPE=3 ");
        query.append(" WHERE 1=1 ");
        if (bean.getTxtinputtext() != null && !bean.getTxtinputtext().trim().equalsIgnoreCase("")) {
            query.append(" AND NRM.REF_NO= :SEARCHBY ");
            query.append(" OR NRM.RECEIPT_NO= :SEARCHBY ");
            query.append(" OR NRM.PAN= :SEARCHBY ");
            query.append(" OR NRM.UID= :SEARCHBY ");
            query.append(" OR PM.PRAN_NO= :SEARCHBY ");
        } else {
            if (bean.getCmbbranch() != null && !bean.getCmbbranch().trim().equalsIgnoreCase("")) {
                query.append(" AND LM.LOC_ID IN('").append(bean.getCmbbranch().replace(",", "\',\'")).append("') ");
            }
            if (bean.getRdoreportchoice().trim().equalsIgnoreCase("registration")) {
                if (bean.getCmbstatus() != null && !bean.getCmbstatus().trim().equalsIgnoreCase("")) {
                    query.append(" AND NRM.STATUS_ID IN(").append(bean.getCmbstatus()).append(") ");
                }
            }
            if (bean.getCmbpartner() != null && !bean.getCmbpartner().trim().equalsIgnoreCase("")) {
                query.append(" AND GM.NJBRCODE IN('").append(bean.getCmbpartner().replace(",", "\',\'")).append("') ");
            }
            if (bean.getRdotierchoice() != null && !bean.getRdotierchoice().trim().equalsIgnoreCase("") && bean.getRdotierchoice().trim().equalsIgnoreCase("TierI")) {
                query.append(" AND NRM.TIER_I ='Y' AND NRM.TIER_II ='N'  ");
            } else if (bean.getRdotierchoice() != null && !bean.getRdotierchoice().trim().equalsIgnoreCase("") && bean.getRdotierchoice().trim().equalsIgnoreCase("TierII")) {
                query.append(" AND NRM.TIER_I ='Y' AND NRM.TIER_II ='Y'   ");
            }
            if (bean.getRdoreportchoice() != null && bean.getRdoreportchoice().trim().equalsIgnoreCase("registration")) {
                query.append(" AND DATE(NRM.ENTDATE) BETWEEN STR_TO_DATE(:FROMDATE, '%d-%m-%Y') AND STR_TO_DATE(:TODATE, '%d-%m-%Y') ");
            } else if (bean.getRdoreportchoice() != null && bean.getRdoreportchoice().trim().equalsIgnoreCase("activation")) {
                query.append(" AND NRM.ACTIVE_DATE IS NOT NULL AND DATE(NRM.ACTIVE_DATE) BETWEEN STR_TO_DATE(:FROMDATE, '%d-%m-%Y') AND STR_TO_DATE(:TODATE, '%d-%m-%Y') ");
            }
//            else if (bean.getRdoreportchoice() != null && bean.getRdoreportchoice().trim().equalsIgnoreCase("paymentreceived")) {
//                query.append(" DATE(NSCD.ENT_DATE) BETWEEN STR_TO_DATE(:FROMDATE, '%d-%m-%Y') AND STR_TO_DATE(:TODATE, '%d-%m-%Y') ");
//            }
        }
        query.append(" ORDER BY REF_NO DESC,TIER ");
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getStatusDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        query.append(" SELECT DATE_FORMAT(SCD.ENT_DATE,'%d-%m-%Y') AS ENT_DATE,SM.STATUS, ");
        query.append(" CASE ");
        query.append(" WHEN SCD.CHANGE_BY='AUTO' THEN 'AUTO' ");
        query.append(" ELSE (SELECT EMP_NAME FROM NJHR.EMP_MAST WHERE EMP_CODE= SCD.EMP_CODE) ");
        query.append(" END AS CHANGEBY,IFNULL(SCD.REJECT_REASON,'NA') AS REJECT_REASON ");
        query.append(" FROM NPS_STATUS_CHANGE_DTL	SCD ");
        query.append(" INNER JOIN NPS_STATUS_MASTER SM ON SCD.STATUS_ID = SM.STATUS_ID ");
        query.append(" WHERE SCD.REF_NO= :REF_NO ");
        query.append(" ORDER BY SCD.STATUS_CHANGE_ID DESC ");
        
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getPrimaryAddressContactOtherFatcaDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        query.append(" SELECT NRM.REF_NO,IFNULL(NPM.PRAN_NO,'NA') AS PRAN_NO ,IFNULL(GRP.NAME,'NA')AS PARTNER_NAME,IFNULL(LOC.LOC_NAME,'NA') AS LOC_NAME , ");
        query.append(" IF( ");
        query.append(" CONCAT(IFNULL(NRP.INITIALS,''),' ',IFNULL(NRP.FNAME,''),' ',IFNULL(NRP.MNAME,''),' ',IFNULL(NRP.LNAME,''))='', ");
        query.append(" 'NA',CONCAT(IFNULL(NRP.INITIALS,''),' ',IFNULL(NRP.FNAME,''),' ',IFNULL(NRP.MNAME,''),' ',IFNULL(NRP.LNAME,''))) AS APP_NAME, ");
        query.append(" NSM.STATUS,NRM.UID,NRM.PAN,IFNULL(NRM.RECEIPT_NO,'NA') AS RECEIPT_NO,IFNULL(DATE_FORMAT(NRP.DOB,'%d-%m-%Y'),'NA') AS DOB,IFNULL(NRP.GENDER,'NA') AS GENDER, ");
        query.append(" NRM.CATEGORY,IFNULL(NRP.IS_MOTHER_NAME,'NA') AS IS_MOTHER_NAME,");
        query.append(" IF(NRP.IS_MOTHER_NAME='Y' OR NRP.IS_MOTHER_NAME='N',IF(TRIM(CONCAT(IFNULL(NRP.FM_INTTIALS,''),' ',IFNULL(NRP.FM_FNAME,''),' ',IFNULL(NRP.FM_MNAME,''),' ',IFNULL(NRP.FM_LNAME,'')))!='',CONCAT(IFNULL(NRP.FM_INTTIALS,''),' ',IFNULL(NRP.FM_FNAME,''),' ',IFNULL(NRP.FM_MNAME,''),' ',IFNULL(NRP.FM_LNAME,'')),'NA'),'NA') AS PRANNAME,");
        query.append(" IFNULL(NRP.EKYC_IMAGE_NAME,'NA') AS EKYC_IMAGE_NAME, ");
        query.append(" IFNULL(NRP.BO_FILE_NAME,'NA') AS BO_FILE_NAME,IFNULL(NRM.TIER_I,'NA') AS TIER_I,IFNULL(NRM.TIER_II,'NA') AS TIER_II, ");
        query.append(" IFNULL(NRA.CORR_ADD1,'NA') AS CORR_ADD1,IFNULL(NRA.CORR_ADD2,'NA') AS CORR_ADD2, ");
        query.append(" IFNULL(NRA.CORR_ADD3,'NA') AS CORR_ADD3,IFNULL(NRA.CORR_LOCALITY,'NA') AS CORR_LOCALITY, ");
        query.append(" IFNULL(NRA.CORR_LANDMARK,'NA') AS CORR_LANDMARK,IFNULL(NRA.CORR_CITY,'NA') AS CORR_CITY, ");
        query.append(" IFNULL(NRA.CORR_PINCODE,'NA')AS CORR_PINCODE,IFNULL(NRA.CORR_STATE,'NA') AS CORR_STATE, ");
        query.append(" IFNULL(NRA.CORR_COUNTRY,'NA')AS CORR_COUNTRY, ");
        query.append(" CASE ");
        query.append(" WHEN NRA.CORR_STATE_ID IS NOT NULL THEN ");
        query.append(" (SELECT STATE_NAME FROM NPS_STATE_MASTER WHERE NJ_GEO_ID= NRA.CORR_STATE_ID) ");
        query.append(" ELSE 'NA' ");
        query.append(" END STATE_NAME, ");
        query.append(" IFNULL(NRM.GST_NO,'NA') AS GST_NO,IFNULL(NRA.IS_SAME_ADD,'NA') AS IS_SAME_ADD, ");
        query.append(" IFNULL(NRA.RES_ADD1,'NA') AS RES_ADD1,IFNULL(NRA.RES_ADD2,'NA') AS RES_ADD2, ");
        query.append(" IFNULL(NRA.RES_ADD3,'NA') AS RES_ADD3,IFNULL(NRA.RES_LOCALITY,'NA') AS RES_LOCALITY, ");
        query.append(" IFNULL(NRA.RES_LANDMARK,'NA') AS RES_LANDMARK,IFNULL(NRA.RES_CITY,'NA')AS RES_CITY, ");
        query.append(" IFNULL(NRA.RES_PINCODE,'NA')AS RES_PINCODE,IFNULL(NRA.RES_STATE,'NA')AS RES_STATE, ");
        query.append(" IFNULL(NRA.RES_COUNTRY,'NA')AS RES_COUNTRY, ");
        query.append(" IFNULL(NRC.OPHONE,'NA') AS OPHONE,IFNULL(NRC.RPHONE,'NA') AS RPHONE, ");
        query.append(" IFNULL(NRC.MOBILE,'NA') AS MOBILE,IFNULL(NRC.EMAIL_ID,'NA') AS EMAIL_ID, ");
        query.append(" IFNULL((SELECT OCC_DESC FROM  NPS_OCCUPATION_MASTER WHERE OCC_CODE=  NRP.OCC_CODE),'NA') AS OCCUPATION, ");
        query.append(" IFNULL(NRP.OTHER_OCCUPATION,'NA') AS OTHER_OCCUPATION, ");
        query.append(" IFNULL((SELECT INCOME_RANGE FROM NPS_INCOME_RANGE_MASTER WHERE IR_ID=NRP.IR_ID),'NA') AS INCOME_RANGE, ");
        query.append(" IFNULL((SELECT EDUCATION FROM NPS_EDUCATION_MASTER WHERE EDUCATION_CODE =NRP.EDUCATION_CODE),'NA') AS EDUCATION, ");
        query.append(" IFNULL(NRP.POLITICAL_EXPO,'NA') AS POLITICAL_EXPO, ");
//        query.append(" IFNULL((SELECT CNTRY_NAME FROM registration.FATCA_COUNTRY WHERE CNTRY_ID = NRF.CNTRY_OF_BIRTH),'NA') AS FAT_CO, ");
//        query.append(" IFNULL((SELECT CNTRY_NAME FROM registration.FATCA_COUNTRY WHERE CNTRY_ID = NRF.NATIONALITY),'NA') AS FAT_NAT, ");
//        query.append(" IFNULL((SELECT CNTRY_NAME FROM registration.FATCA_COUNTRY WHERE CNTRY_ID = NRF.CNTRY_OF_TAX_PURPOSE),'NA') AS FAT_TAX, ");
        query.append(" IFNULL(FAT1.CNTRY_NAME,'NA') AS FAT_BIRTH_COUNTRY, ");
        query.append(" IFNULL(FAT2.CNTRY_NAME,'NA') AS FAT_NATIONALITY, ");
        query.append(" IFNULL(FAT3.CNTRY_NAME,'NA') AS FAT_TAX, ");
        query.append(" IFNULL(NRF.IS_US,'NA') AS IS_US, ");
        query.append(" IFNULL(NRF.CITY_OF_BIRTH,'NA') AS CITY_OF_BIRTH,IFNULL(NRM.CKYC_NO,'NA') AS CKYC_NO, ");
        query.append(" CASE ");
        query.append(" WHEN NRP.MARITAL_STATUS = 'M' THEN 'Married' ");
        query.append(" WHEN NRP.MARITAL_STATUS = 'U' THEN 'Unmarried' ");
        query.append(" WHEN NRP.MARITAL_STATUS = 'O' THEN 'Other' ");
        query.append(" ELSE 'NA' ");
        query.append(" END AS MARITAL_STATUS, ");
        query.append(" IF(NRP.MTHR_FNAME IS NULL AND NRP.MTHR_MNAME IS NULL AND NRP.MTHR_LNAME IS NULL,'NA',CONCAT(IFNULL(NRP.MTHR_FNAME,''),' ',IFNULL(NRP.MTHR_MNAME,''),' ',IFNULL(NRP.MTHR_LNAME,''))) As MOTHER_NAME, ");
        query.append(" IFNULL(NRP.MDN_NAME,'NA') AS MDN_NAME, ");
        query.append(" IF(NRP.SPOUSE_FNAME IS NULL AND NRP.SPOUSE_MNAME IS NULL AND NRP.SPOUSE_LNAME IS NULL,'NA',CONCAT(IFNULL(NRP.SPOUSE_FNAME,''),' ',IFNULL(NRP.SPOUSE_MNAME,''),' ',IFNULL(NRP.SPOUSE_LNAME,''))) As SPOUSE_NAME, ");
        query.append(" IFNULL(NRA.CORR_ADD_TYPE,'NA') AS CORR_ADD_TYPE, ");
        query.append(" IFNULL(NRA.RES_ADD_TYPE,'NA') AS RES_ADD_TYPE, ");
        query.append(" IFNULL(NRF.CNTRY_OF_TAX_PURPOSE,'NA') AS CNTRY_OF_TAX_PURPOSE ");
        query.append(" FROM NPS_REG_MAIN NRM ");
        query.append(" INNER JOIN NPS_STATUS_MASTER NSM ON NRM.STATUS_ID=NSM.STATUS_ID ");
        query.append(" INNER JOIN NPS_REG_PERSONAL NRP ON NRM.REF_NO=NRP.REF_NO ");
        query.append(" INNER JOIN njindiainvest.GRPMST GRP ON GRP.GRPCODE=NRM.BRCODE ");
        query.append(" INNER JOIN NJHR.LOCATION LOC ON LOC.LOC_ID = GRP.BRNCODE ");
        query.append(" INNER JOIN NPS_REG_CONTACT NRC ON NRM.REF_NO=NRC.REF_NO ");
        query.append(" LEFT JOIN NPS_REG_ADDRESS NRA ON NRM.REF_NO=NRA.REF_NO ");
        query.append(" LEFT JOIN NPS_PRAN_MASTER NPM ON NRM.REF_NO=NPM.REF_NO ");
        query.append(" LEFT JOIN NPS_REG_FATCA NRF ON NRM.REF_NO=NRF.REF_NO ");
        query.append(" LEFT JOIN registration.FATCA_COUNTRY FAT1 ON NRF.CNTRY_OF_BIRTH=FAT1.CNTRY_ID ");
        query.append(" LEFT JOIN registration.FATCA_COUNTRY FAT2 ON NRF.NATIONALITY=FAT2.CNTRY_ID ");
        query.append(" LEFT JOIN registration.FATCA_COUNTRY FAT3 ON NRF.CNTRY_OF_TAX_PURPOSE=FAT3.CNTRY_ID ");
        query.append(" WHERE NRM.REF_NO=:REF_NO ");
        
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> geteKycAndeSignDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        map.put("EKYCDONE", ekyc_done);
        map.put("ESIGNDONE", esign_done);
        
        query.append(" SELECT IF(NRM.STATUS_ID >= :EKYCDONE AND SCDL.STATUS_ID = :EKYCDONE ,'Done','Pending') AS EKYCSTATUS, ");
        query.append(" CASE ");
        query.append(" WHEN NRM.STATUS_ID >= :EKYCDONE AND SCDL.STATUS_ID = :EKYCDONE AND NRM.EKYC_MODE ='1' THEN 'OTP' ");
        query.append(" WHEN NRM.STATUS_ID >= :EKYCDONE AND SCDL.STATUS_ID = :EKYCDONE AND NRM.EKYC_MODE ='2' THEN 'Biometric' ");
        query.append(" ELSE 'NA' ");
        query.append(" END AS EKYCMODE, ");
        query.append(" IF(NRM.STATUS_ID >= :EKYCDONE AND SCDL.STATUS_ID = :EKYCDONE,IFNULL(DATE_FORMAT(SCDL.ENT_DATE,'%d-%m-%Y'),'NA'),'NA') AS EKYC_DATE, ");
        query.append(" IF(NRM.STATUS_ID >= :ESIGNDONE AND ESIGN.STATUS_ID = :ESIGNDONE,'Done','Pending') AS ESIGNSTATUS, ");
        query.append(" CASE ");
        query.append(" WHEN NRM.STATUS_ID >= :ESIGNDONE AND ESIGN.STATUS_ID = :ESIGNDONE AND (ESIGN.INP_TYP='SMS' OR NRM.EKYC_MODE ='1') THEN 'OTP'  ");
        query.append(" WHEN NRM.STATUS_ID >= :ESIGNDONE AND ESIGN.STATUS_ID = :ESIGNDONE AND (ESIGN.INP_TYP='BIO' OR NRM.EKYC_MODE ='2') THEN 'BIOMETRIC'  ");
        query.append(" ELSE 'NA' ");
        query.append(" END AS ESIGNMODE, ");
        query.append(" IF(NRM.STATUS_ID >= :ESIGNDONE AND ESIGN.STATUS_ID = :ESIGNDONE,IFNULL(DATE_FORMAT(SCDL.ENT_DATE,'%d-%m-%Y'),'NA'),'NA') AS ESIGN_DATE, ");
        query.append(" IFNULL(IF(NRM.STATUS_ID >= :ESIGNDONE AND ESIGN.STATUS_ID = :ESIGNDONE,NRM.REF_NO,'NA'),'NA') AS VIEWESIGN ");
        query.append(" FROM NPS_REG_MAIN NRM ");
        query.append(" LEFT JOIN NPS_STATUS_CHANGE_DTL SCDL ON NRM.REF_NO=SCDL.REF_NO AND SCDL.STATUS_ID= :EKYCDONE ");
        query.append(" LEFT JOIN  ");
        query.append(" ( ");
        query.append(" SELECT REQ.*,ESCDL.STATUS_ID FROM NPS_ESIGN_REQ REQ ");
        query.append(" INNER JOIN NPS_ESIGN_RES RES ON RES.ESIGN_REQ_ID=REQ.ESIGN_REQ_ID AND RES.RET_STATUS='S' AND RES.ERROR_CODE IS NULL    ");
        query.append(" INNER JOIN NPS_STATUS_CHANGE_DTL ESCDL ON REQ.REF_NO=ESCDL.REF_NO AND ESCDL.STATUS_ID= :ESIGNDONE ");
//        query.append(" )ESIGN ON NRM.REF_NO=ESIGN.REF_NO AND SCDL.STATUS_ID= :ESIGNDONE ");
        query.append(" )ESIGN ON NRM.REF_NO=ESIGN.REF_NO ");
        query.append(" WHERE NRM.REF_NO=:REF_NO ");
        query.append(" ORDER BY SCDL.ENT_DATE DESC LIMIT 1 ");
        
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getFatcaTinDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        
        query.append(" SELECT NRFT.SR_NO,NRFT.TIN_NUM,FT.CNTRY_NAME AS TIN_CNTRY, IFNULL(FTT.CNTRY_NAME,'NA') AS TAX_RESIDENCY,");
        query.append(" IFNULL(DATE_FORMAT(NRFT.DOC_VALIDITY,'%d-%m-%Y'),'NA') AS DOC_VALIDITY,IFNULL(NRFT.TAX_ADDRESS,'NA') AS TAX_ADDRESS, ");
        query.append(" IFNULL(NRFT.TAX_CITY,'NA') AS TAX_CITY,IFNULL(NRFT.TAX_STATE,'NA') AS TAX_STATE,IFNULL(NRFT.TAX_PINCODE,'NA') AS TAX_PINCODE ");
        query.append(" FROM NPS_REG_FATCA NRF ");
        query.append(" INNER JOIN NPS_REG_FATCA_TIN NRFT ON NRF.REG_FATCA_ID=NRFT.REG_FATCA_ID ");
        query.append(" INNER JOIN registration.FATCA_COUNTRY FT ON FT.CNTRY_ID=NRFT.TIN_CNTRY ");
        query.append(" LEFT JOIN registration.FATCA_COUNTRY FTT ON FTT.CNTRY_ID=NRFT.TAX_CNTRY ");
        query.append(" WHERE NRF.REF_NO=:REF_NO ");
        query.append(" ORDER BY NRFT.SR_NO ");
        
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getTierDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        query.append(" SELECT ");
        query.append(" NRM.REF_NO,NRPR.NPS_AC_TYPE,NSM.SCHEME_NAME,NRPR.INVESTMENT_OPTION, ");
        query.append(" IFNULL(NRPR.EQUITY_ALLOCATION,'NA') AS EQUITY_ALLOCATION, ");
        query.append(" IFNULL(NRPR.DEBT_ALLOCATION,'NA') AS DEBT_ALLOCATION, ");
        query.append(" IFNULL(NRPR.GOVT_BOND_ALLOCATION,'NA') AS GOVT_BOND_ALLOCATION, ");
        query.append(" IFNULL(NRPR.ALTERNATE_ALLOCATION,'NA') AS ALTERNATE_ALLOCATION, ");
        query.append(" IFNULL(NRPR.LC_FUND_TYPE,'NA') AS LC_FUND_TYPE, ");
        query.append(" CASE ");
        query.append(" WHEN NBD.ACCTYPE ='S' THEN 'Saving' ");
        query.append(" WHEN NBD.ACCTYPE ='C' THEN 'Current' ");
        query.append(" ELSE 'NA' ");
        query.append(" END AS ACCTYPE,NRM.ENT_BY,NBD.BANK_ID,NBM.NJ_BANKCODE, ");
        query.append(" IFNULL(NBD.ACCNO,'NA') AS ACCNO, ");
        query.append(" IFNULL(NBM.BANK_NAME,'NA') AS BANK_NAME, ");
        query.append(" IFNULL(NBD.BRANCH_NAME,'NA') AS BRANCH_NAME, ");
        query.append(" IFNULL(NBD.BANK_ADDRESS,'NA') AS BANK_ADDRESS, ");
        query.append(" IFNULL(NBD.PINCODE,'NA') AS PINCODE, ");
        query.append(" IFNULL(SM.STATE_NAME,'NA') AS STATE_NAME,IFNULL(SM.NJ_GEO_ID,'NA') AS STATE_CODE, ");
        query.append(" IFNULL(CM.COUNTRY_NAME,'NA') AS COUNTRY_NAME,IFNULL(CM.NJ_GEO_ID,'NA') AS COUNTRY_CODE, ");
        query.append(" IFNULL(NBD.MICR,'NA') AS MICR, ");
        query.append(" IFNULL(NBD.IFSC,'NA') AS IFSC, ");
        query.append(" IFNULL(NBD.BANK_PROOF,'NA') AS BANK_PROOF, ");
        query.append(" IFNULL(NBD.PAN_COPY,'NA')AS PAN_COPY ");
        query.append(" FROM NPS_REG_MAIN NRM ");
        query.append(" INNER JOIN NPS_REG_PREFERENCES NRPR ON NRM.REF_NO=NRPR.REF_NO ");
        query.append(" INNER JOIN NPS_SCHEME_MASTER NSM ON NRPR.SCHEME_ID=NSM.SCHEME_ID ");
        query.append(" INNER JOIN NPS_REG_BANK_DTL NBD ON NRM.REF_NO=NBD.REF_NO AND NBD.NPS_AC_TYPE=NRPR.NPS_AC_TYPE  ");
        query.append(" INNER JOIN NPS_BANK_MAST NBM ON NBD.BANK_ID=NBM.BANK_ID ");
        query.append(" LEFT JOIN NPS_STATE_MASTER SM ON NBD.STATE_CODE=SM.NJ_GEO_ID ");
        query.append(" LEFT JOIN NPS_COUNTRY_MASTER CM ON NBD.COUNTRY_CODE=CM.NJ_GEO_ID ");
        query.append(" WHERE NRM.REF_NO=:REF_NO ");
        query.append(" ORDER BY NPS_AC_TYPE ");
        
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getNomineeDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        
        query.append(" SELECT  ");
        query.append(" NRMD.NPS_AC_TYPE, NRMD.SR_NO, ");
        query.append(" IF(TRIM(CONCAT(IFNULL(NRMD.NOMI_FNAME,''),' ',IFNULL(NRMD.NOMI_MNAME,''),'',IFNULL(NRMD.NOMI_LNAME,'')))!='' ");
        query.append(" ,CONCAT(IFNULL(NRMD.NOMI_FNAME,''),' ',IFNULL(NRMD.NOMI_MNAME,''),'',IFNULL(NRMD.NOMI_LNAME,'')) ");
        query.append(" ,'NA') AS NOMINAME, ");
        query.append(" IFNULL(NRMD.REL_WITH_APP,'NA')AS REL_WITH_APP,IFNULL(DATE_FORMAT(NRMD.DOB,'%d-%m-%Y'),'NA')AS DOB, ");
        query.append(" IF(TRIM(CONCAT(IFNULL(NRMD.GRDN_FNAME,''),' ',IFNULL(NRMD.GRDN_MNAME,''),'',IFNULL(NRMD.GRDN_LNAME,'')))!='' ");
        query.append(" ,CONCAT(IFNULL(NRMD.GRDN_FNAME,''),' ',IFNULL(NRMD.GRDN_MNAME,''),'',IFNULL(NRMD.GRDN_LNAME,'')) ");
        query.append(" ,'NA') AS GARDNAME, ");
        query.append(" IFNULL(NRMD.ADDRESS1,'NA')AS ADDRESS1,IFNULL(NRMD.ADDRESS2,'NA')AS ADDRESS2,IFNULL(NRMD.ADDRESS3,'NA')AS ADDRESS3, ");
        query.append(" IFNULL(NRMD.NOMI_TYPE,'NA')AS NOMI_TYPE,IFNULL(NRMD.SHARE_PERCENT,'NA') AS SHARE_PERCENT  ");
        query.append(" FROM NPS_REG_MAIN NRM ");
        query.append(" INNER JOIN NPS_REG_NOMI_DTL NRMD ON NRM.REF_NO=NRMD.REF_NO ");
        query.append(" WHERE NRM.REF_NO=:REF_NO ");
        query.append(" ORDER BY SR_NO,NPS_AC_TYPE ");
        
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getPaymentDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        map.put("PAYMENTRECEIVED", payment_received);
        map.put("PAYMENTFAILED", payment_failed);
        
        query.append(" SELECT  ");
        query.append(" IFNULL(NRT.TIER_I_AMOUNT,'NA') AS TIER_I_AMOUNT ,IFNULL(NRTCH1.TRXN_CHRG,'NA') AS TRXN_CHRG_T1, ");
        query.append(" IFNULL(NRTCH1.IS_IGST,'NA') AS IS_IGST_T1,IFNULL(NRTCH1.IGST_RATE,'NA') AS IGST_RATE_T1,IFNULL(NRTCH1.IGST_AMT,'NA') AS IGST_AMT_T1, ");
        query.append(" IFNULL(NRTCH1.IS_UTGST,'NA') AS IS_UTGST_T1,IFNULL(NRTCH1.UTGST_RATE,'NA') AS UTGST_RATE_T1,IFNULL(NRTCH1.UTGST_AMT,'NA') AS UTGST_AMT_T1, ");
        query.append(" IFNULL(NRTCH1.IS_CGST,'NA') AS IS_CGST_T1,IFNULL(NRTCH1.CGST_RATE,'NA') AS CGST_RATE_T1,IFNULL(NRTCH1.CGST_AMT,'NA') AS CGST_AMT_T1, ");
        query.append(" IFNULL(NRTCH1.IS_SGST,'NA') AS IS_SGST_T1,IFNULL(NRTCH1.SGST_RATE,'NA') AS SGST_RATE_T1,IFNULL(NRTCH1.SGST_AMT,'NA') AS SGST_AMT_T1, ");
        query.append(" IFNULL(NRT.TIER_II_AMOUNT,'NA') AS TIER_II_AMOUNT,IFNULL(NRTCH2.TRXN_CHRG,'NA') AS TRXN_CHRG_T2, ");
        query.append(" IFNULL(NRTCH2.IS_IGST,'NA') AS IS_IGST_T2,IFNULL(NRTCH2.IGST_RATE,'NA') AS IGST_RATE_T2,IFNULL(NRTCH2.IGST_AMT,'NA') AS IGST_AMT_T2, ");
        query.append(" IFNULL(NRTCH2.IS_UTGST,'NA') AS IS_UTGST_T2,IFNULL(NRTCH2.UTGST_RATE,'NA') AS UTGST_RATE_T2,IFNULL(NRTCH2.UTGST_AMT,'NA') AS UTGST_AMT_T2, ");
        query.append(" IFNULL(NRTCH2.IS_CGST,'NA') AS IS_CGST_T2,IFNULL(NRTCH2.CGST_RATE,'NA') AS CGST_RATE_T2,IFNULL(NRTCH2.CGST_AMT,'NA') ASCGST_AMT_T2, ");
        query.append(" IFNULL(NRTCH2.IS_SGST,'NA') AS IS_SGST_T2,IFNULL(NRTCH2.SGST_RATE,'NA') AS SGST_RATE_T2,IFNULL(NRTCH2.SGST_AMT,'NA') AS SGST_AMT_T2, ");
        query.append(" IFNULL(NRTCH3.TRXN_CHRG,'NA') AS TRXN_CHRG_AC, ");
        query.append(" IFNULL(NRTCH3.IS_IGST,'NA') AS IS_IGST_AC,IFNULL(NRTCH3.IGST_RATE,'NA') AS IGST_RATE_AC,IFNULL(NRTCH3.IGST_AMT,'NA') AS IGST_AMT_AC, ");
        query.append(" IFNULL(NRTCH3.IS_UTGST,'NA') AS IS_UTGST_AC,IFNULL(NRTCH3.UTGST_RATE,'NA') AS UTGST_RATE_AC,IFNULL(NRTCH3.UTGST_AMT,'NA') AS UTGST_AMT_AC, ");
        query.append(" IFNULL(NRTCH3.IS_CGST,'NA') AS IS_CGST_AC,IFNULL(NRTCH3.CGST_RATE,'NA') AS CGST_RATE_AC,IFNULL(NRTCH3.CGST_AMT,'NA') AS CGST_AMT_AC, ");
        query.append(" IFNULL(NRTCH3.IS_SGST,'NA') AS IS_SGST_AC,IFNULL(NRTCH3.SGST_RATE,'NA') AS SGST_RATE_AC,IFNULL(NRTCH3.SGST_AMT,'NA') AS SGST_AMT_AC, ");
        query.append(" IFNULL(NRT.TOTAL_AMOUNT,'NA') AS TOTAL_AMOUNT, ");
        query.append(" IFNULL(NRT.INVOICE_NUM,'NA') AS INVOICE_NUM, ");
        query.append(" CASE ");
        query.append(" WHEN NRT.STATUS_ID= :PAYMENTRECEIVED THEN 'Paid' ");
        query.append(" WHEN NRT.STATUS_ID= :PAYMENTFAILED THEN 'Failed' ");
        query.append(" ELSE 'NA' ");
        query.append(" END AS  PAYMENTSTATUS, ");
        query.append(" IFNULL(NRT.NET_AMOUNT,'NA') AS NET_AMOUNT,IFNULL(DATE_FORMAT(NSCD.ENT_DATE,'%d-%m-%Y'),'NA') AS ENT_DATE, ");
        query.append(" CASE  ");
        query.append(" WHEN NSCD.CHANGE_BY='MANUAL' THEN IFNULL(CONCAT(NSCD.CHANGE_BY,' ',EMP.EMP_NAME),'NA') ");
        query.append(" ELSE IFNULL(NSCD.CHANGE_BY,'NA') ");
        query.append(" END AS REMARK, ");
        query.append(" IFNULL(NRT.STATUS_ID,'NA') AS STATUS_ID,IFNULL(NRT.NET_AMOUNT,'NA') AS NET_AMOUNT, ");
        query.append(" IFNULL(NRT.TIER_I_RECEIPT_NO,'NA') AS TIER_I_RECEIPT_NO, ");
        query.append(" IFNULL(NRT.TIER_II_RECEIPT_NO,'NA') AS TIER_II_RECEIPT_NO ");
        query.append(" FROM NPS_REG_TRXN NRT ");
        query.append(" INNER JOIN NPS_REG_TRXNCHRG NRTCH1 ON NRT.PAYMENT_ID=NRTCH1.PAYMENT_ID AND NRTCH1.TRXN_TYPE=1 ");
        query.append(" LEFT JOIN NPS_REG_TRXNCHRG NRTCH2 ON NRT.PAYMENT_ID=NRTCH2.PAYMENT_ID AND NRTCH2.TRXN_TYPE=2 "); // When Tier II not selected
        query.append(" INNER JOIN NPS_REG_TRXNCHRG NRTCH3 ON NRT.PAYMENT_ID=NRTCH3.PAYMENT_ID AND NRTCH3.TRXN_TYPE=3 ");
        query.append(" LEFT JOIN NPS_STATUS_CHANGE_DTL NSCD ON NRT.REF_NO=NSCD.REF_NO AND NSCD.STATUS_ID= :PAYMENTRECEIVED ");
        query.append(" LEFT JOIN NJHR.EMP_MAST EMP ON NSCD.EMP_CODE=EMP.EMP_CODE ");
        query.append(" WHERE NRT.REF_NO=:REF_NO AND NRT.IS_FRESH='Y' ORDER BY NRT.TRXN_DATE  DESC LIMIT 1 ");
        
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getBankProof(CRAExportUtilityBean bean, String tier) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        map.put("TIER", tier);
        
        query.append(" SELECT BANK_PROOF,PAN_COPY ");
        query.append(" FROM NPS_REG_BANK_DTL ");
        query.append(" WHERE REF_NO=:REF_NO AND NPS_AC_TYPE=:TIER ");
        
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public String getReceiptNumber(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        
        query.append(" SELECT RECEIPT_NO ");
        query.append(" FROM NPS_REG_MAIN ");
        query.append(" WHERE REF_NO=:REF_NO ");
        
        return sqlutil.getString(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getAllowedStatusList(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        query.append(" SELECT NSM.STATUS_ID,NSM.STATUS ");
        query.append(" FROM NPS_REG_MAIN NRM ");
        query.append(" INNER JOIN NPS_STATUS_CHANGE_MATRIX SCM ON SCM.FROM_STATUS_ID=NRM.STATUS_ID ");
        query.append(" INNER JOIN NPS_STATUS_MASTER NSM ON NSM.STATUS_ID=SCM.ALLOWED_STATUS_ID ");
        query.append(" WHERE NRM.REF_NO= :REF_NO ");
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getDataUsingRefNo(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        query.append(" SELECT ENT_BY,RECEIPT_NO,STATUS_ID ");
        query.append(" FROM NPS_REG_MAIN ");
        query.append(" WHERE REF_NO=:REF_NO ");
        
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getEmailData(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        
        query.append(" SELECT NRM.PAN, ");
        query.append(" IF(TRIM(CONCAT(IFNULL(NRP.FNAME,''),' ',IFNULL(NRP.MNAME,''),' ',IFNULL(NRP.LNAME,'')))!='',CONCAT(IFNULL(NRP.FNAME,''),' ',IFNULL(NRP.MNAME,''),' ',IFNULL(NRP.LNAME,'')),'NA') AS APP_NAME, ");
        query.append(" IFNULL(NRM.RECEIPT_NO,'NA') AS RECEIPT_NO,IFNULL(SCD.REJECT_REASON,'NA') AS REJECT_REASON,NRC.EMAIL_ID, ");
        query.append(" IFNULL(NPM.PRAN_NO,'NA') AS PRAN_NO,DATE_FORMAT(SCD.ENT_DATE,'%d-%m-%Y') AS ENT_DATE ");
        query.append(" FROM NPS_REG_MAIN NRM  ");
        query.append(" INNER JOIN NPS_REG_PERSONAL NRP ON NRP.REF_NO=NRM.REF_NO ");
        query.append(" INNER JOIN NPS_REG_CONTACT NRC ON NRC.REF_NO=NRM.REF_NO ");
        query.append(" INNER JOIN NPS_STATUS_CHANGE_DTL SCD ON SCD.REF_NO=NRM.REF_NO AND SCD.STATUS_ID=NRM.STATUS_ID ");
        query.append(" LEFT JOIN NPS_PRAN_MASTER NPM ON NRM.REF_NO=NPM.REF_NO ");
        query.append(" WHERE NRM.REF_NO= :REF_NO ");
        query.append(" ORDER BY SCD.STATUS_CHANGE_ID DESC ");
        
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List CheckUpdateValidStatus(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getRefno());
        
        query.append(" SELECT NSCM.ALLOWED_STATUS_ID ");
        query.append(" FROM NPS_REG_MAIN NRM ");
        query.append(" INNER JOIN NPS_STATUS_MASTER NSM ON NRM.STATUS_ID=NSM.STATUS_ID ");
        query.append(" INNER JOIN NPS_STATUS_CHANGE_MATRIX NSCM ON NSM.STATUS_ID=NSCM.FROM_STATUS_ID ");
        query.append(" WHERE NRM.REF_NO= :REF_NO ");
        
        List lst = sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
        List reslst = new ArrayList();
        int i;
        if (lst != null && lst.size() > 0) {
            for (i = 0; i < lst.size(); i++) {
                map.clear();
                map = (Map) lst.get(i);
                reslst.add(map.get("ALLOWED_STATUS_ID").toString());
            }
        }
        return reslst;
    }
    
    @Override
    public List<Map<String, String>> getReportPaymentDtl(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", bean.getHdnrefno());
        map.put("PAYMENTID", bean.getTxtpaymentid());
        map.put("PAYMENTPENDING", payment_pending);
        map.put("PAYMENTFAILED", payment_failed);
        
        query.append(" SELECT NRT.PAYMENT_ID,DATE_FORMAT(NPG.TRXNDATE,'%d- %m- %Y %h:%i %p') AS TRAN_DATE,NSM.STATUS,NPG.AMOUNT ");
        query.append(" FROM  NPS_PAYMENTGATEWAY NPG ");
        query.append(" INNER JOIN  NPS_REG_TRXN NRT ON NPG.PAYMENT_ID=NRT.PAYMENT_ID ");
        query.append(" INNER JOIN  NPS_STATUS_MASTER NSM ON NSM.STATUS_ID=NRT.STATUS_ID ");
        query.append(" WHERE NRT.REF_NO=:REF_NO AND NRT.PAYMENT_ID=:PAYMENTID AND NRT.IS_FRESH='Y' "); // AND NRT.STATUS_ID  IN (:PAYMENTPENDING,:PAYMENTFAILED)

        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(map));
    }
    
    @Override
    public List<Map<String, String>> getNpsInvoiceAmntDetailContent(Map mp, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        
        query.append("  SELECT DISTINCT NRT.INVOICE_NUM,DATE_FORMAT(NSCD.ENT_DATE,'%d-%m-%Y') AS ENT_DATE,NRP.EKYC_NAME ");
        query.append("  ,concat(NRA.CORR_ADD1,' ', COALESCE(NRA.CORR_ADD2,'') , ' ', ");
        query.append("  COALESCE(NRA.CORR_ADD3,''),' ', COALESCE(NRA.CORR_LOCALITY,''), ' ', ");
        query.append("  COALESCE( NRA.CORR_LANDMARK,''),' ', NRA.CORR_CITY,' ', '-' ,' ', NRA.CORR_PINCODE) as ADDRESS ");
        query.append("  ,GM.GEO_NAME,GGM.GSTIN,NRM.GST_NO, ");
        query.append("   ");
        query.append("  NRTX.TRXN_CHRG as Tier0_TRXN_CHRG,NRTX.IS_IGST as Tier0_IGST,NRTX.IS_SGST as Tier0_SGST ");
        query.append("  ,NRTX.IS_CGST as Tier0_CSGT,NRTX.IS_UTGST as Tier0_UTGST, ");
        query.append("  NRTX.IGST_RATE as Tier0_IGST_RATE,NRTX.IGST_AMT as Tier0_IGST_AMT, ");
        query.append("  NRTX.CGST_RATE as Tier0_CGST_RATE,NRTX.CGST_AMT as Tier0_CGST_AMT, ");
        query.append("  NRTX.SGST_RATE as Tier0_SGST_RATE,NRTX.SGST_AMT as Tier0_SGST_AMT, ");
        query.append("  NRTX.UTGST_RATE as Tier0_UTGST_RATE,NRTX.UTGST_AMT as Tier0_UTGST_AMT ");
        query.append("   ");
        query.append("  ,NRTX1.TRXN_CHRG as Tier1_TRXN_CHRG ,NRTX1.IS_IGST as Tier1_IGST , ");
        query.append("  NRTX1.IS_SGST as Tier1_SGST ,NRTX1.IS_CGST as Tier1_CGST,NRTX1.IS_UTGST as Tier1_UTGST , ");
        query.append("  NRTX1.IGST_RATE as Tier1_IGST_RATE ,NRTX1.IGST_AMT as Tier1_IGST_AMT , ");
        query.append("  NRTX1.CGST_RATE as Tier1_CGST_RATE ,NRTX1.CGST_AMT as Tier1_CGST_AMT , ");
        query.append("  NRTX1.SGST_RATE as Tier1_SGST_RATE ,NRTX1.SGST_AMT as Tier1_SGST_AMT , ");
        query.append("  NRTX1.UTGST_RATE as Tier1_UTGST_RATE ,NRTX1.UTGST_AMT as Tier1_UTGST_AMT  ");
        query.append("   ");
        query.append("  ,NRTX2.TRXN_CHRG as Tier2_TRXN_CHRG,NRTX2.IS_IGST  as Tier2_IGST,NRTX2.IS_SGST  as Tier2_SGST, ");
        query.append("  NRTX2.IS_CGST  as Tier2_CGST,NRTX2.IS_UTGST  as Tier2_UTGST, ");
        query.append("  NRTX2.IGST_RATE  as Tier2_IGST_RATE,NRTX2.IGST_AMT  as Tier2_IGST_AMT, ");
        query.append("  NRTX2.CGST_RATE  as Tier2_CGST_RATE,NRTX2.CGST_AMT  as Tier2_CGST_AMT, ");
        query.append("  NRTX2.SGST_RATE  as Tier2_SGST_RATE,NRTX2.SGST_AMT  as Tier2_SGST_AMT, ");
        query.append("  NRTX2.UTGST_RATE  as Tier2_UTGST_RATE,NRTX2.UTGST_AMT  as Tier2_UTGST_AMT ");
        query.append("   ");
        query.append("   ");
        query.append("  FROM  NPS_REG_MAIN NRM ");
        query.append("  INNER JOIN  NPS_STATUS_CHANGE_DTL NSCD ON NRM.REF_NO = NSCD.REF_NO ");
        query.append("  AND NRM.STATUS_ID = NSCD.STATUS_ID ");
        query.append("  INNER JOIN  NPS_REG_PERSONAL NRP ON NRM.REF_NO = NRP.REF_NO ");
        query.append("  INNER JOIN  NPS_REG_ADDRESS NRA ON NRM.REF_NO = NRA.REF_NO ");
        query.append("  INNER JOIN NJHR.GEO_MAST GM ON GM.GEO_ID = NRA.CORR_STATE_ID ");
        query.append("  INNER JOIN NJHR.GEO_GSTIN_MAPPING GGM ON GGM.GEO_ID = NRA.CORR_STATE_ID ");
        query.append("  INNER JOIN  NPS_REG_TRXN NRT ON NRM.REF_NO = NRT.REF_NO   AND NRM.STATUS_ID=NRT.STATUS_ID ");
        query.append("  INNER JOIN  NPS_REG_TRXNCHRG NRTX ON NRT.PAYMENT_ID = NRTX.PAYMENT_ID ");
        query.append("  INNER JOIN  NPS_REG_TRXNCHRG NRTX1 ON NRT.PAYMENT_ID = NRTX1.PAYMENT_ID  ");
        query.append("  left outer join  NPS_REG_TRXNCHRG NRTX2 ON NRT.PAYMENT_ID = NRTX2.PAYMENT_ID  ");
        query.append("  and NRTX2.TRXN_TYPE = 2 ");
        query.append("  WHERE NRM.REF_NO = :REF_NO ");
        query.append("  AND NRM.STATUS_ID = :STATUS_ID ");
        query.append("  AND  NRTX.TRXN_TYPE = 3  ");
        query.append("  AND NRTX1.TRXN_TYPE = 1  ");
        query.append("  AND NRT.IS_FRESH = 'Y' ");
        query.append("   ");
        query.append("  ORDER BY NRT.PAYMENT_ID DESC LIMIT 1");
        
        mp.put("STATUS_ID", payment_received);
        
        return sqltran.getList(query.toString(), new MapSqlParameterSource(mp));
    }
    
    @Override
    public List<Map<String, String>> getnpsInvoiceDetailContent(Map mp, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        
        StringBuilder query = new StringBuilder();
        
        query.append("  SELECT  NRP.EKYC_NAME,NPM.PRAN_NO,NRM.RECEIPT_NO, ");
        query.append("  NSCD.ENT_DATE,NRC.MOBILE, ");
        query.append("  NRM.TIER_I,NRM.TIER_II, ");
        query.append("  NRT.TIER_I_AMOUNT,IFNULL(NRT.TIER_II_AMOUNT,0) TIER_II_AMOUNT, ");
        query.append("  NRT.TOTAL_AMOUNT, ");
        query.append("  NRTX1.TRXN_CHRG as Tier1_TRXN_CHRG ,NRTX1.IS_IGST as Tier1_IGST , ");
        query.append("  NRTX1.IS_SGST as Tier1_SGST ,NRTX1.IS_CGST as Tier1_CGST, ");
        query.append("  NRTX1.IGST_RATE as Tier1_IGST_RATE ,IFNULL(NRTX1.IGST_AMT,0) as Tier1_IGST_AMT , ");
        query.append("  NRTX1.CGST_RATE as Tier1_CGST_RATE ,IFNULL(NRTX1.CGST_AMT,0) as Tier1_CGST_AMT , ");
        query.append("  NRTX1.SGST_RATE as Tier1_SGST_RATE ,IFNULL(NRTX1.SGST_AMT,0) as Tier1_SGST_AMT , ");
        query.append("  IFNULL(NRTX2.TRXN_CHRG,0) as Tier2_TRXN_CHRG,NRTX2.IS_IGST  as Tier2_IGST, ");
        query.append("  NRTX2.IS_SGST  as Tier2_SGST,NRTX2.IS_CGST  as Tier2_CGST, ");
        query.append("  NRTX2.IGST_RATE  as Tier2_IGST_RATE,IFNULL(NRTX2.IGST_AMT,0)  as Tier2_IGST_AMT, ");
        query.append("  NRTX2.CGST_RATE  as Tier2_CGST_RATE,IFNULL(NRTX2.CGST_AMT ,0) as Tier2_CGST_AMT, ");
        query.append("  NRTX2.SGST_RATE  as Tier2_SGST_RATE,IFNULL(NRTX2.SGST_AMT ,0) as Tier2_SGST_AMT, ");
        query.append("  NRTX3.TRXN_CHRG as Tier0_TRXN_CHRG,NRTX3.IS_IGST as Tier0_IGST, ");
        query.append("  NRTX3.IS_SGST as Tier0_SGST,NRTX3.IS_CGST as Tier0_CSGT, ");
        query.append("  NRTX3.IGST_RATE as Tier0_IGST_RATE,IFNULL(NRTX3.IGST_AMT,0) as Tier0_IGST_AMT, ");
        query.append("  NRTX3.CGST_RATE as Tier0_CGST_RATE,IFNULL(NRTX3.CGST_AMT,0)as Tier0_CGST_AMT, ");
        query.append("  NRTX3.SGST_RATE as Tier0_SGST_RATE,IFNULL(NRTX3.SGST_AMT,0) as Tier0_SGST_AMT, ");
        query.append("  IFNULL(NRT.TIER_I_RECEIPT_NO,'NA') AS TIER_I_RECEIPT_NO,IFNULL(NRT.TIER_II_RECEIPT_NO,'NA') AS TIER_II_RECEIPT_NO ");
        query.append("  FROM  NPS_REG_MAIN NRM ");
        query.append("  INNER JOIN  NPS_PRAN_MASTER NPM ON NRM.REF_NO = NPM.REF_NO ");
        query.append("  INNER JOIN  NPS_REG_CONTACT NRC ON NRM.REF_NO = NRC.REF_NO ");
        query.append("  INNER JOIN  NPS_REG_PERSONAL NRP ON NRM.REF_NO = NRP.REF_NO ");
        query.append("  INNER JOIN  NPS_REG_PREFERENCES NRPR ON NRM.REF_NO = NRPR.REF_NO ");
        query.append("  INNER JOIN  NPS_REG_TRXN NRT ON NRM.REF_NO = NRT.REF_NO   AND NRM.STATUS_ID=NRT.STATUS_ID ");
        query.append("  INNER JOIN  NPS_REG_TRXNCHRG NRTX1 ON NRT.PAYMENT_ID = NRTX1.PAYMENT_ID  ");
        query.append("  LEFT OUTER JOIN  NPS_REG_TRXNCHRG NRTX2 ON NRT.PAYMENT_ID = NRTX2.PAYMENT_ID  ");
        query.append("  and NRTX2.TRXN_TYPE = 2 ");
        query.append("  INNER JOIN  NPS_REG_TRXNCHRG NRTX3 ON NRT.PAYMENT_ID = NRTX3.PAYMENT_ID ");
        query.append("  INNER JOIN  NPS_STATUS_CHANGE_DTL NSCD ON NRM.REF_NO = NSCD.REF_NO  ");
        query.append("  WHERE NRM.REF_NO =:REF_NO  ");
        query.append("  AND NRM.STATUS_ID = :STATUS_ID ");
        query.append("  and NSCD.STATUS_ID = 2  ");
        query.append("  and NRTX1.TRXN_TYPE = 1 ");
        query.append("  and NRTX3.TRXN_TYPE = 3 ");
        query.append("  AND NRT.IS_FRESH = 'Y' ");
        query.append("  ORDER BY NRT.PAYMENT_ID DESC LIMIT 1");
        
        mp.put("STATUS_ID", payment_received);
        
        return sqltran.getList(query.toString(), new MapSqlParameterSource(mp));
    }
    
    @Override
    public String getpartner(Map mp) throws ClassNotFoundException, SQLException {
        
        StringBuilder query = new StringBuilder();
        query.append(" SELECT CONCAT (GM.NJBRCODE,' - ',GM.NAME) PARTNER   ")
                .append(" FROM registration.TAC_DETAIL TD ")
                .append(" INNER JOIN njindiainvest.GRPMST GM ON GM.GRPCODE = TD.BRCODE ")
                .append(" INNER JOIN registration.TAC_MAIN TM ON TM.NJAC_NO = TD.NJAC_NO  ")
                .append(" INNER JOIN  NPS_REG_MAIN NRM ON TM.NJAC_NO = NRM.ENT_BY ")
                .append(" WHERE NRM.REF_NO = :REF_NO ");
        
        return sqlutil.getString(ALIAS, query.toString(), new MapSqlParameterSource(mp));
    }
    
    @Override
    public String getnpsresgistrationTOemailid(Map mp) throws ClassNotFoundException, SQLException {
        
        StringBuilder query = new StringBuilder();
        query.append(" SELECT TC.EMAIL_ID   ")
                .append(" FROM NPS_REG_MAIN NRM ")
                .append(" INNER JOIN registration.TAC_MAIN TM  ")
                .append(" ON TM.NJAC_NO = NRM.ENT_BY ")
                .append(" INNER JOIN registration.TAC_CONTACT TC ")
                .append(" ON TC.NJAC_NO = TM.NJAC_NO ")
                .append(" WHERE NRM.REF_NO = :REF_NO ");
        
        return new SQLUtility().getString(ALIAS,
                query.toString(), new MapSqlParameterSource(mp));
    }
    
    @Override
    public String getnpsresgistrationCCemailid(Map mp) throws ClassNotFoundException, SQLException {
        
        StringBuilder query = new StringBuilder();
        query.append(" SELECT GD.EMAIL   ")
                .append(" FROM NPS_REG_MAIN NRM ")
                .append(" INNER JOIN registration.TAC_MAIN TM  ON TM.NJAC_NO = NRM.ENT_BY ")
                .append(" INNER JOIN registration.TAC_DETAIL TD ON TD.NJAC_NO = TM.NJAC_NO ")
                .append(" INNER JOIN njindiainvest.GRPMST GM ON GM.BRCODE = TD.BRCODE ")
                .append(" INNER JOIN njindiainvest.GRP_DETAIL GD ON GD.GRPCODE = GM.BRCODE ")
                .append(" WHERE NRM.REF_NO = :REF_NO AND GM.GRPCODE = GM.BRCODE ")
                .append(" AND GM.TYPE = :TYPE ");
        
        return new SQLUtility().getString(ALIAS,
                query.toString(), new MapSqlParameterSource(mp));
    }
    
    @Override
    public List<Map<String, String>> getGenerateFileReport(String finalrefids) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        query.append(" SELECT CONVERT(@rownum := @rownum + 1, CHAR(50)) AS SRNO,t1.*"); // Return Double at java side so need to Cast to char
        query.append(" FROM (");
        query.append(" SELECT  NRM.REF_NO,NRM.RECEIPT_NO AS Reciept_No, IFNULL(PM.PRAN_NO,'') AS PRAN ,");
        query.append(" CASE WHEN LOWER(NRP.INITIALS)='mr' THEN 'Shri'");
        query.append(" WHEN LOWER(NRP.INITIALS)='mrs' THEN 'Smt' ");
        query.append(" WHEN LOWER(NRP.INITIALS)='miss' THEN 'Kumari'");
        query.append(" ELSE ''");
        query.append(" END AS Title, ");
        query.append(" IFNULL(NRP.FNAME,'') AS Subscriber_First_Name ,IFNULL(NRP.LNAME,'') AS Subscriber_LAStName, IFNULL(NRP.MNAME,'') AS Subscriber_Middle_Name  ,");
        query.append(" IFNULL(NRP.FM_FNAME,'') AS Subscriber_Fathers_First_Name ,IFNULL(NRP.FM_LNAME,'') AS Subscriber_Fathers_LASt_Name,IFNULL(NRP.FM_MNAME,'') AS Subscriber_Fathers_Middle_Name,");
        query.append(" IFNULL(NRP.MDN_NAME,'') AS Subscriber_Maiden_Name,	'1454610' AS POP_SP_CBO_Reg_No,");
        query.append(" IFNULL(NRP.GENDER,'') AS Subscriber_Gender  ,");
        query.append(" DATE_FORMAT(NRP.DOB,'%d/%m/%Y') AS Subscriber_DOB ,IFNULL(NRF.CITY_OF_BIRTH,'') AS Ex_City_of_Birth, ");
        query.append(" IFNULL((SELECT CNTRY_CODE FROM  registration.FATCA_COUNTRY WHERE  CNTRY_ID = NRF.CNTRY_OF_BIRTH ),'') AS Ex_Country_of_Birth,");
        query.append(" ifnull(NRP.MARITAL_STATUS,'') as Ex_Marital_Status, ");
        query.append(" ifnull(NRP.SPOUSE_FNAME,'') as Ex_Spouse_First_Name, ");
        query.append(" ifnull(NRP.SPOUSE_LNAME,'') as Ex_Spouse_Last_Name, ");
        query.append(" ifnull(NRP.SPOUSE_MNAME,'') as Ex_Spouse_Middle_Name, ");
        query.append(" 'RI' as Ex_Nationality, ");
        query.append(" (Case when NRM.RESI_STATUS ='01' Then 'RI' when NRM.RESI_STATUS='02' Then 'NRI' Else '' END)  as Ex_Residential_Status, ");
        query.append(" NRM.PAN AS Subscriber_PAN ,IFNULL(NRA.CORR_ADD_TYPE,'') AS Ex_Address_Type,");
        query.append(" IFNULL(NRA.CORR_ADD1,'') AS Subscriber_Correspondence_line_1,");
        query.append(" IFNULL(NRA.CORR_ADD2,'') AS Subscriber_Correspondence_line_2,");
        query.append(" IFNULL(NRA.CORR_ADD3,'') AS Subscriber_Correspondence_line_3,");
        query.append(" IFNULL(NRA.CORR_CITY,'') AS Subscriber_Correspondence_District_Town_City,");
        query.append(" IFNULL(NRA.CORR_LOCALITY,'') AS Subscriber_Correspondence_Road_Street, ");
        query.append(" IFNULL(NRA.CORR_LANDMARK,'') AS Subscriber_Correspondence_Landmark , ");
        query.append(" (SELECT STATE_CODE FROM eNPS.NPS_STATE_MASTER WHERE NJ_GEO_ID = NRA.CORR_STATE_ID) AS Subscriber_Correspondence_State_UT,");
        query.append(" 'IN' AS Subscriber_Correspondence_Country,NRA.CORR_PINCODE AS Subscriber_Correspondence_PIN_Code,");
        query.append(" IFNULL(NRA.RES_ADD_TYPE,'') AS Ex_Address_Type1,								");
        query.append(" IFNULL(NRA.RES_ADD1,'') AS Subscriber_Permanent_Address_line_1,");
        query.append(" IFNULL(NRA.RES_ADD2,'') AS Subscriber_Permanent_Address_line_2,");
        query.append(" IFNULL(NRA.RES_ADD3,'') AS Subscriber_Permanent_Address_line_3,");
        query.append(" IFNULL(NRA.RES_CITY,'') AS Subscriber_Permanent_District_Town_City,");
        query.append(" IFNULL(NRA.RES_LOCALITY,'') AS Subscriber_Permanent_Street,");
        query.append(" IFNULL(NRA.RES_LANDMARK,'') AS Subscriber_Permanent_Landmark,");
        query.append(" (SELECT IFNULL(STATE_CODE,'') FROM eNPS.NPS_STATE_MASTER  WHERE NJ_GEO_ID = NRA.CORR_STATE_ID) AS Subscriber_Permanent_State_UT,");
        query.append(" 'IN' AS Subscriber_Permanent_Address_Country ,");
        query.append(" IFNULL(NRA.RES_PINCODE,'')  AS Subscriber_Permanent_Permanent_Address_Pin_Code,");
        query.append(" IFNULL(NRC.RPHONE,'') AS Subscriber_Tel_Number ,");
        query.append(" IFNULL(NRC.MOBILE,'')  AS Subscriber_Mobile_Number,");
        query.append(" '' AS Subscriber_Fax_No, ");
        query.append(" IFNULL(NRC.EMAIL_ID,'') AS Subscriber_Email ,");
        query.append(" 'Y' AS SMS_Subscription_flag,");
        query.append(" 'Y' AS Email_Subscription_flag, ");
        query.append(" '' AS Subscribers_Date_of_Joining,");
        query.append(" '' AS	Subscribers_Date_of_Retirement, ");
        query.append(" 'N' AS	Incomplete_Bank_Details_Flag,");
        query.append(" CASE BD_TR1.ACCTYPE WHEN 'S' THEN 'Savings' WHEN 'C' THEN 'Current' ELSE IFNULL(BD_TR1.ACCTYPE,'') END AS Subscribers_Bank_Type ,	");
        query.append(" IFNULL(BD_TR1.ACCNO,'') AS Subscribers_Bank_AC_No,");
        query.append(" (SELECT IFNULL(BANK_NAME,'')  FROM eNPS.NPS_BANK_MAST WHERE BANK_ID= BD_TR1.BANK_ID) AS Tier1_Bank_Name,");
        query.append(" IFNULL(BD_TR1.BRANCH_NAME,'') AS Tier1_Bank_Branch, ");
        query.append(" CASE WHEN BD_TR1.BANK_ADDRESS is null THEN '' ELSE REPLACE_SPECIAL_CHAR(BD_TR1.BANK_ADDRESS,' ') End  AS Tier1_Bank_Address,	");
        query.append(" (SELECT IFNULL(STATE_CODE,'') FROM eNPS.NPS_STATE_MASTER WHERE NJ_GEO_ID = BD_TR1.STATE_CODE) AS Tier1_Bank_Address_State_UT,");
        query.append(" (SELECT IFNULL(COUNTRY_CODE,'') FROM eNPS.NPS_COUNTRY_MASTER WHERE NJ_GEO_ID = BD_TR1.COUNTRY_CODE) AS Tier1_Bank_Address_Country,	");
        query.append(" IFNULL(BD_TR1.PINCODE,'') AS Tier1_Bank_Address_PIN, ");
        query.append(" IFNULL(BD_TR1.MICR,'') AS Tier1_Bank_MICR_Code,");
        query.append(" (SELECT count(*) FROM eNPS.NPS_REG_NOMI_DTL  WHERE  REF_NO= NRM.REF_NO AND  NPS_AC_TYPE=1) AS Number_of_Nominees, ");
        query.append(" (CASE WHEN  PRF_TR1.INVESTMENT_OPTION = 'Auto' THEN 3 ");
        query.append(" ELSE (");
        query.append(" (CASE WHEN IFNULL(PRF_TR1.EQUITY_ALLOCATION,0) >0  THEN 1 ELSE 0 END ) +(CASE WHEN IFNULL(PRF_TR1.DEBT_ALLOCATION,0) >0  THEN 1 ELSE 0 END )  +(CASE WHEN IFNULL(PRF_TR1.GOVT_BOND_ALLOCATION,0) >0  THEN 1 ELSE 0 END )+(CASE WHEN IFNULL(PRF_TR1.ALTERNATE_ALLOCATION,0) >0  THEN 1 ELSE 0 END )");
        query.append("  ) End) AS Number_of_Schemes,");
        query.append(" IFNULL(NRP.OCC_CODE,'') AS Subscriber_Occupation, ");
        query.append(" 'Y'AS KYC_verification_flag,	");
        query.append(" 'N' AS PAN_Verification_Flag, ");
        query.append(" '' AS Ex_EFU_Retirement_Advisor_Reg_NO1,");
//        query.append(" CONCAT(1454610,100,LPAD(FLOOR(RAND() * 9999999), 7, '0')) AS FC_Provisional_Acknowledgement_Number,");
        query.append(" NRM.CRA_FILE_ACKW_NUM AS FC_Provisional_Acknowledgement_Number,");
        query.append(" IFNULL(NRP.MTHR_FNAME ,'')  AS Subscribers_Mothers_First_Name ,");
        query.append("  IFNULL(NRP.MTHR_LNAME,'')  AS Subscribers_Mothers_LASt_Name,");
        query.append(" IFNULL(NRP.MTHR_MNAME,'')  AS Subscribers_Mothers_Middle_Name ,");
        query.append(" 'N' AS Hindi_Subscription_Flag , ");
        query.append(" '' AS First_Name_in_Hindi, ");
        query.append(" '' AS	LASt_Name_in_Hindi, ");
        query.append(" '' AS Middle_Name_in_Hindi, ");
        query.append(" '' AS	Father_Mother_First_name_in_Hindi	, ");
        query.append(" '' AS Father_Mother_LASt_name_in_Hindi	 , ");
        query.append(" '' AS Father_Mother_Middle_name_in_Hindi,");
        query.append(" IFNULL(BD_TR1.IFSC,'') AS Bank_IFS_code , ");
        query.append(" ( CASE WHEN NRM.TIER_II='Y' THEN 'Y' ELSE 'N' end) AS Combined_form_flag, ");
        query.append(" IFNULL(NRM.UID,'') AS UID,'N' AS Swavalamban_Flag, '' AS Employee_Id,'N' AS Form_type_flag ,	");
        query.append(" '' AS CBO_ID ,'' AS PASsport_Number,");
        query.append(" '' Voter_Id ,	");
        query.append(" '' AS FC_digitization_ID , ");
        query.append(" 'U' AS Sector_Type_Flag,");
        query.append(" (CASE WHEN  PRF_TR1.INVESTMENT_OPTION = 'Auto' and PRF_TR1.LC_FUND_TYPE = 'LC25' THEN 'L'");
        query.append(" WHEN PRF_TR1.INVESTMENT_OPTION = 'Auto' and PRF_TR1.LC_FUND_TYPE = 'LC50' THEN 'A'");
        query.append(" WHEN PRF_TR1.INVESTMENT_OPTION = 'Auto' and PRF_TR1.LC_FUND_TYPE = 'LC75' THEN 'H'");
        query.append(" WHEN PRF_TR1.INVESTMENT_OPTION = 'Active' THEN 'V'  End ) AS Scheme_Pref_Option , ");
        query.append(" 'I' AS Pre_Generated_PRAN_Flag, '1' AS  Minimum_upload_indicator, ");
        query.append(" (CASE WHEN NRP.IS_MOTHER_NAME='Y' THEN 'M' ELSE  'F' end) AS  Parent_Name_Flag ,");
        query.append(" '00' AS SOT_Language_Code,");
        query.append(" (CASE WHEN NRP.OCC_CODE='06'  THEN IFNULL(NRP.OTHER_OCCUPATION,'') ELSE '' end) AS Other_Details,  							");
        query.append(" 'N' AS Existing_Customer_Flag,	'N' AS Bank_Account_Aadhar_Link,'' AS Atal_Pension_yojana_Flag, ");
        query.append(" '150' AS Address_Proof, '150' AS Identity_Proof ,'150' AS DOB_Proof ,");
        query.append(" IFNULL(NRM.UID,'') AS Address_Proof_Doc_Number, IFNULL(NRM.UID,'')  AS Identity_Proof_Doc_Number ,IFNULL(NRM.UID,'') AS DOB_Proof_Doc_Number,");
        query.append(" '' AS Address_Proof_Doc_Name , '' AS Identity_Proof_Doc_Name, '' AS 	DOB_Proof_Doc_Name ,");
        query.append(" IFNULL(NRP.IR_ID,'') AS Income_Range,");
        query.append(" CASE WHEN NRP.POLITICAL_EXPO='00' THEN  '' ELSE IFNULL(NRP.POLITICAL_EXPO,'') end AS Politically_Exposed_Flag,	");
        query.append("  CASE WHEN  NRP.EDUCATION_CODE='00' THEN '' ELSE  IFNULL(NRP.EDUCATION_CODE,'') end AS Education_Qualifiction,'' AS Permanent_Address_Proof,");
        query.append(" '' AS Permanent_Address_Proof_Doc_Number ,'' AS Permanent_Address_Proof_Doc_Name,'' AS Permanent_Address_Proof_Doc_Expiry_Date	,");
        query.append(" '' AS Correspondence_Address_Proof_Document_Expiry_date	,'' AS Identity_Proof_Document_Expiry_Date,'' AS DOB_Proof_Document_Expiry_Date, ");
        query.append(" 'N' AS NRI_Flag,'Y' AS eNPS_Flag,'' AS PASsport_Date_of_Issue,'' AS	PASsport_Date_of_Expiry	,");
        query.append(" '' AS PASsport_Place_of_Issue,'' AS Foreign_Address_State_for_NRI,'' AS Preferred_Address_for_Communication,'' AS PASsport_with_Visa_Work_permit,");
        query.append(" ''AS Ex_TFU_NRIBankAccountStatus,'Y' AS Ex_Aadhaar_Seeding_Flag, IFNULL(NRM.CKYC_NO,'') AS  Ex_CERSAI_UIN,");
        query.append(" IFNULL(TR1_N1.NOMI_FNAME,'') AS T1_Nom_1_First_Name , IFNULL(TR1_N1.NOMI_LNAME,'') AS T1_Nom_1_LASt_Name , IFNULL(TR1_N1.NOMI_MNAME,'') AS T1_Nom_1_Middle_Name ,");
        query.append(" IFNULL(DATE_FORMAT(TR1_N1.DOB,'%d/%m/%Y'),'') AS T1_Nom_1_Date_of_Birth , ");
        query.append(" IFNULL(TR1_N1.REL_WITH_APP,'') AS T1_Nom_1_Relationship,");
        query.append(" (CASE WHEN TR1_N1.NOMI_TYPE='Minor' THEN 'Y' WHEN  TR1_N1.NOMI_TYPE='Major' THEN 'N' ELSE '' end) AS T1_Nom_1_Major_Minor_Flag ,");
        query.append(" IFNULL(TR1_N1.GRDN_FNAME,'') AS T1_Nom_1_Guardian_First_Name ,	IFNULL(TR1_N1.GRDN_LNAME,'') AS T1_Nom_1_Guardian_LASt_Name,IFNULL(TR1_N1.GRDN_MNAME,'') AS T1_Nom_1_Guardian_Middle_Name,	");
        query.append(" IFNULL(TR1_N1.SHARE_PERCENT,'') AS T1_Nom_1_Percentage_Share ,IFNULL(TR1_N1.ADDRESS1,'') AS T1_Nom1_Address_line_1,	IFNULL(TR1_N1.ADDRESS2,'') AS T1_Nom1_Address_line_2 , IFNULL(TR1_N1.ADDRESS3,'')  AS T1_Nom1_Address_line_3,");
        query.append(" '' AS T1_Nom1_Address_line_4_District_Town_City ,'' AS T1_Nom1_State_Union_Territory,'' AS T1_Nom1_Country, '' AS T1_Nom1__Address_Pin_Code_Postal_Code,");
        query.append(" IFNULL(TR1_N2.NOMI_FNAME,'') AS T1_Nom2_First_Name , IFNULL(TR1_N2.NOMI_LNAME,'') AS T1_Nom2_LASt_Name , IFNULL(TR1_N2.NOMI_MNAME,'') AS T1_Nom2_Middle_Name ,");
        query.append(" IFNULL(DATE_FORMAT(TR1_N2.DOB,'%d/%m/%Y'),'') AS T1_Nom2_Date_of_Birth , ");
        query.append(" IFNULL(TR1_N2.REL_WITH_APP,'') AS T1_Nom2_Relationship,");
        query.append(" (CASE WHEN TR1_N2.NOMI_TYPE='Minor' THEN 'Y' WHEN  TR1_N2.NOMI_TYPE='Major' THEN 'N' ELSE '' end) AS T1_Nom2_Major_Minor_Flag ,");
        query.append(" IFNULL(TR1_N2.GRDN_FNAME,'') AS T1_Nom2_Guardian_First_Name ,	IFNULL(TR1_N2.GRDN_LNAME,'') AS T1_Nom2_Guardian_LASt_Name,IFNULL(TR1_N2.GRDN_MNAME,'') AS T1_Nom2_Guardian_Middle_Name,	");
        query.append(" IFNULL(TR1_N2.SHARE_PERCENT,'') AS T1_Nom2_Percentage_Share ,");
        query.append(" IFNULL(TR1_N2.ADDRESS1,'') AS T1_Nom2_Address_line_1,	IFNULL(TR1_N2.ADDRESS2,'') AS T1_Nom2_Address_line_2 , IFNULL(TR1_N2.ADDRESS3,'')  AS T1_Nom2_Address_line_3,");
        query.append(" '' AS T1_Nom2_Address_line_4_District_Town_City ,'' AS T1_Nom2_State_Union_Territory,'' AS T1_Nom2_Country, '' T1_Nom2__Address_Pin_Code_Postal_Code,");
        query.append(" IFNULL(TR1_N3.NOMI_FNAME,'') AS T1_Nom3_First_Name , IFNULL(TR1_N3.NOMI_LNAME,'') AS T1_Nom3_LASt_Name , IFNULL(TR1_N3.NOMI_MNAME,'') AS T1_Nom3_Middle_Name ,");
        query.append(" IFNULL(DATE_FORMAT(TR1_N3.DOB,'%d/%m/%Y'),'')  AS T1_Nom3_Date_of_Birth ,");
        query.append(" IFNULL(TR1_N3.REL_WITH_APP,'') AS T1_Nom3_Relationship,");
        query.append(" (CASE WHEN TR1_N3.NOMI_TYPE='Minor' THEN 'Y' WHEN  TR1_N3.NOMI_TYPE='Major' THEN 'N' ELSE '' end) AS T1_Nom3_Major_Minor_Flag ,");
        query.append("  IFNULL(TR1_N3.GRDN_FNAME,'') AS T1_Nom3_Guardian_First_Name ,	IFNULL(TR1_N3.GRDN_LNAME,'') AS T1_Nom3_Guardian_LASt_Name,IFNULL(TR1_N3.GRDN_MNAME,'') AS T1_Nom3_Guardian_Middle_Name,	");
        query.append(" IFNULL(TR1_N3.SHARE_PERCENT,'') AS T1_Nom3_Percentage_Share ,IFNULL(TR1_N3.ADDRESS1,'') AS T1_Nom3_Address_line_1,	IFNULL(TR1_N3.ADDRESS2,'') AS T1_Nom3_Address_line_2 , IFNULL(TR1_N3.ADDRESS3,'')  AS T1_Nom3_Address_line_3,");
        query.append(" '' AS T1_Nom3_Address_line_4_District_Town_City ,'' AS T1_Nom3_State_Union_Territory,'' AS T1_Nom3_Country, ");
        query.append(" '' AS T1_Nom3_Address_Pin_Code_Postal_Code,");
        query.append(" IFNULL((SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR1.SCHEME_ID),'') AS Tier1_PFM_Id_1,");
        query.append(" IFNULL((SELECT SUB_SCHEME_ID FROM eNPS.NPS_SUB_SCHEME_MASTER WHERE PFM_ID = (SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR1.SCHEME_ID) ");
        query.append(" AND NPS_AC_TYPE=1 AND IS_ACTIVE='Y' AND  ALLOCATION_TYPE='E'),'') AS  Tier1_Scheme_Id_1,");
        query.append(" IFNULL(PRF_TR1.EQUITY_ALLOCATION,'') AS Tier1_Percentage_of_Investment_1 , ");
        query.append(" IFNULL((SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR1.SCHEME_ID) ,'')AS Tier1_PFM_Id_2,");
        query.append(" IFNULL((SELECT SUB_SCHEME_ID FROM eNPS.NPS_SUB_SCHEME_MASTER WHERE PFM_ID = (SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR1.SCHEME_ID) ");
        query.append(" AND NPS_AC_TYPE= 1 AND  IS_ACTIVE='Y' AND  ALLOCATION_TYPE='C'),'')AS  Tier1_Scheme_Id_2,");
        query.append(" IFNULL(PRF_TR1.DEBT_ALLOCATION,'') AS Tier1_Percentage_of_Investment_2 , ");
        query.append(" (SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR1.SCHEME_ID) AS Tier1_PFM_Id_3,");
        query.append(" IFNULL((SELECT SUB_SCHEME_ID FROM eNPS.NPS_SUB_SCHEME_MASTER WHERE PFM_ID = (SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR1.SCHEME_ID) ");
        query.append(" AND NPS_AC_TYPE= 1 AND IS_ACTIVE='Y' AND  ALLOCATION_TYPE='G'),'') AS  Tier1_Scheme_Id_3,");
        query.append(" IFNULL(PRF_TR1.GOVT_BOND_ALLOCATION,'') AS Tier1_Percentage_of_Investment_3 , ");
        query.append(" IFNULL((SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR1.SCHEME_ID),'') AS Tier1_PFM_Id_4,");
        query.append(" IFNULL((SELECT SUB_SCHEME_ID FROM eNPS.NPS_SUB_SCHEME_MASTER WHERE PFM_ID = (SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR1.SCHEME_ID) ");
        query.append(" AND NPS_AC_TYPE= 1 AND IS_ACTIVE='Y' AND  ALLOCATION_TYPE='A'),'') AS  Tier1_Scheme_Id_4,");
        query.append(" IFNULL(PRF_TR1.ALTERNATE_ALLOCATION,'') AS Tier1_Percentage_of_Investment_4 ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN CASE BD_TR2.ACCTYPE WHEN 'S' THEN 'Savings' WHEN 'C' THEN 'Current' ELSE IFNULL(BD_TR2.ACCTYPE,'') END ELSE '' END AS T2_Bank_AC_Type ,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(BD_TR2.ACCNO,'') ELSE '' END AS T2_Bank_AC_No,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL((SELECT BANK_NAME  FROM eNPS.NPS_BANK_MAST WHERE BANK_ID= BD_TR2.BANK_ID),'') ELSE '' END AS T2_Bank_Name ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(BD_TR2.BRANCH_NAME,'') ELSE '' END AS T2_Bank_Branch,");
        query.append(" CASE WHEN NRM.TIER_II='Y' AND BD_TR2.BANK_ADDRESS is not null THEN REPLACE_SPECIAL_CHAR(BD_TR2.BANK_ADDRESS,' ') ELSE '' END AS T2_Bank_Address,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(BD_TR2.PINCODE,'') ELSE '' END AS T2_Bank_Address_PIN,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(BD_TR2.MICR,'') ELSE '' END AS T2_Bank_MICR_Code,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(BD_TR2.IFSC,'') ELSE '' END AS T2_Bank_IFS_code,");
        query.append(" '' AS Ex_EFU_Retirement_Advisor_Reg_NO2,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN (SELECT CAST(count(*) AS UNSIGNED) FROM eNPS.NPS_REG_NOMI_DTL WHERE REF_NO= NRM.REF_NO AND NPS_AC_TYPE=2) ELSE '' END AS T2_Number_of_Nominees ,");
        query.append(" ( CASE WHEN NRM.TIER_II = 'Y' THEN (");
        query.append("       (CASE WHEN PRF_TR2.INVESTMENT_OPTION = 'Auto' THEN 3");
        query.append("         ELSE (CASE WHEN IFNULL(PRF_TR2.EQUITY_ALLOCATION, 0) > 0 THEN 1 ELSE 0 END)");
        query.append("           + (CASE WHEN IFNULL(PRF_TR2.DEBT_ALLOCATION, 0) > 0 THEN 1 ELSE 0 END)");
        query.append("           + (CASE WHEN IFNULL(PRF_TR2.GOVT_BOND_ALLOCATION, 0) > 0 THEN 1 ELSE 0 END)");
        query.append("       END))");
        query.append("     ELSE ''");
        query.append("   END )AS T2_Number_of_Schemes,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL((CASE WHEN  PRF_TR2.INVESTMENT_OPTION = 'Auto' and PRF_TR2.LC_FUND_TYPE = 'LC25' THEN 'L'");
        query.append(" WHEN PRF_TR2.INVESTMENT_OPTION = 'Auto' and PRF_TR2.LC_FUND_TYPE = 'LC50' THEN 'A'");
        query.append(" WHEN PRF_TR2.INVESTMENT_OPTION = 'Auto' and PRF_TR2.LC_FUND_TYPE = 'LC75' THEN 'H'");
        query.append(" WHEN PRF_TR2.INVESTMENT_OPTION = 'Active' THEN 'V' ");
        query.append("  End ),'') ELSE '' END AS T2_Scheme_Pref_Option ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN ( CASE WHEN NRM.TIER_II='Y' THEN '1454610' ELSE '' end) ELSE '' END AS POP_SP_Reg_No,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN 'Y' ELSE '' END AS Cancelled_Cheque_Flag ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL((SELECT STATE_CODE FROM eNPS.NPS_STATE_MASTER WHERE NJ_GEO_ID = BD_TR2.STATE_CODE),'') ELSE '' END AS T2_Bank_Address_State_UT,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL((SELECT COUNTRY_CODE FROM eNPS.NPS_COUNTRY_MASTER WHERE NJ_GEO_ID = BD_TR2.COUNTRY_CODE),'') ELSE '' END AS T2_Bank_Address_Country	,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.NOMI_FNAME,'') ELSE '' END AS T2_Nom1_First_Name , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.NOMI_LNAME,'') ELSE '' END AS T2_Nom1_LASt_Name , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.NOMI_MNAME,'') ELSE '' END AS T2_Nom1_Middle_Name ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(DATE_FORMAT(TR2_N1.DOB,'%d/%m/%Y'),'') ELSE '' END AS T2_Nom1_Date_of_Birth , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.REL_WITH_APP,'') ELSE '' END AS T2_Nom1_Relationship,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN (CASE WHEN TR2_N1.NOMI_TYPE='Minor' THEN 'Y' WHEN  TR2_N1.NOMI_TYPE='Major' THEN 'N' ELSE '' end) ELSE '' END AS T2_Nom1_Major_Minor_Flag ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.GRDN_FNAME,'') ELSE '' END AS T2_Nom1_Guardian_First_Name ,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.GRDN_LNAME,'') ELSE '' END AS T2_Nom1_Guardian_LASt_Name,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.GRDN_MNAME,'') ELSE '' END AS T2_Nom1_Guardian_Middle_Name,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.SHARE_PERCENT,'') ELSE '' END AS T2_Nom1_Percentage_Share ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.ADDRESS1,'') ELSE '' END AS T2_Nom1_Address_line_1,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.ADDRESS2,'') ELSE '' END AS T2_Nom1_Address_line_2 , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N1.ADDRESS3,'') ELSE '' END AS T2_Nom1_Address_line_3,");
        query.append(" '' AS T2_Nom1_Address_line_4_District_Town_City ,'' AS T2_Nom1_State_Union_Territory,'' AS T2_Nom1_Country, '' AS T2_Nom1_Address_Pin_Code_Postal_Code,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N2.NOMI_FNAME,'') ELSE '' END AS T2_Nom2_First_Name , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N2.NOMI_LNAME,'') ELSE '' END AS T2_Nom2_LASt_Name , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N2.NOMI_MNAME,'') ELSE '' END AS T2_Nom2_Middle_Name ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(DATE_FORMAT(TR2_N2.DOB,'%d/%m/%Y'),'') ELSE '' END AS T2_Nom2_Date_of_Birth , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N2.REL_WITH_APP,'') ELSE '' END AS T2_Nom2_Relationship,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN (CASE WHEN TR2_N2.NOMI_TYPE='Minor' THEN 'Y' WHEN  TR2_N2.NOMI_TYPE='Major' THEN 'N' ELSE '' end) ELSE '' END AS T2_Nom2_Major_Minor_Flag ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN  IFNULL(TR2_N2.GRDN_FNAME,'') ELSE '' END AS T2_Nom2_Guardian_First_Name ,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N2.GRDN_LNAME,'') ELSE '' END AS T2_Nom2_Guardian_LASt_Name,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN  IFNULL(TR2_N2.GRDN_MNAME,'') ELSE '' END AS T2_Nom2_Guardian_Middle_Name,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N2.SHARE_PERCENT,'') ELSE '' END AS T2_Nom2_Percentage_Share ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN 0 ELSE '' END AS T2_Nom2_Nominee_Invalid_Condition,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN  IFNULL(TR2_N2.ADDRESS1,'') ELSE '' END AS T2_Nom2_Address_line_1,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N2.ADDRESS2,'') ELSE '' END AS T2_Nom2_Address_line_2 , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N2.ADDRESS3,'') ELSE '' END AS T2_Nom2_Address_line_3,");
        query.append(" '' AS T2_Nom2_Address_line_4_District_Town_City ,'' AS T2_Nom2_State_Union_Territory,'' AS T2_Nom2_Country, '' AS T2_Nom2_Address_Pin_Code_Postal_Code,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.NOMI_FNAME,'') ELSE '' END AS T2_Nom3_Nominee_First_Name , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.NOMI_LNAME,'') ELSE '' END AS T2_Nom3_Nominee_LASt_Name, ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.NOMI_MNAME,'') ELSE '' END AS T2_Nom3_Nominee_Middle_Name ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(DATE_FORMAT(TR2_N3.DOB,'%d/%m/%Y'),'') ELSE '' END AS T2_Nom3_Nominee_Date_of_Birth, ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.REL_WITH_APP,'') ELSE '' END AS T2_Nom3_Relationship,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN (CASE WHEN TR2_N3.NOMI_TYPE='Minor' THEN 'Y' WHEN  TR2_N3.NOMI_TYPE='Major' THEN 'N' ELSE '' end) ELSE '' END AS T2_Nom3_Major_Minor_Flag ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.GRDN_FNAME,'') ELSE '' END AS T2_Nom3_Guardian_First_Name ,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.GRDN_LNAME,'') ELSE '' END AS T2_Nom3_Guardian_LASt_Name,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.GRDN_MNAME,'') ELSE '' END AS T2_Nom3_Guardian_Middle_Name,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.SHARE_PERCENT,'') ELSE '' END AS T2_Nom3_Percentage_Share ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN 0 ELSE '' END AS  T2_Nom3_Nominee_Invalid_Condition,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.ADDRESS1,'') ELSE '' END AS T2_Nom3_Address_line_1,	");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.ADDRESS2,'') ELSE '' END AS T2_Nom3_Address_line_2 , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(TR2_N3.ADDRESS3,'') ELSE '' END AS T2_Nom3_Address_line_3,");
        query.append(" '' AS T2_Nom3_Address_line_4_District_Town_City ,'' AS T2_Nom3_State_Union_Territory,	'' AS T2_Nom3_Country, '' T2_Nom3_Address_Pin_Code_Postal_Code ,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL((SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR2.SCHEME_ID),'') ELSE '' END AS T2_PFM_Id1,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL((SELECT SUB_SCHEME_ID FROM eNPS.NPS_SUB_SCHEME_MASTER WHERE PFM_ID = (SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR2.SCHEME_ID) ");
        query.append(" AND NPS_AC_TYPE=2 AND  IS_ACTIVE='Y' AND  ALLOCATION_TYPE='E'),'') ELSE '' END AS  T2_Scheme_Id1,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(PRF_TR2.EQUITY_ALLOCATION,'') ELSE '' END AS T2_Percentage_of_Investment1 , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL((SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR2.SCHEME_ID),'') ELSE '' END AS T2_PFM_Id2,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL((SELECT SUB_SCHEME_ID FROM eNPS.NPS_SUB_SCHEME_MASTER WHERE PFM_ID = (SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR2.SCHEME_ID) ");
        query.append(" AND NPS_AC_TYPE=2 AND IS_ACTIVE='Y' AND  ALLOCATION_TYPE='C'),'') ELSE '' END AS T2_Scheme_Id2,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(PRF_TR2.DEBT_ALLOCATION,'') ELSE '' END AS T2_Percentage_of_Investment2 , ");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL((SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR2.SCHEME_ID),'') ELSE '' END AS T2_PFM_Id3,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL((SELECT SUB_SCHEME_ID FROM eNPS.NPS_SUB_SCHEME_MASTER WHERE ");
        query.append(" PFM_ID = (SELECT PFM_ID FROM NPS_SCHEME_MASTER WHERE SCHEME_ID= PRF_TR2.SCHEME_ID) ");
        query.append(" AND NPS_AC_TYPE=2 AND IS_ACTIVE='Y' AND  ALLOCATION_TYPE='G'),'') ELSE '' END AS  T2_Scheme_Id3,");
        query.append(" CASE WHEN NRM.TIER_II='Y' THEN IFNULL(PRF_TR2.GOVT_BOND_ALLOCATION,'') ELSE '' END AS T2_Percentage_of_Investment3 ,");
        query.append(" 'Y' AS Ex_FATCA_declaration,");
        query.append(" (SELECT count(*) FROM eNPS.NPS_REG_FATCA_TIN WHERE REG_FATCA_ID=NRF.REG_FATCA_ID ) AS Ex_FATCA_declaration_count,");
        query.append(" 'Y' AS Ex_AMLA_Flag,'' AS Ex_customer_Bank_account_number, ''AS Ex_customer_Bank_Branch,");
        query.append(" 'Y' AS Ex_eSign_Flag,NRF.IS_US AS EX_US_Person,");
        query.append(" IFNULL(TIN1.TIN_NUM,'') AS Ex_EFU_TIN_1,IFNULL(	DATE_FORMAT(TIN1.DOC_VALIDITY,'%d/%m/%Y'),'') AS Ex_EFU_ValidityOfDocumentary1,	");
        query.append(" IFNULL((SELECT CNTRY_CODE FROM registration.FATCA_COUNTRY WHERE CNTRY_ID = TIN1.TIN_CNTRY),'') AS Ex_EFU_Country_of_issue1,");
        query.append(" IFNULL((SELECT CNTRY_CODE FROM registration.FATCA_COUNTRY WHERE CNTRY_ID = TIN1.TAX_CNTRY),'') AS Ex_EFU_COUNTRY_CODE_Jurisdiction_Residence1,");
        query.append(" IFNULL(TIN1.TAX_ADDRESS,'') AS Ex_EFU_Address_jurisdiction_Tax_Residence1	,");
        query.append(" IFNULL(TIN1.TAX_STATE,'') AS Ex_EFU_State1, IFNULL(TIN1.TAX_CITY,'') AS Ex_EFU_City1,IFNULL(TIN1.TAX_PINCODE,'') AS Ex_EFU_zip_code1 ,");
        query.append(" IFNULL(TIN2.TIN_NUM,'') AS Ex_EFU_TIN_2,IFNULL(	DATE_FORMAT(TIN2.DOC_VALIDITY,'%d/%m/%Y'),'') AS Ex_EFU_ValidityOfDocumentary2,	");
        query.append(" IFNULL((SELECT CNTRY_CODE FROM registration.FATCA_COUNTRY WHERE CNTRY_ID = TIN2.TIN_CNTRY),'') AS Ex_EFU_Country_of_issue2,");
        query.append(" IFNULL((SELECT CNTRY_CODE FROM registration.FATCA_COUNTRY WHERE CNTRY_ID = TIN2.TAX_CNTRY),'') AS Ex_EFU_COUNTRY_CODE_Jurisdiction_Residence2,");
        query.append(" IFNULL(TIN2.TAX_ADDRESS,'') AS Ex_EFU_Address_jurisdiction_Tax_Residence2	,");
        query.append(" IFNULL(TIN2.TAX_STATE,'') AS Ex_EFU_State2,IFNULL(TIN2.TAX_CITY,'') AS Ex_EFU_City2,IFNULL(TIN2.TAX_PINCODE,'') AS Ex_EFU_zip_code2 ,					");
        query.append(" IFNULL(TIN3.TIN_NUM,'') AS Ex_EFU_TIN_3,IFNULL(	DATE_FORMAT(TIN3.DOC_VALIDITY,'%d/%m/%Y'),'') AS Ex_EFU_ValidityOfDocumentary3,	");
        query.append(" IFNULL((SELECT CNTRY_CODE FROM registration.FATCA_COUNTRY WHERE CNTRY_ID = TIN3.TIN_CNTRY),'') AS Ex_EFU_Country_of_issue3,");
        query.append(" IFNULL((SELECT CNTRY_CODE FROM registration.FATCA_COUNTRY WHERE CNTRY_ID = TIN3.TAX_CNTRY),'') AS Ex_EFU_COUNTRY_CODE_Jurisdiction_Residence3,");
        query.append(" IFNULL(TIN3.TAX_ADDRESS,'') AS Ex_EFU_Address_jurisdiction_Tax_Residence3	,");
        query.append(" IFNULL(TIN3.TAX_STATE,'') AS Ex_EFU_State3,IFNULL(TIN3.TAX_CITY,'') AS Ex_EFU_City3,IFNULL(TIN3.TAX_PINCODE,'') AS Ex_EFU_zip_code3					");
        query.append(" FROM eNPS.NPS_REG_MAIN NRM  ");
        query.append(" INNER JOIN NPS_REG_PERSONAL NRP ON NRP.REF_NO= NRM.REF_NO");
        query.append(" INNER JOIN NPS_REG_ADDRESS NRA ON NRA.REF_NO= NRM.REF_NO");
        query.append(" INNER JOIN NPS_REG_CONTACT NRC ON NRC.REF_NO= NRM.REF_NO ");
        query.append(" INNER JOIN NPS_REG_FATCA NRF ON NRF.REF_NO= NRM.REF_NO ");
        query.append(" LEFT JOIN NPS_PRAN_MASTER PM ON PM.REF_NO= NRM.REF_NO ");
        query.append(" LEFT JOIN NPS_REG_PREFERENCES  PRF_TR1 ON PRF_TR1.REF_NO=NRM.REF_NO AND PRF_TR1.NPS_AC_TYPE=1");
        query.append(" LEFT JOIN NPS_REG_PREFERENCES  PRF_TR2 ON PRF_TR2.REF_NO=NRM.REF_NO AND PRF_TR2.NPS_AC_TYPE=2");
        query.append(" LEFT JOIN NPS_REG_BANK_DTL BD_TR1 ON BD_TR1.REF_NO=NRM.REF_NO AND BD_TR1.NPS_AC_TYPE=1");
        query.append(" LEFT JOIN NPS_REG_BANK_DTL BD_TR2 ON BD_TR2.REF_NO=NRM.REF_NO AND BD_TR2.NPS_AC_TYPE=2");
        query.append(" LEFT JOIN NPS_REG_NOMI_DTL TR1_N1 ON TR1_N1.REF_NO=NRM.REF_NO AND TR1_N1.NPS_AC_TYPE=1 AND TR1_N1.SR_NO=1");
        query.append(" LEFT JOIN NPS_REG_NOMI_DTL TR1_N2 ON TR1_N2.REF_NO=NRM.REF_NO AND TR1_N2.NPS_AC_TYPE=1 AND TR1_N2.SR_NO=2");
        query.append(" LEFT JOIN NPS_REG_NOMI_DTL TR1_N3 ON TR1_N3.REF_NO=NRM.REF_NO AND TR1_N3.NPS_AC_TYPE=1 AND TR1_N3.SR_NO=3");
        query.append(" LEFT JOIN NPS_REG_NOMI_DTL TR2_N1 ON TR2_N1.REF_NO=NRM.REF_NO AND TR2_N1.NPS_AC_TYPE=2 AND TR2_N1.SR_NO=1");
        query.append(" LEFT JOIN NPS_REG_NOMI_DTL TR2_N2 ON TR2_N2.REF_NO=NRM.REF_NO AND TR2_N2.NPS_AC_TYPE=2 AND TR2_N2.SR_NO=2");
        query.append(" LEFT JOIN NPS_REG_NOMI_DTL TR2_N3 ON TR2_N3.REF_NO=NRM.REF_NO AND TR2_N3.NPS_AC_TYPE=2 AND TR2_N3.SR_NO=3");
        query.append(" LEFT JOIN NPS_REG_FATCA_TIN TIN1 ON TIN1.REG_FATCA_ID=NRF.REG_FATCA_ID AND TIN1.SR_NO=1 ");
        query.append(" LEFT JOIN NPS_REG_FATCA_TIN TIN2 ON TIN2.REG_FATCA_ID=NRF.REG_FATCA_ID AND TIN2.SR_NO=2");
        query.append(" LEFT JOIN NPS_REG_FATCA_TIN TIN3 ON TIN3.REG_FATCA_ID=NRF.REG_FATCA_ID AND TIN3.SR_NO=3");
        query.append(" WHERE NRM.REF_NO IN(").append(finalrefids).append(")");
        query.append(" ) t1,(SELECT @rownum:= 0) AS rownum");
        return sqlutil.getList(ALIAS, query.toString());
    }
    
    @Override
    public List<Map<String, String>> getPersonalDtl(String refids) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        query.append(" SELECT IFNULL(NRM.RECEIPT_NO,'') AS RECEIPT_NO,NRM.REF_NO,IFNULL(NRP.EKYC_IMAGE_NAME,'') AS EKYC_IMAGE_NAME,IFNULL(NRP.BO_FILE_NAME,'')AS BO_FILE_NAME ");
        query.append(" FROM eNPS.NPS_REG_MAIN NRM ");
        query.append(" INNER JOIN eNPS.NPS_REG_PERSONAL NRP ON NRP.REF_NO=NRM.REF_NO ");
        query.append(" WHERE NRM.REF_NO IN(").append(refids).append(")");
        return sqlutil.getList(ALIAS, query.toString());
    }
    
    @Override
    public List<Map<String, String>> getNpsRegTrxnData(CRAExportUtilityBean bean) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map mp = new HashMap();
        mp.put("PAYMENTID", bean.getTxtpaymentid());
        query.append("SELECT IFNULL(TIER_II_AMOUNT,'NA') AS TIER_II_AMOUNT FROM NPS_REG_TRXN WHERE PAYMENT_ID =:PAYMENTID ");
        return sqlutil.getList(ALIAS, query.toString(), new MapSqlParameterSource(mp));
    }
    
    @Override
    public String getAckNumber(String refid) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        query.append("SELECT GET_FC_PROV_ACKW_NUM(").append(refid).append(")");
        return sqlutil.getString(ALIAS, query.toString());
    }
}
