/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.craexportutility.service;

import com.finlogic.enps.craexportutility.bean.CRAExportUtilityBean;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ankur7
 */
public interface CRAExportUtilityService {

    public List<Map<String, String>> getBranchList() throws Exception;

    public List<Map<String, String>> getStatusList() throws Exception;

    public List<Map<String, String>> getPartnerList(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> getReportData(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> getStatusDtl(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> getPrimaryAddressContactOtherFatcaDtl(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> geteKycAndeSignDtl(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> getFatcaTinDtl(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> getTierDtl(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> getNomineeDtl(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> getPaymentDtl(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> getBankProof(CRAExportUtilityBean bean, String tier) throws Exception;

    public String getReceiptNumber(CRAExportUtilityBean bean) throws Exception;

    public List<Map<String, String>> getTradingBankDetail(String bankcode, String njacno) throws Exception;

    public List<Map<String, String>> getAllowedStatusList(CRAExportUtilityBean bean) throws Exception;

    public String getDataSave(CRAExportUtilityBean bean) throws Exception;

    public void sendMail(String content, Map map);

    public List<Map<String, String>> getReportPaymentDtl(CRAExportUtilityBean bean) throws Exception;

    public void getExportExcelFile(HttpServletRequest request, HttpServletResponse response, CRAExportUtilityBean bean) throws Exception;

    public void getGenerateFileReport(HttpServletRequest request, HttpServletResponse response, CRAExportUtilityBean bean) throws Exception;
}
