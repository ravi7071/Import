/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.craexportutility.service.impl;

import com.finlogic.enps.common.dao.OtherSchemaDataDao;
import com.finlogic.enps.commons.util.CommonFunction;
import com.finlogic.enps.commons.util.CommonMemberLog;
import com.finlogic.enps.commons.util.ExcelWrite;
import com.finlogic.enps.commons.util.FolderZipper;
import com.finlogic.enps.commons.util.NpsInvoiceGenerator;
import com.finlogic.enps.commons.util.SBCommonOperation;
import com.finlogic.enps.communication.mail.EmailSender;
import com.finlogic.enps.craexportutility.bean.CRAExportUtilityBean;
import com.finlogic.enps.craexportutility.report.CRAExportUtilityReport;
import com.finlogic.enps.craexportutility.service.CRAExportUtilityService;
import com.finlogic.enps.npscraexporthistory.dao.NpsCraExportHistory;
import com.finlogic.enps.npscraexporthistory.model.NpsCraExportHistoryModel;
import com.finlogic.enps.npspaymentgateway.dao.NpsPaymentGateway;
import com.finlogic.enps.npspaymentgateway.model.NpsPaymentGatewayModel;
import com.finlogic.enps.npspranmaster.dao.NpsPranMaster;
import com.finlogic.enps.npspranmaster.model.NpsPranMasterModel;
import com.finlogic.enps.npsregaddress.dao.NpsRegAddress;
import com.finlogic.enps.npsregaddress.model.NpsRegAddressModel;
import com.finlogic.enps.npsregmain.dao.NpsRegMain;
import com.finlogic.enps.npsregmain.model.NpsRegMainModel;
import com.finlogic.enps.npsregpersonal.dao.NpsRegPersonal;
import com.finlogic.enps.npsregpersonal.model.NpsRegPersonalModel;
import com.finlogic.enps.npsregtrxn.dao.NpsRegTrxn;
import com.finlogic.enps.npsregtrxn.model.NpsRegTrxnModel;
import com.finlogic.enps.npsstatuschangedtl.dao.NpsStatusChangeDtl;
import com.finlogic.enps.npsstatuschangedtl.model.NpsStatusChangeDtlModel;
import com.finlogic.enps.session.model.SessionBean;
import com.finlogic.util.persistence.SQLTranUtility;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 *
 * @author ankur7
 */
@Service(value = "CRAExportUtilityService")
public class CRAExportUtilityServiceImpl implements CRAExportUtilityService {

    @Autowired
    @Qualifier(value = "OtherSchemaDataDao")
    private OtherSchemaDataDao otherSchemaDataDao;

    @Autowired
    @Qualifier(value = "CRAExportUtilityReport")
    private CRAExportUtilityReport craExportUtilityReport;

    @Autowired
    @Qualifier(value = "NpsRegMain")
    private NpsRegMain npsRegMain;

    @Autowired
    @Qualifier(value = "NpsStatusChangeDtl")
    private NpsStatusChangeDtl npsStatusChangeDtl;

    @Autowired
    @Qualifier(value = "NpsRegPersonal")
    private NpsRegPersonal npsRegPersonal;

    @Autowired
    @Qualifier(value = "NpsRegAddress")
    private NpsRegAddress npsRegAddress;

    @Autowired
    @Qualifier(value = "NpsPranMaster")
    private NpsPranMaster npsPranMaster;

    @Autowired
    @Qualifier(value = "NpsPaymentGateway")
    private NpsPaymentGateway npsPaymentGateway;

    @Autowired
    @Qualifier(value = "NpsRegTrxn")
    private NpsRegTrxn npsRegTrxn;

    @Autowired
    @Qualifier(value = "sqltranutility")
    private SQLTranUtility sqltran;

    @Autowired
    @Qualifier(value = "NpsCraExportHistory")
    private NpsCraExportHistory npscraexporthistory;

    private static String rejectedNJtemp;
    private static String rejectedCRAtemp;
    private static String activetemp;
    private static String npsStoragePath;
    private static String ALIAS;
    private static String ekycPending;
    private static String active;
    private static String rejectedByCra;
    private static String rejectedByNj;
    private static String paymentReceived;
    private static String njNpsGstIn;
    private static String hsnSacCode;
    private static String npsInvoiceTempId;
    private static String bcc;
    private static String paymentfailed;

    @Value("${nps_storagepath}")
    public void setStoragePath(String nps_storagepath) {
        CRAExportUtilityServiceImpl.npsStoragePath = nps_storagepath;
    }

    @Value("${activetemplate}")
    public void setActiveTemp(String activetemplate) {
        CRAExportUtilityServiceImpl.activetemp = activetemplate;
    }

    @Value("${rejectedcratemplate}")
    public void setRejectedCraTemp(String rejectedcratemplate) {
        CRAExportUtilityServiceImpl.rejectedCRAtemp = rejectedcratemplate;
    }

    @Value("${rejectednjtemplate}")
    public void setRejectedTemp(String rejectednjtemplate) {
        CRAExportUtilityServiceImpl.rejectedNJtemp = rejectednjtemplate;
    }

    @Value("${bcc}")
    public void setBcc(String bcc) {
        CRAExportUtilityServiceImpl.bcc = bcc;
    }

    @Value("${npsinvoicetempid}")
    public void setInvoiceTempId(String npsinvoicetempid) {
        CRAExportUtilityServiceImpl.npsInvoiceTempId = npsinvoicetempid;
    }

    @Value("${njnpsgstin}")
    public void setGst(String njnpsgstin) {
        CRAExportUtilityServiceImpl.njNpsGstIn = njnpsgstin;
    }

    @Value("${enps_db_alias}")
    public void setCcode(String hsnsaccode) {
        CRAExportUtilityServiceImpl.hsnSacCode = hsnsaccode;
    }

    @Value("${enps_db_alias}")
    public void setDbAlias(String dbAlias) {
        CRAExportUtilityServiceImpl.ALIAS = dbAlias;
    }

    @Value("${ekyc_pending}")
    public void setEkycPending(String ekyc_pending) {
        CRAExportUtilityServiceImpl.ekycPending = ekyc_pending;
    }

    @Value("${active}")
    public void setActive(String active) {
        CRAExportUtilityServiceImpl.active = active;
    }

    @Value("${rejected_by_cra}")
    public void setRejectedCra(String rejected_by_cra) {
        CRAExportUtilityServiceImpl.rejectedByCra = rejected_by_cra;
    }

    @Value("${rejected_by_nj}")
    public void setRejectedByNj(String rejected_by_nj) {
        CRAExportUtilityServiceImpl.rejectedByNj = rejected_by_nj;
    }

    @Value("${payment_received}")
    public void setPaymentReceived(String payment_received) {
        CRAExportUtilityServiceImpl.paymentReceived = payment_received;
    }

    @Value("${payment_failed}")
    public void setPaymentFailed(String payment_failed) {
        CRAExportUtilityServiceImpl.paymentfailed = payment_failed;
    }

    @Override
    public List<Map<String, String>> getBranchList() throws Exception {
        return otherSchemaDataDao.getBranchList();
    }

    @Override
    public List<Map<String, String>> getStatusList() throws Exception {
        return craExportUtilityReport.getStatusList();
    }

    @Override
    public List<Map<String, String>> getPartnerList(CRAExportUtilityBean bean) throws Exception {
        return otherSchemaDataDao.getPartnerList(bean);
    }

    @Override
    public List<Map<String, String>> getReportData(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.getReportData(bean);
    }

    @Override
    public List<Map<String, String>> getStatusDtl(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.getStatusDtl(bean);
    }

    @Override
    public List<Map<String, String>> getPrimaryAddressContactOtherFatcaDtl(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.getPrimaryAddressContactOtherFatcaDtl(bean);
    }

    @Override
    public List<Map<String, String>> geteKycAndeSignDtl(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.geteKycAndeSignDtl(bean);
    }

    @Override
    public List<Map<String, String>> getFatcaTinDtl(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.getFatcaTinDtl(bean);
    }

    @Override
    public List<Map<String, String>> getTierDtl(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.getTierDtl(bean);
    }

    @Override
    public List<Map<String, String>> getNomineeDtl(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.getNomineeDtl(bean);
    }

    @Override
    public List<Map<String, String>> getPaymentDtl(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.getPaymentDtl(bean);
    }

    @Override
    public List<Map<String, String>> getBankProof(CRAExportUtilityBean bean, String tier) throws Exception {
        return craExportUtilityReport.getBankProof(bean, tier);
    }

    @Override
    public String getReceiptNumber(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.getReceiptNumber(bean);
    }

    @Override
    public List<Map<String, String>> getTradingBankDetail(String bankcode, String njacno) throws Exception {
        return otherSchemaDataDao.getBankDetailList(bankcode, njacno);
    }

    @Override
    public List<Map<String, String>> getAllowedStatusList(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.getAllowedStatusList(bean);
    }

    @Override
    public String getDataSave(CRAExportUtilityBean bean) throws Exception {
        String flag = "F";
        String receiptno = "", prevstatus = "";
        Map mp = new HashMap();
        StringBuilder content = new StringBuilder();
//        SQLTranUtility sqltran = null;
        try {
            bean.setRefno(bean.getHdnrefno());
            List allowStatus = craExportUtilityReport.CheckUpdateValidStatus(bean);
            sqltran.openConn(ALIAS);
            if (allowStatus != null && allowStatus.size() > 0) {
                if (allowStatus.contains(bean.getCmbchangestatus())) {
                    List emailData = craExportUtilityReport.getEmailData(bean);
                    if (emailData != null && emailData.size() > 0) {
                        mp = (Map) emailData.get(0);
                        List lstdata = craExportUtilityReport.getDataUsingRefNo(bean);
                        if (lstdata != null && lstdata.size() > 0) {
                            receiptno = ((Map) lstdata.get(0)).get("RECEIPT_NO") != null ? ((Map) lstdata.get(0)).get("RECEIPT_NO").toString() : "NA";
                            prevstatus = ((Map) lstdata.get(0)).get("STATUS_ID").toString();
                        }
                        npsRegMain.getUpdateStatus(convertFormBeanToNpsMainEntityBean(bean), sqltran);
                        npsStatusChangeDtl.getInsertStatusDtl(convertFormBeanToNpsStatusEntityBean(bean), sqltran);
                        List paymentlist = craExportUtilityReport.getNpsRegTrxnData(bean);
                        if (bean.getCmbchangestatus().equalsIgnoreCase(rejectedByNj)) // RejectedByNJ
                        {
                            int countexport = Integer.parseInt(npsRegMain.getCountFileExport(convertFormBeanToNpsMainEntityBean(bean), sqltran));
                            if (countexport > 0) {
                                npsPranMaster.getupdatePran(convertFormBeanToNpsPranMasterEntityBean(bean), sqltran);
                            }
                            npsRegMain.getUpdateActivation(convertFormBeanToNpsMainEntityBean(bean), sqltran);
                            if (!mp.isEmpty()) {
                                content.append("#InvestorName=").append(mp.get("APP_NAME").toString()).append("#,")
                                        .append("#PAN=").append(mp.get("PAN").toString()).append("#,")
                                        .append("#RefNo=").append(mp.get("RECEIPT_NO").toString()).append("#,")
                                        .append("#Reason=").append(bean.getRemark()).append("#");
                                mp.put("templateid", rejectedNJtemp);
                                sendMail(content.toString(), mp);
                            }
                        } else if (bean.getCmbchangestatus().equalsIgnoreCase(rejectedByCra)) // RejectedByCRA
                        {
                            npsRegMain.getUpdateActivation(convertFormBeanToNpsMainEntityBean(bean), sqltran);
                            if (!mp.isEmpty()) {
                                content.append("#InvestorName=").append(mp.get("APP_NAME").toString()).append("#,")
                                        .append("#PAN=").append(mp.get("PAN").toString()).append("#,")
                                        .append("#RefNo=").append(mp.get("RECEIPT_NO").toString()).append("#,")
                                        .append("#Reason=").append(bean.getRemark()).append("#");
                                mp.put("templateid", rejectedCRAtemp);
                                sendMail(content.toString(), mp);
                            }
                        } else if (bean.getCmbchangestatus().equalsIgnoreCase(active)) // Active
                        {
                            if (!mp.isEmpty()) {
                                content.append("#InvestorName=").append(mp.get("APP_NAME").toString()).append("#,")
                                        .append("#PRAN=").append(mp.get("PRAN_NO").toString()).append("#,")
                                        .append("#Date=").append(mp.get("ENT_DATE").toString()).append("#");
//                                    .append("#Reason=").append(mp.get("REJECT_REASON").toString()).append("#");
                                mp.put("templateid", activetemp);
                                sendMail(content.toString(), mp);
                            }
                        } else if (bean.getCmbchangestatus().equalsIgnoreCase(ekycPending)) // ekycpending
                        {
                            npsRegPersonal.getPersonalData(convertFormBeanToNpsRegPersonalEntityBean(bean), sqltran);
                            npsRegAddress.getDeleteAddressData(convertFormBeanToNpsRegAddressEntityBean(bean), sqltran);
                            npsPranMaster.getupdatePran(convertFormBeanToNpsPranMasterEntityBean(bean), sqltran);

                            try {
                                SBCommonOperation sbCommon = SBCommonOperation.getSBCommonOperation();
                                String path = "NPS/NPS_MERGE_FILE/" + bean.getRefno() + "/" + bean.getRefno() + "_photo.jpg";
                                if (sbCommon.isFileExist(path)) {
                                    sbCommon.deleteFile(path);
                                }
                                path = "NPS/NPS_MERGE_FILE/" + bean.getRefno() + "/" + receiptno + ".pdf";
                                if (sbCommon.isFileExist(path)) {
                                    sbCommon.deleteFile(path);
                                }
                            } catch (Exception e) {
                                throw e;
                            }
                        } else if (bean.getCmbchangestatus().equalsIgnoreCase(paymentReceived)) {
                            bean.setPrevstatusid(prevstatus);
                            if (paymentlist != null && paymentlist.size() > 0) {
                                if (!((Map) paymentlist.get(0)).get("TIER_II_AMOUNT").toString().equalsIgnoreCase("NA")) {
                                    bean.setIstier2("Y");
                                } else {
                                    bean.setIstier2("N");
                                }
                            } else {
                                bean.setIstier2("N");
                            }
                            bean.setPaymentremark("Manually Verified By " + bean.getEmpcode());
                            npsPaymentGateway.getUpdatePayment(convertFormBeanToNpsPaymentEntityBean(bean), sqltran);
                            npsRegTrxn.getUpdateInvoiceNo(convertFormBeanToNpsRegTrxnEntityBean(bean), sqltran);
                            Map map = new HashMap();
                            map.put("REF_NO", bean.getHdnrefno());
                            map.put("STATUS_ID", bean.getCmbchangestatus());
                            genInvoice(map, sqltran);
                            sendNpsTaxInvoiceEmail(map, sqltran);
                        } else if (bean.getCmbchangestatus().equalsIgnoreCase(paymentfailed)) {
                            bean.setPrevstatusid(prevstatus);
                            if (paymentlist != null && paymentlist.size() > 0) {
                                if (!((Map) paymentlist.get(0)).get("TIER_II_AMOUNT").toString().equalsIgnoreCase("NA")) {
                                    bean.setIstier2("Y");
                                } else {
                                    bean.setIstier2("N");
                                }
                            } else {
                                bean.setIstier2("N");
                            }
                            npsRegTrxn.getUpdateInvoiceNo(convertFormBeanToNpsRegTrxnEntityBean(bean), sqltran);
                        }

                        flag = "S";
                        sqltran.commitChanges();
                    }
                }
            }

        } catch (Exception e) {
            if (sqltran != null) {
                sqltran.rollbackChanges();
            }
            throw e;
        } finally {
            if (sqltran != null) {
                sqltran.closeConn();
            }
        }

        return flag;
    }

    public NpsRegMainModel convertFormBeanToNpsMainEntityBean(CRAExportUtilityBean bean) {
        NpsRegMainModel entbean = new NpsRegMainModel();
        entbean.setRefno(bean.getHdnrefno());
        entbean.setStatusid(bean.getCmbchangestatus());
        entbean.setActivedate(bean.getTxtstatusdate());
        return entbean;
    }

    public NpsStatusChangeDtlModel convertFormBeanToNpsStatusEntityBean(CRAExportUtilityBean bean) {
        NpsStatusChangeDtlModel entbean = new NpsStatusChangeDtlModel();
        entbean.setRefno(bean.getHdnrefno());
        entbean.setStatusid(bean.getCmbchangestatus());
        entbean.setEmpcode(bean.getEmpcode());
        entbean.setRejectreason(bean.getRemark());
        entbean.setTxtstatusdate(bean.getTxtstatusdate());
        return entbean;
    }

    public NpsRegPersonalModel convertFormBeanToNpsRegPersonalEntityBean(CRAExportUtilityBean bean) {
        NpsRegPersonalModel entbean = new NpsRegPersonalModel();
        entbean.setRefno(bean.getHdnrefno());
        return entbean;
    }

    public NpsRegAddressModel convertFormBeanToNpsRegAddressEntityBean(CRAExportUtilityBean bean) {
        NpsRegAddressModel entbean = new NpsRegAddressModel();
        entbean.setRefno(bean.getHdnrefno());
        return entbean;
    }

    public NpsPranMasterModel convertFormBeanToNpsPranMasterEntityBean(CRAExportUtilityBean bean) {
        NpsPranMasterModel entbean = new NpsPranMasterModel();
        entbean.setRefno(bean.getHdnrefno());
        return entbean;
    }

    public NpsPaymentGatewayModel convertFormBeanToNpsPaymentEntityBean(CRAExportUtilityBean bean) {
        NpsPaymentGatewayModel entbean = new NpsPaymentGatewayModel();
        entbean.setPaymentid(bean.getTxtpaymentid());
        entbean.setPaymentRefNo(bean.getTxtpaymentrefno());
        entbean.setPaymentStatus(bean.getCmbchangestatus());
        entbean.setRemarks(bean.getPaymentremark());
        return entbean;
    }

    public NpsRegTrxnModel convertFormBeanToNpsRegTrxnEntityBean(CRAExportUtilityBean bean) {
        NpsRegTrxnModel entbean = new NpsRegTrxnModel();
        entbean.setPaymentid(bean.getTxtpaymentid());
        entbean.setStatusid(bean.getCmbchangestatus());
        entbean.setIstier2(bean.getIstier2());
        entbean.setPrevstatusid(bean.getPrevstatusid());
        return entbean;
    }

    public NpsCraExportHistoryModel convertFormBeanToNpsCRAExportEntityBean(CRAExportUtilityBean bean) {
        NpsCraExportHistoryModel entbean = new NpsCraExportHistoryModel();
        entbean.setEmpcode(bean.getEmpcode());
        entbean.setExportrefno(bean.getRefids());
        entbean.setFilename(bean.getFilename());
        entbean.setIpaddress(bean.getIpaddress());
        return entbean;
    }

    @Override
    public void sendMail(String content, Map map) {

        try {
            Map emailmp = new HashMap();
            emailmp.put("emailtempId", map.get("templateid").toString());
            emailmp.put("to", map.get("EMAIL_ID").toString());
            emailmp.put("bcc", bcc);
            emailmp.put("subjectValue", "N");
            emailmp.put("mailFromServer", finpack.FinPack.getProperty("java_server_name"));
            emailmp.put("content", content);
            new EmailSender().sendEmail(emailmp);
        } catch (Exception ex) {
            CommonMemberLog.appendLog("Exception in mail==>" + Pagging.CommonFunctions.getErrorStack(ex));
        }
    }

    @Override
    public List<Map<String, String>> getReportPaymentDtl(CRAExportUtilityBean bean) throws Exception {
        return craExportUtilityReport.getReportPaymentDtl(bean);
    }

    public String genInvoice(Map map, SQLTranUtility sqltran) throws Exception {
        String str = "Success";
        List lst = craExportUtilityReport.getNpsInvoiceAmntDetailContent(map, sqltran);
        String tempfile = finpack.FinPack.getProperty("tempfiles_path") + "NPS/" + map.get("REF_NO") + "_Invoice.pdf";
        String destfile = npsStoragePath + map.get("REF_NO") + "/" + map.get("REF_NO") + "_Invoice.pdf";

        File objFile = new File(tempfile);
        if (objFile.exists()) {
            objFile.delete();
            objFile = new File(tempfile);
        }
        new NpsInvoiceGenerator().generatePdf(lst, objFile, njNpsGstIn, hsnSacCode);

        CommonFunction.transferFileToStorageBox(objFile, destfile);

        return str;
    }

    public void sendNpsTaxInvoiceEmail(Map mp, SQLTranUtility sqltran) {
        try {
            StringBuilder content = new StringBuilder();
            String acctype = "";
            double totamount;
            List lst = craExportUtilityReport.getnpsInvoiceDetailContent(mp, sqltran);
            String getInvoiceFile = npsStoragePath + mp.get("REF_NO") + "/" + mp.get("REF_NO") + "_Invoice.pdf";

            if (lst != null && !lst.isEmpty()) {
                Map detailmp = (Map) lst.get(0);
                // Map detailmp = (Map) ndm.getnpsInvoiceDetailContent(mp);

                //Find acc type
                if (detailmp.get("TIER_I").toString().equalsIgnoreCase("Y")
                        && detailmp.get("TIER_II").toString().equalsIgnoreCase("N")) {
                    acctype = "TIER I";
                } else if (detailmp.get("TIER_I").toString().equalsIgnoreCase("Y")
                        && detailmp.get("TIER_II").toString().equalsIgnoreCase("Y")) {
                    acctype = "TIER I & TIER II";
                }

                detailmp.put("SUBBROCK", craExportUtilityReport.getpartner(mp));
                detailmp.put("ACCTYPE", acctype);
                //end acc type logic    

                //calculate total value
                totamount = Double.parseDouble(detailmp.get("TIER_I_AMOUNT").toString());
                totamount += Double.parseDouble(detailmp.get("TIER_II_AMOUNT").toString());

                detailmp.put("Investment_Amount", String.format("%.2f", totamount));

                totamount += Double.parseDouble(detailmp.get("Tier0_TRXN_CHRG").toString()); // ac opening charges
                totamount += Double.parseDouble(detailmp.get("Tier0_IGST_AMT").toString());
                totamount += Double.parseDouble(detailmp.get("Tier0_CGST_AMT").toString());
                totamount += Double.parseDouble(detailmp.get("Tier0_SGST_AMT").toString());

                totamount += Double.parseDouble(detailmp.get("Tier1_TRXN_CHRG").toString()); // Tier 1 Trxn charge
                totamount += Double.parseDouble(detailmp.get("Tier1_IGST_AMT").toString());
                totamount += Double.parseDouble(detailmp.get("Tier1_CGST_AMT").toString());
                totamount += Double.parseDouble(detailmp.get("Tier1_SGST_AMT").toString());

                totamount += Double.parseDouble(detailmp.get("Tier2_TRXN_CHRG").toString()); // Tier 2 Trxn charge
                totamount += Double.parseDouble(detailmp.get("Tier2_IGST_AMT").toString());
                totamount += Double.parseDouble(detailmp.get("Tier2_CGST_AMT").toString());
                totamount += Double.parseDouble(detailmp.get("Tier2_SGST_AMT").toString());
                //end calculate total value
                detailmp.put("TOTAMNT", String.format("%.2f", totamount));
                // detailmp.put("TOTAMNT", Math.round(totamount));
                content.append("#Table=").append(paymentDetailContent(detailmp)).append("#,")
                        .append("#NJGSTIN=").append(njNpsGstIn).append("#");

                Map emailmp = new HashMap();
                mp.put("TYPE", "BR");
                emailmp.put("emailtempId", npsInvoiceTempId);
                emailmp.put("to", craExportUtilityReport.getnpsresgistrationTOemailid(mp));
                emailmp.put("cc", craExportUtilityReport.getnpsresgistrationCCemailid(mp));
                emailmp.put("bcc", bcc);
                emailmp.put("subjectValue", null);
                emailmp.put("mailFromServer", finpack.FinPack.getProperty("java_server_name"));
                emailmp.put("attachment", getInvoiceFile);
                emailmp.put("content", content);
                new EmailSender().sendEmail(emailmp);
            }
        } catch (Exception e) {
            CommonMemberLog.appendLogFile("Exception in sendNpsTaxInvoiceEmail-->" + Pagging.CommonFunctions.getErrorStack(e));
        }
    }

    public String paymentDetailContent(Map mp) throws Exception {
        StringBuilder content = new StringBuilder();
        content.append(" <HTML> ")
                .append(" <BODY> ")
                .append("     <CENTER> ")
                .append("          <TABLE border = 1;  style='border: solid gray; width: 40%'>  ")
                .append("             <tr> <td width='40%'>Subscriber Name :</td>")
                .append("             <td width='60%'>").append(mp.get("EKYC_NAME") != null ? mp.get("EKYC_NAME").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>PRAN : </td>")
                .append("             <td width='60%'>").append(mp.get("PRAN_NO") != null ? mp.get("PRAN_NO").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>Reference Number :  </td>")
                .append("             <td width='60%'>").append(mp.get("RECEIPT_NO") != null ? mp.get("RECEIPT_NO").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>Tier I Payment Receipt Number :  </td>")
                .append("             <td width='60%'>").append(mp.get("TIER_I_RECEIPT_NO") != null ? mp.get("TIER_I_RECEIPT_NO").toString() : " ").append("</td></tr> ");

        if (!mp.get("TIER_II_RECEIPT_NO").toString().equalsIgnoreCase("NA")) {

            content.append("             <tr> <td width='40%'>Tier II Payment Receipt Number :  </td>")
                    .append("             <td width='60%'>").append(mp.get("TIER_II_RECEIPT_NO") != null ? mp.get("TIER_II_RECEIPT_NO").toString() : " ").append("</td></tr> ");
        }

        content.append("             <tr> <td width='40%'>Registration Date : </td>")
                .append("             <td width='60%'> ").append(mp.get("ENT_DATE") != null ? mp.get("ENT_DATE").toString() : " ").append(" </td></tr> ")
                .append("             <tr> <td width='40%'>Registered Mobile Number : </td>")
                .append("             <td width='60%'> ").append(mp.get("MOBILE") != null ? mp.get("MOBILE").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>Sub Broker Code : </td>")
                .append("             <td width='60%'> ").append(mp.get("SUBBROCK") != null ? mp.get("SUBBROCK").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>Account Type Opted for </td>")
                .append("             <td width='60%'> ").append(mp.get("ACCTYPE") != null ? mp.get("ACCTYPE").toString() : " ").append("</td></tr> ")
                .append("             <tr bgcolor='lightgray'> <td colspan='2'>Investment Details </td></tr> ")
                .append("             <tr> <td width='40%'>Tier : I</td>")
                .append("             <td width='60%'>").append(mp.get("TIER_I_AMOUNT") != null ? mp.get("TIER_I_AMOUNT").toString() : " ").append("</td></tr> ");

        if (mp.get("TIER_I").toString().equalsIgnoreCase("Y")
                && mp.get("TIER_II").toString().equalsIgnoreCase("Y")) {
            content.append("             <tr> <td width='40%'>Tier : II </td>")
                    .append("             <td width='60%'>").append(mp.get("TIER_II_AMOUNT") != null ? mp.get("TIER_II_AMOUNT").toString() : " ").append("</td></tr> ");
        }
        content.append("              <tr bgcolor='lightgray'> <td width='40%'>Investment Amount  </td>")
                .append("             <td width='60%'>").append(mp.get("Investment_Amount") != null ? mp.get("Investment_Amount").toString() : " ").append("</td></tr> ")
                .append("             <tr bgcolor='lightgray'> <td width='40%'>Tier : I Transaction Charges  </td>")
                .append("             <td width='60%'>").append(mp.get("Tier1_TRXN_CHRG") != null ? mp.get("Tier1_TRXN_CHRG").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>CGST</td><td width='60%'>").append(mp.get("Tier1_CGST_AMT") != null ? mp.get("Tier1_CGST_AMT").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>SGST</td><td width='60%'>").append(mp.get("Tier1_SGST_AMT") != null ? mp.get("Tier1_SGST_AMT").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>IGST</td><td width='60%'>").append(mp.get("Tier1_IGST_AMT") != null ? mp.get("Tier1_IGST_AMT").toString() : " ").append("</td></tr> ");

        if (mp.get("TIER_I").toString().equalsIgnoreCase("Y")
                && mp.get("TIER_II").toString().equalsIgnoreCase("Y")) {

            content.append("              <tr bgcolor='lightgray'> <td width='40%'>Tier : II Transaction Charges  </td>")
                    .append("             <td width='60%'>").append(mp.get("Tier2_TRXN_CHRG") != null ? mp.get("Tier2_TRXN_CHRG").toString() : " ").append("</td></tr> ")
                    .append("             <tr> <td width='40%'>CGST</td><td width='60%'>").append(mp.get("Tier2_CGST_AMT") != null ? mp.get("Tier2_CGST_AMT").toString() : " ").append("</td></tr> ")
                    .append("             <tr> <td width='40%'>SGST</td><td width='60%'>").append(mp.get("Tier2_SGST_AMT") != null ? mp.get("Tier2_SGST_AMT").toString() : " ").append("</td></tr> ")
                    .append("             <tr> <td width='40%'>IGST</td><td width='60%'>").append(mp.get("Tier2_IGST_AMT") != null ? mp.get("Tier2_IGST_AMT").toString() : " ").append("</td></tr> ");

        }
        content.append("              <tr bgcolor='lightgray'> <td width='40%'>Account Opening Charges  </td>")
                .append("             <td width='60%'>").append(mp.get("Tier0_TRXN_CHRG") != null ? mp.get("Tier0_TRXN_CHRG").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>CGST</td><td width='60%'>").append(mp.get("Tier0_CGST_AMT") != null ? mp.get("Tier0_CGST_AMT").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>SGST</td><td width='60%'>").append(mp.get("Tier0_SGST_AMT") != null ? mp.get("Tier0_SGST_AMT").toString() : " ").append("</td></tr> ")
                .append("             <tr> <td width='40%'>IGST</td><td width='60%'>").append(mp.get("Tier0_IGST_AMT") != null ? mp.get("Tier0_IGST_AMT").toString() : " ").append("</td></tr> ")
                .append("             <tr bgcolor='gray'> <td width='40%'>Total Amount :    </td>")
                .append("             <td width='60%'>").append(mp.get("TOTAMNT") != null ? mp.get("TOTAMNT").toString() : " ").append("</td></tr> ")
                .append("         </TABLE> ")
                .append("     </CENTER> ")
                .append(" </BODY>  ")
                .append(" </HTML>  ");

        return content.toString();
    }

    @Override
    public void getExportExcelFile(HttpServletRequest request, HttpServletResponse response, CRAExportUtilityBean bean) throws Exception {
        String downloadpath, color = "gray_50";
        int rowcnt = 0, colcnt = 0, i, srno;
        List lstrepo = craExportUtilityReport.getReportData(bean);

        downloadpath = finpack.FinPack.getProperty("tempfiles_path") + "NPS/" + bean.getEmpcode() + "_" + (CommonFunction.getCurrentDate(false)).replace("/", "") + ".xls";
        ExcelWrite out = new ExcelWrite(downloadpath);

        /*Header Column*/
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "Sr. No.", color);
        out.setColumnWidth(colcnt, 3000);
        colcnt++;
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "Status", color);
        out.setColumnWidth(colcnt, 3000);
        colcnt++;
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "Submission Date", color);
        out.setColumnWidth(colcnt, 5000);
        colcnt++;
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "Branch", color);
        out.setColumnWidth(colcnt, 5000);
        colcnt++;
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "Partner", color);
        out.setColumnWidth(colcnt, 3000);
        colcnt++;
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "Subscriber Name", color);
        out.setColumnWidth(colcnt, 5000);
        colcnt++;
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "NPS Ref.No", color);
        out.setColumnWidth(colcnt, 3000);
        colcnt++;
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("9")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "PAN", color);
            out.setColumnWidth(colcnt, 3000);
            colcnt++;
        }
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("10")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Aadhaar No", color);
            out.setColumnWidth(colcnt, 3000);
            colcnt++;
        }
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "PRAN NO", color);
        out.setColumnWidth(colcnt, 3000);
        colcnt++;
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("12")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Corr. Address", color);
            out.setColumnWidth(colcnt, 5000);
            colcnt++;
        }
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("13")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "City", color);
            out.setColumnWidth(colcnt, 3000);
            colcnt++;
        }
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("14")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "State", color);
            out.setColumnWidth(colcnt, 3000);
            colcnt++;
        }
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("15")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Country", color);
            out.setColumnWidth(colcnt, 3000);
            colcnt++;
        }
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "Tier", color);
        out.setColumnWidth(colcnt, 2000);
        colcnt++;
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("17")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Scheme Name", color);
            out.setColumnWidth(colcnt, 5000);
            colcnt++;
        }
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("18")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Bank Name", color);
            out.setColumnWidth(colcnt, 5000);
            colcnt++;
        }
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("19")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Bank Account No", color);
            out.setColumnWidth(colcnt, 5000);
            colcnt++;
        }
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("20")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Payment Received Date", color);
            out.setColumnWidth(colcnt, 5000);
            colcnt++;
        }
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "Investment Amount", color);
        out.setColumnWidth(colcnt, 5000);
        colcnt++;
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("22")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Transaction Charges", color);
            out.setColumnWidth(colcnt, 5000);
            colcnt++;
        }
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("23")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Txn. GST", color);
            out.setColumnWidth(colcnt, 3000);
            colcnt++;
        }
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("24")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Registration Charges", color);
            out.setColumnWidth(colcnt, 5000);
            colcnt++;
        }
        if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("25")) {
            out.writeHeaderBackGroundColor(colcnt, rowcnt, "Reg. GST", color);
            out.setColumnWidth(colcnt, 3000);
            colcnt++;
        }
        out.writeHeaderBackGroundColor(colcnt, rowcnt, "Total Amount", color);
        out.setColumnWidth(colcnt, 5000);

        rowcnt++;
        if (lstrepo != null && lstrepo.size() > 0) {
            Map map, nextmap = null;
            srno = 1;
            for (i = 0; i < lstrepo.size(); i++) {
                map = (Map) lstrepo.get(i);
                if (i < lstrepo.size() - 1) {
                    nextmap = (Map) lstrepo.get(i + 1);
                }
                colcnt = 0;

                if (nextmap != null && nextmap.get("TIER").toString().equalsIgnoreCase("TIER II")) {
                    out.writeStringCenter_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, srno + "");
                    colcnt++;
                    out.writeStringCenter_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("STATUS").toString());
                    colcnt++;
                    out.writeStringCenter_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("ENTDATE").toString());
                    colcnt++;
                    out.writeStringLeft_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("LOC_NAME").toString().equalsIgnoreCase("NA") ? "" : map.get("LOC_NAME").toString());
                    colcnt++;
                    out.writeStringLeft_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("PTN_NAME").toString().equalsIgnoreCase("NA") ? "" : map.get("PTN_NAME").toString());
                    colcnt++;
                    out.writeStringLeft_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("SUBS_NAME").toString().equalsIgnoreCase("NA") ? "" : map.get("SUBS_NAME").toString());
                    colcnt++;
                    out.writeStringCenter_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("REF_NO").toString());
                    colcnt++;

                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("9")) {
                        out.writeStringCenter_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("PAN").toString().equalsIgnoreCase("NA") ? "" : map.get("PAN").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("10")) {
                        out.writeStringCenter_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("UID").toString().equalsIgnoreCase("NA") ? "" : map.get("UID").toString());
                        colcnt++;
                    }
                    out.writeStringCenter_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("PRAN_NO").toString().equalsIgnoreCase("NA") ? "" : map.get("PRAN_NO").toString());
                    colcnt++;
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("12")) {
                        out.writeStringLeft_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("CORR_ADDRESS").toString().equalsIgnoreCase("NA") ? "" : map.get("CORR_ADDRESS").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("13")) {
                        out.writeStringLeft_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("CORR_CITY").toString().equalsIgnoreCase("NA") ? "" : map.get("CORR_CITY").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("14")) {
                        out.writeStringLeft_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("CORR_STATE").toString().equalsIgnoreCase("NA") ? "" : map.get("CORR_STATE").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("15")) {
                        out.writeStringLeft_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("CORR_CNTRY").toString().equalsIgnoreCase("NA") ? "" : map.get("CORR_CNTRY").toString());
                        colcnt++;
                    }
                    out.writestringcontentCenter(colcnt, rowcnt, map.get("TIER").toString());
                    colcnt++;
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("17")) {
                        out.writestringcontentCenter(colcnt, rowcnt, map.get("SCHEME_NAME").toString().equalsIgnoreCase("NA") ? "" : map.get("SCHEME_NAME").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("18")) {
                        out.writestringcontent_left(colcnt, rowcnt, map.get("BANK_NAME").toString().equalsIgnoreCase("NA") ? "" : map.get("BANK_NAME").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("19")) {
                        out.writestringcontentCenter(colcnt, rowcnt, map.get("ACCNO").toString().equalsIgnoreCase("NA") ? "" : map.get("ACCNO").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("20")) {
                        out.writestringcontentCenter(colcnt, rowcnt, map.get("PAYMENT_DATE").toString().equalsIgnoreCase("NA") ? "" : map.get("PAYMENT_DATE").toString());
                        colcnt++;
                    }
                    out.writestringcontent_right(colcnt, rowcnt, map.get("INVEST_AMOUNT").toString().equalsIgnoreCase("NA") ? "" : map.get("INVEST_AMOUNT").toString());
                    colcnt++;
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("22")) {
                        out.writestringcontent_right(colcnt, rowcnt, map.get("TRXN_CHARGE").toString().equalsIgnoreCase("NA") ? "" : map.get("TRXN_CHARGE").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("23")) {
                        out.writestringcontent_right(colcnt, rowcnt, map.get("TXN_GST").toString().equalsIgnoreCase("NA") ? "" : map.get("TXN_GST").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("24")) {
                        out.writeStringRight_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("REG_CHARGE").toString().equalsIgnoreCase("NA") ? "" : map.get("REG_CHARGE").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("25")) {
                        out.writeStringRight_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("REG_GST").toString().equalsIgnoreCase("NA") ? "" : map.get("REG_GST").toString());
                        colcnt++;
                    }
                    out.writeStringRight_Colspan_Rowspan(colcnt, rowcnt, colcnt, rowcnt + 1, map.get("NET_AMOUNT").toString().equalsIgnoreCase("NA") ? "" : map.get("NET_AMOUNT").toString());
                    colcnt++;
                } else {
                    out.writestringcontentCenter(colcnt, rowcnt, srno + "");
                    colcnt++;
                    out.writestringcontentCenter(colcnt, rowcnt, map.get("STATUS").toString());
                    colcnt++;
                    out.writestringcontentCenter(colcnt, rowcnt, map.get("ENTDATE").toString());
                    colcnt++;
                    out.writestringcontent_left(colcnt, rowcnt, map.get("LOC_NAME").toString().equalsIgnoreCase("NA") ? "" : map.get("LOC_NAME").toString());
                    colcnt++;
                    out.writestringcontent_left(colcnt, rowcnt, map.get("PTN_NAME").toString().equalsIgnoreCase("NA") ? "" : map.get("PTN_NAME").toString());
                    colcnt++;
                    out.writestringcontent_left(colcnt, rowcnt, map.get("SUBS_NAME").toString().equalsIgnoreCase("NA") ? "" : map.get("SUBS_NAME").toString());
                    colcnt++;
                    out.writestringcontentCenter(colcnt, rowcnt, map.get("REF_NO").toString());
                    colcnt++;

                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("9")) {
                        out.writestringcontentCenter(colcnt, rowcnt, map.get("PAN").toString().equalsIgnoreCase("NA") ? "" : map.get("PAN").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("10")) {
                        out.writestringcontentCenter(colcnt, rowcnt, map.get("UID").toString().equalsIgnoreCase("NA") ? "" : map.get("UID").toString());
                        colcnt++;
                    }
                    out.writestringcontentCenter(colcnt, rowcnt, map.get("PRAN_NO").toString().equalsIgnoreCase("NA") ? "" : map.get("PRAN_NO").toString());
                    colcnt++;
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("12")) {
                        out.writestringcontent_left(colcnt, rowcnt, map.get("CORR_ADDRESS").toString().equalsIgnoreCase("NA") ? "" : map.get("CORR_ADDRESS").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("13")) {
                        out.writestringcontent_left(colcnt, rowcnt, map.get("CORR_CITY").toString().equalsIgnoreCase("NA") ? "" : map.get("CORR_CITY").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("14")) {
                        out.writestringcontent_left(colcnt, rowcnt, map.get("CORR_STATE").toString().equalsIgnoreCase("NA") ? "" : map.get("CORR_STATE").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("15")) {
                        out.writestringcontent_left(colcnt, rowcnt, map.get("CORR_CNTRY").toString().equalsIgnoreCase("NA") ? "" : map.get("CORR_CNTRY").toString());
                        colcnt++;
                    }
                    out.writestringcontentCenter(colcnt, rowcnt, map.get("TIER").toString());
                    colcnt++;
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("17")) {
                        out.writestringcontentCenter(colcnt, rowcnt, map.get("SCHEME_NAME").toString().equalsIgnoreCase("NA") ? "" : map.get("SCHEME_NAME").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("18")) {
                        out.writestringcontent_left(colcnt, rowcnt, map.get("BANK_NAME").toString().equalsIgnoreCase("NA") ? "" : map.get("BANK_NAME").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("19")) {
                        out.writestringcontentCenter(colcnt, rowcnt, map.get("ACCNO").toString().equalsIgnoreCase("NA") ? "" : map.get("ACCNO").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("20")) {
                        out.writestringcontentCenter(colcnt, rowcnt, map.get("PAYMENT_DATE").toString().equalsIgnoreCase("NA") ? "" : map.get("PAYMENT_DATE").toString());
                        colcnt++;
                    }
                    out.writestringcontent_right(colcnt, rowcnt, map.get("INVEST_AMOUNT").toString().equalsIgnoreCase("NA") ? "" : map.get("INVEST_AMOUNT").toString());
                    colcnt++;
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("22")) {
                        out.writestringcontent_right(colcnt, rowcnt, map.get("TRXN_CHARGE").toString().equalsIgnoreCase("NA") ? "" : map.get("TRXN_CHARGE").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("23")) {
                        out.writestringcontent_right(colcnt, rowcnt, map.get("TXN_GST").toString().equalsIgnoreCase("NA") ? "" : map.get("TXN_GST").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("24")) {
                        out.writestringcontent_right(colcnt, rowcnt, map.get("REG_CHARGE").toString().equalsIgnoreCase("NA") ? "" : map.get("REG_CHARGE").toString());
                        colcnt++;
                    }
                    if (bean.getCmbreportcol() != null && Arrays.asList((bean.getCmbreportcol()).split(",")).contains("25")) {
                        out.writestringcontent_right(colcnt, rowcnt, map.get("REG_GST").toString().equalsIgnoreCase("NA") ? "" : map.get("REG_GST").toString());
                        colcnt++;
                    }
                    out.writestringcontent_right(colcnt, rowcnt, map.get("NET_AMOUNT").toString().equalsIgnoreCase("NA") ? "" : map.get("NET_AMOUNT").toString());
                    colcnt++;
                    srno++;
                }
                rowcnt++;
            }
        } else {
            out.writestringCenter(0, rowcnt, colcnt, rowcnt, "No Record Found");
        }
        out.writeworkbook();
        CommonFunction.getDownloadFileFromStaorageBox(request, response, "", downloadpath);
    }

    @Override
    public void getGenerateFileReport(HttpServletRequest request, HttpServletResponse response, CRAExportUtilityBean bean) throws Exception {

        int i, j, colCount = 0;
        ArrayList columnlist = new ArrayList();
        Map datamap = new HashMap();
        String finalrefid = "";
        String tempfilepath = finpack.FinPack.getProperty("tempfiles_path") + "NPS/";
        String rettemppath = "";
        boolean photosflag = false;
        boolean signflag = false;
        SessionBean sessionBean = CommonFunction.getSessionBean(request);
        HttpSession session = request.getSession(false);

        String zipfilename = sessionBean.getUsername() + "_" + (CommonFunction.getCurrentDate(true)).replace("/", "") + ".zip";
        List tmplist = new ArrayList();
        if (bean.getRefids().contains("-")) {
            String refids[] = bean.getRefids().split("-");
            for (i = 0; i < refids.length; i++) {
                bean.setRefno(refids[i]);
                tmplist = craExportUtilityReport.getDataUsingRefNo(bean);
                datamap = (Map) tmplist.get(0);
                if (datamap.get("STATUS_ID").toString().equalsIgnoreCase("7") || datamap.get("STATUS_ID").toString().equalsIgnoreCase("9") || datamap.get("STATUS_ID").toString().equalsIgnoreCase("12")) {
                    if (!finalrefid.isEmpty()) {
                        finalrefid = finalrefid + ",";
                    }
                    finalrefid = finalrefid + refids[i];
                }
                datamap.clear();
            }
        } else {
            bean.setRefno(bean.getRefids());
            tmplist = craExportUtilityReport.getDataUsingRefNo(bean);
            datamap = (Map) tmplist.get(0);
            if (datamap.get("STATUS_ID").toString().equalsIgnoreCase("7") || datamap.get("STATUS_ID").toString().equalsIgnoreCase("9") || datamap.get("STATUS_ID").toString().equalsIgnoreCase("12")) {
                finalrefid = bean.getRefids();
            }
            datamap.clear();
        }
        if (!finalrefid.isEmpty()) {
            String filename = "NPSREG" + (CommonFunction.getCurrentDate(true)).replace("/", "") + ".xls";
            String downloadpath = tempfilepath + filename;

            /*Update Acknoledgement Number If Not available */
            String refidarray[] = finalrefid.split(",");
            for (i = 0; i < refidarray.length; i++) {
                craExportUtilityReport.getAckNumber(refidarray[i]);
            }
            /**/
            List<Map<String, String>> lstreport = craExportUtilityReport.getGenerateFileReport(finalrefid);

            File excelFile = new File(downloadpath);
            FileOutputStream fos = new FileOutputStream(excelFile, true);
            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet worksheet = workbook.createSheet();
            XSSFRow headerRow = null;
            XSSFCell headerCell = null;

            XSSFFont boldFont = workbook.createFont();
            boldFont.setFontName(XSSFFont.DEFAULT_FONT_NAME);
            boldFont.setFontHeight(10);
            boldFont.setBold(true);

            XSSFFont normalFont = workbook.createFont();
            normalFont.setFontName(XSSFFont.DEFAULT_FONT_NAME);
            normalFont.setFontHeight(10);

            XSSFCellStyle cellBoldStyle = workbook.createCellStyle();
            cellBoldStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
            cellBoldStyle.setVerticalAlignment((short) 1);
            cellBoldStyle.setFont(boldFont);

            XSSFCellStyle cellNormalStyle = workbook.createCellStyle();
            cellNormalStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
            cellNormalStyle.setVerticalAlignment((short) 1);
            cellNormalStyle.setFont(normalFont);

            headerRow = worksheet.createRow(0);
            for (Map<String, String> map : lstreport) {
                for (Map.Entry<String, String> mapEntry : map.entrySet()) {
                    headerCell = headerRow.createCell(colCount);
                    headerCell.setCellValue(mapEntry.getKey());
                    headerCell.setCellStyle(cellBoldStyle);
                    worksheet.autoSizeColumn(colCount);
                    columnlist.add(mapEntry.getKey());
                    colCount++;
                }
                break;
            }

            if (lstreport != null && lstreport.size() > 0) {
                for (i = 0; i < lstreport.size(); i++) {
                    datamap = (Map) lstreport.get(i);
                    headerRow = worksheet.createRow(i + 1);
                    for (j = 0; j < columnlist.size(); j++) {
                        headerCell = headerRow.createCell(j);
                        headerCell.setCellValue(datamap.get(columnlist.get(j)).toString());
                        headerCell.setCellStyle(cellNormalStyle);
                        worksheet.autoSizeColumn(j);
                    }

                }
            } else {
                XSSFCellStyle cellNoRecors = workbook.createCellStyle();
                cellNormalStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
                cellNormalStyle.setVerticalAlignment((short) 1);
                cellNormalStyle.setFont(normalFont);

                headerRow = worksheet.createRow(1);
                headerCell = headerRow.createCell(0);
                headerCell.setCellValue("No Records Founds");
                headerCell.setCellStyle(cellNoRecors);
                worksheet.addMergedRegion(new CellRangeAddress(1, 1, 0, colCount - 1));

            }
            workbook.write(fos);
            fos.close();
            datamap.clear();

//        try {
            SBCommonOperation sbCommon = SBCommonOperation.getSBCommonOperation();

            FileOutputStream zipfos;
            ZipOutputStream zipzos;

            FileOutputStream photofos;
            ZipOutputStream photozos;

            FileOutputStream signfos;
            ZipOutputStream signzos;

            /* Main Zip*/
            zipfos = new FileOutputStream(tempfilepath + zipfilename);
            zipzos = new ZipOutputStream(zipfos);
            /*End*/

            File tempfile;
            tempfile = new File(tempfilepath + "PHOTOS.zip");
            if (tempfile.exists()) {
                tempfile.delete();
            }
            tempfile = new File(tempfilepath + "SIGN.zip");
            if (tempfile.exists()) {
                tempfile.delete();
            }
            tempfile = new File(tempfilepath + "REG_FORMS");
            if (tempfile.exists()) {
                CommonFunction.deleteFileWithFolder(tempfile);
            }

            /* Photo and Sign Zip*/
            photofos = new FileOutputStream(tempfilepath + "PHOTOS.zip");
            photozos = new ZipOutputStream(photofos);

            signfos = new FileOutputStream(tempfilepath + "SIGN.zip");
            signzos = new ZipOutputStream(signfos);
            tmplist = craExportUtilityReport.getPersonalDtl(finalrefid);
            if (tmplist != null && tmplist.size() > 0) {
                File pdffolder = new File(tempfilepath + "REG_FORMS");
                if (!pdffolder.exists()) {
                    pdffolder.mkdir();
                }
                for (i = 0; i < tmplist.size(); i++) {
                    datamap = (Map) tmplist.get(i);
                    if (!datamap.get("RECEIPT_NO").toString().isEmpty()) {
                        rettemppath = sbCommon.getFile(npsStoragePath + datamap.get("REF_NO").toString() + "/" + datamap.get("RECEIPT_NO").toString() + "_eSign.pdf");
                        FileUtils.copyFile(new File(rettemppath), new File(tempfilepath + "REG_FORMS/" + datamap.get("RECEIPT_NO").toString() + ".pdf"));
                    }
                    if (!datamap.get("EKYC_IMAGE_NAME").toString().isEmpty()) {
                        rettemppath = sbCommon.getFile(npsStoragePath + datamap.get("REF_NO").toString() + "/" + datamap.get("EKYC_IMAGE_NAME").toString());
                        FileUtils.copyFile(new File(rettemppath), new File(tempfilepath + datamap.get("RECEIPT_NO").toString() + ".jpg"));
                        FolderZipper.addFileToZip("", tempfilepath + datamap.get("RECEIPT_NO").toString() + ".jpg", photozos);
                        photosflag = true;
                    }
                    if (!datamap.get("BO_FILE_NAME").toString().isEmpty()) {
                        rettemppath = sbCommon.getFile(npsStoragePath + datamap.get("REF_NO").toString() + "/" + datamap.get("BO_FILE_NAME").toString());

                        int scaledWidth = 260;
                        int scaledHeight = 107;
                        CommonFunction.convertImageToFixSize(rettemppath, tempfilepath + datamap.get("RECEIPT_NO").toString() + ".jpg", scaledWidth, scaledHeight);

                        FolderZipper.addFileToZip("", tempfilepath + datamap.get("RECEIPT_NO").toString() + ".jpg", signzos);
                        signflag = true;
                    }
                }
            }
            photozos.flush();
            photozos.close();
            signzos.flush();
            signzos.close();
            /*End*/

            FolderZipper.addFileToZip("", tempfilepath + filename, zipzos);
            FolderZipper.addFolderToZip("", tempfilepath + "REG_FORMS", zipzos);
            if (photosflag) {
                FolderZipper.addFileToZip("", tempfilepath + "PHOTOS.zip", zipzos);
            }
            if (signflag) {
                FolderZipper.addFileToZip("", tempfilepath + "SIGN.zip", zipzos);
            }
            zipzos.flush();
            zipzos.close();

            try {
                sqltran.openConn(ALIAS);
                bean.setHdnrefno(finalrefid);
                bean.setFilename(zipfilename);
                bean.setIpaddress(CommonFunction.getIpAddr(request));
                bean.setRefids(finalrefid);

                npsRegMain.getUpdateExportDate(convertFormBeanToNpsMainEntityBean(bean), sqltran);
                npscraexporthistory.getInsertExportHistory(convertFormBeanToNpsCRAExportEntityBean(bean), sqltran);
                sqltran.commitChanges();
                CommonFunction.getDownloadFileFromStaorageBox(request, response, "", tempfilepath + zipfilename);
            } catch (Exception e) {
                if (sqltran != null) {
                    sqltran.rollbackChanges();
                }
                throw e;
            } finally {
                if (sqltran != null) {
                    sqltran.closeConn();
                }
            }
        }

//        } catch (Exception e) {
//            throw e;
//        }
    }

}
