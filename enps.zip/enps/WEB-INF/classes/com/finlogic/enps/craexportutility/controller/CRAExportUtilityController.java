/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.craexportutility.controller;

import com.finlogic.enps.commons.util.CommonFunction;
import com.finlogic.enps.commons.util.SBCommonOperation;
import com.finlogic.enps.craexportutility.bean.CRAExportUtilityBean;
import com.finlogic.enps.craexportutility.service.CRAExportUtilityService;
import com.finlogic.enps.session.model.SessionBean;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author ankur7
 */
@Controller
@RequestMapping(value = "craexportutility.fin")
public class CRAExportUtilityController {

    @Autowired
    @Qualifier(value = "CRAExportUtilityService")
    private CRAExportUtilityService craExportUtilityService;

    private static String storagepath;

    @Value("${nps_storagepath}")
    public void setDbAlias(String storagepath) {
        CRAExportUtilityController.storagepath = storagepath;
    }

    @ModelAttribute
    public void init(Model model) {
        model.addAttribute("currentdate", CommonFunction.getCurrentDate(false));
    }

    @RequestMapping(method = RequestMethod.GET)
    public String defaultMethod(Model model) throws Exception {
        String view = "craexportutility/craexportutility";
        model.addAttribute("branchlist", craExportUtilityService.getBranchList());
        model.addAttribute("statuslist", craExportUtilityService.getStatusList());
        return view;
    }

    @RequestMapping(params = "cmdAction=getPartnerList", method = RequestMethod.POST)
    public String getPartnerList(Model model, CRAExportUtilityBean bean) throws Exception {
        String view = "craexportutility/craexportutilityajax";
        model.addAttribute("partnerlist", craExportUtilityService.getPartnerList(bean));
        model.addAttribute("action", "getPartner");
        return view;
    }

    @RequestMapping(params = "cmdAction=getReportData", method = RequestMethod.POST)
    public String getReportData(Model model, CRAExportUtilityBean bean) throws Exception {
        String view = "craexportutility/craexportutilityajax";
        String reportHeaading = "NPS Registration Report | ";
        if (bean.getTxtinputtext() != null && !bean.getTxtinputtext().isEmpty()) {
            reportHeaading = reportHeaading + "Search By : " + bean.getTxtinputtext().trim();
        } else {
            reportHeaading = reportHeaading + "PERIOD : " + bean.getTxtfromdate() + " To " + bean.getTxttodate();
        }
        model.addAttribute("reportlist", craExportUtilityService.getReportData(bean));
        model.addAttribute("heading", reportHeaading);
        model.addAttribute("action", "getReport");
        return view;
    }

    @RequestMapping(params = "cmdAction=getStatusDtl", method = RequestMethod.POST)
    public String getStatusDtl(Model model, CRAExportUtilityBean bean) throws Exception {
        String view = "craexportutility/craexportutilityajax";
        model.addAttribute("statusdtllist", craExportUtilityService.getStatusDtl(bean));
        model.addAttribute("action", "getstatusdtl");
        return view;
    }

    @RequestMapping(params = "cmdAction=getViewDtl", method = RequestMethod.POST)
    public String getViewDtl(Model model, CRAExportUtilityBean bean) throws Exception {
        String view = "craexportutility/craexportutilityajax";
        List primarylst, tierlst;
        String njacno, bankcode;
        primarylst = craExportUtilityService.getPrimaryAddressContactOtherFatcaDtl(bean);
        tierlst = craExportUtilityService.getTierDtl(bean);
        model.addAttribute("priAddrContOtrFtcaLst", primarylst);
        model.addAttribute("eKyceSignDtl", craExportUtilityService.geteKycAndeSignDtl(bean));
        model.addAttribute("fatcaTinDtl", craExportUtilityService.getFatcaTinDtl(bean));
        model.addAttribute("tierDtl", tierlst);
        model.addAttribute("nomineeDtl", craExportUtilityService.getNomineeDtl(bean));
        model.addAttribute("paymentDtl", craExportUtilityService.getPaymentDtl(bean));
        model.addAttribute("allowedstatuslst", craExportUtilityService.getAllowedStatusList(bean));

        if (tierlst != null && tierlst.size() > 0) {
            Map map = (Map) tierlst.get(0);
            njacno = map.get("ENT_BY").toString();
            bankcode = map.get("NJ_BANKCODE").toString();
            model.addAttribute("tradingbankdtl", craExportUtilityService.getTradingBankDetail(bankcode, njacno));
        }

        if (primarylst != null && primarylst.size() > 0) {
            String name = ((Map) primarylst.get(0)).get("EKYC_IMAGE_NAME").toString();
//                String imgurl = "craexportutility.fin?cmdAction=getEkycImage&refno=" + bean.getRefno();
            String bioimg = ((Map) primarylst.get(0)).get("BO_FILE_NAME").toString();
            String bioimgname = "";
            String kycimgname = "";
            if (!name.equalsIgnoreCase("NA")) {
                kycimgname = "craexportutility.fin?cmdAction=getEkycImage&refno=" + bean.getRefno();

            }
            if (!bioimg.equalsIgnoreCase("NA")) {
                bioimgname = "craexportutility.fin?cmdAction=getBioSignImage&refno=" + bean.getRefno() + "&bioimgname=" + bioimg;

            }
            model.addAttribute("ekycimage", kycimgname);
            model.addAttribute("bioimage", bioimgname);
        }

        model.addAttribute("action", "getView");
        return view;
    }

    @RequestMapping(params = "cmdAction=getDownloadFile", method = RequestMethod.GET)
    public void getDownloadFile(HttpServletRequest request, HttpServletResponse response, CRAExportUtilityBean bean) throws Exception {
        SBCommonOperation sbCommon = SBCommonOperation.getSBCommonOperation();
        String temp_path = "";
        bean.setRefno(request.getParameter("refno"));
        String action = request.getParameter("action");
        if (action.equalsIgnoreCase("bankcopy1")) {
            List banklst = craExportUtilityService.getBankProof(bean, "1");
            if (banklst != null && banklst.size() > 0) {
                String bankproof = ((Map) banklst.get(0)).get("BANK_PROOF").toString();
                temp_path = sbCommon.getFile(storagepath + bean.getRefno() + "/" + bankproof);
            }
        } else if (action.equalsIgnoreCase("bankcopy2")) {
            List banklst = craExportUtilityService.getBankProof(bean, "2");
            if (banklst != null && banklst.size() > 0) {
                String bankproof = ((Map) banklst.get(0)).get("BANK_PROOF").toString();
                temp_path = sbCommon.getFile(storagepath + bean.getRefno() + "/" + bankproof);
            }
        } else if (action.equalsIgnoreCase("pancopy2")) {
            List banklst = craExportUtilityService.getBankProof(bean, "2");
            if (banklst != null && banklst.size() > 0) {
                String panproof = ((Map) banklst.get(0)).get("PAN_COPY").toString();
                temp_path = sbCommon.getFile(storagepath + bean.getRefno() + "/" + panproof);
            }
        } else if (action.equalsIgnoreCase("esign")) {
            String receiptnumber = craExportUtilityService.getReceiptNumber(bean);
            if (receiptnumber != null && !receiptnumber.trim().equalsIgnoreCase("")) {
                temp_path = sbCommon.getFile(storagepath + bean.getRefno() + "/" + receiptnumber + "_eSign.pdf");
            }
        } else if (action.equalsIgnoreCase("invoice")) {
            temp_path = sbCommon.getFile(storagepath + bean.getRefno() + "/" + bean.getRefno() + "_Invoice.pdf");
        }
        CommonFunction.getDownloadFileFromStaorageBox(request, response, "", temp_path);
    }

    @RequestMapping(params = "cmdAction=getDataSave", method = RequestMethod.POST)
    public @ResponseBody
    String getDataSave(HttpServletRequest request, HttpServletResponse response, CRAExportUtilityBean bean) throws Exception {
        String returnfalg = "F";
        SessionBean sessionBean = CommonFunction.getSessionBean(request);
        if (sessionBean.getMecode() != null && !sessionBean.getMecode().isEmpty()) {
            bean.setEmpcode(sessionBean.getMecode());
            String flag = craExportUtilityService.getDataSave(bean);
            returnfalg = flag;
        }
        return returnfalg;
    }

    @RequestMapping(params = "cmdAction=getEkycImage", method = RequestMethod.GET)
    public void getEkycImage(HttpServletRequest request, HttpServletResponse response, CRAExportUtilityBean bean) throws Exception {
        SBCommonOperation sbCommon = SBCommonOperation.getSBCommonOperation();
        String temp_path = sbCommon.getFile(storagepath + bean.getRefno() + "/" + bean.getRefno() + "_photo.jpg");
        CommonFunction.getDownloadFileFromStaorageBox(request, response, "inline", temp_path);
    }

    @RequestMapping(params = "cmdAction=getBioSignImage", method = RequestMethod.GET)
    public void getBioSignImage(HttpServletRequest request, HttpServletResponse response, CRAExportUtilityBean bean) throws Exception {
        SBCommonOperation sbCommon = SBCommonOperation.getSBCommonOperation();
        String temp_path = sbCommon.getFile(storagepath + bean.getRefno() + "/" + request.getParameter("bioimgname"));
        CommonFunction.getDownloadFileFromStaorageBox(request, response, "inline", temp_path);
    }

    @RequestMapping(params = "cmdAction=getReportPaymentDtl", method = RequestMethod.POST)
    public String getReportPaymentDtl(Model model, CRAExportUtilityBean bean) throws Exception {
        if (bean.getHdnrefno() != null && !bean.getHdnrefno().isEmpty() && bean.getTxtpaymentid() != null && !bean.getTxtpaymentid().isEmpty()) {
            model.addAttribute("action", "getRepPayment");
            model.addAttribute("paymentdtllst", craExportUtilityService.getReportPaymentDtl(bean));
        }
        return "craexportutility/craexportutilityajax";
    }

    @RequestMapping(params = "cmdAction=getExportData", method = RequestMethod.GET)
    public void getExportData(HttpServletRequest request, HttpServletResponse response, CRAExportUtilityBean bean) throws Exception {
        SessionBean sessionBean = CommonFunction.getSessionBean(request);
        bean.setEmpcode(sessionBean.getMecode());
        craExportUtilityService.getExportExcelFile(request, response, bean);

    }

    @RequestMapping(params = "cmdAction=getGenerateData", method = RequestMethod.GET)
    public void getGenerateData(HttpServletRequest request, HttpServletResponse response, CRAExportUtilityBean bean) throws Exception {
        SessionBean sessionBean = CommonFunction.getSessionBean(request);
        bean.setEmpcode(sessionBean.getMecode());
        craExportUtilityService.getGenerateFileReport(request, response, bean);

    }
}
