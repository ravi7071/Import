/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.craexportutility.bean;

/**
 *
 * @author roshan4
 */
public class CRAExportUtilityBean {

    private String txtinputtext;
    private String cmbbranch;
    private String cmbstatus;
    private String cmbpartner;
    private String rdotierchoice;
    private String txtfromdate;
    private String txttodate;
    private String txttextlike;
    private String refno;
    private String hdnrefno;
    private String cmbchangestatus;
    private String remark;
    private String empcode;
    private String txtpaymentid;
    private String txtpaymentrefno;
    private String paymentremark;
    private String rdoreportchoice;
    private String txtstatusdate;
    private String cmbreportcol;
    private String refids;
    private String filename;
    private String ipaddress;
    private String istier2;
    private String prevstatusid;

    public String getTxtinputtext() {
        return txtinputtext;
    }

    public void setTxtinputtext(String txtinputtext) {
        this.txtinputtext = txtinputtext;
    }

    public String getCmbbranch() {
        return cmbbranch;
    }

    public void setCmbbranch(String cmbbranch) {
        this.cmbbranch = cmbbranch;
    }

    public String getCmbstatus() {
        return cmbstatus;
    }

    public void setCmbstatus(String cmbstatus) {
        this.cmbstatus = cmbstatus;
    }

    public String getCmbpartner() {
        return cmbpartner;
    }

    public void setCmbpartner(String cmbpartner) {
        this.cmbpartner = cmbpartner;
    }

    public String getRdotierchoice() {
        return rdotierchoice;
    }

    public void setRdotierchoice(String rdotierchoice) {
        this.rdotierchoice = rdotierchoice;
    }

    public String getTxtfromdate() {
        return txtfromdate;
    }

    public void setTxtfromdate(String txtfromdate) {
        this.txtfromdate = txtfromdate;
    }

    public String getTxttodate() {
        return txttodate;
    }

    public void setTxttodate(String txttodate) {
        this.txttodate = txttodate;
    }

    public String getTxttextlike() {
        return txttextlike;
    }

    public void setTxttextlike(String txttextlike) {
        this.txttextlike = txttextlike;
    }

    public String getRefno() {
        return refno;
    }

    public void setRefno(String refno) {
        this.refno = refno;
    }

    public String getHdnrefno() {
        return hdnrefno;
    }

    public void setHdnrefno(String hdnrefno) {
        this.hdnrefno = hdnrefno;
    }

    public String getCmbchangestatus() {
        return cmbchangestatus;
    }

    public void setCmbchangestatus(String cmbchangestatus) {
        this.cmbchangestatus = cmbchangestatus;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getEmpcode() {
        return empcode;
    }

    public void setEmpcode(String empcode) {
        this.empcode = empcode;
    }

    public String getTxtpaymentid() {
        return txtpaymentid;
    }

    public void setTxtpaymentid(String txtpaymentid) {
        this.txtpaymentid = txtpaymentid;
    }

    public String getTxtpaymentrefno() {
        return txtpaymentrefno;
    }

    public void setTxtpaymentrefno(String txtpaymentrefno) {
        this.txtpaymentrefno = txtpaymentrefno;
    }

    public String getPaymentremark() {
        return paymentremark;
    }

    public void setPaymentremark(String paymentremark) {
        this.paymentremark = paymentremark;
    }

    public String getRdoreportchoice() {
        return rdoreportchoice;
    }

    public void setRdoreportchoice(String rdoreportchoice) {
        this.rdoreportchoice = rdoreportchoice;
    }

    public String getTxtstatusdate() {
        return txtstatusdate;
    }

    public void setTxtstatusdate(String txtstatusdate) {
        this.txtstatusdate = txtstatusdate;
    }

    public String getCmbreportcol() {
        return cmbreportcol;
    }

    public void setCmbreportcol(String cmbreportcol) {
        this.cmbreportcol = cmbreportcol;
    }

    public String getRefids() {
        return refids;
    }

    public void setRefids(String refids) {
        this.refids = refids;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getIpaddress() {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    public String getIstier2() {
        return istier2;
    }

    public void setIstier2(String istier2) {
        this.istier2 = istier2;
    }

    public String getPrevstatusid() {
        return prevstatusid;
    }

    public void setPrevstatusid(String prevstatusid) {
        this.prevstatusid = prevstatusid;
    }
}
