/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npscraexporthistory.model;

/**
 *
 * @author roshan4
 */
public class NpsCraExportHistoryModel {
    
    private String filename;
    private String ipaddress;
    private String exportrefno;
    private String empcode;

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getIpaddress() {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    public String getExportrefno() {
        return exportrefno;
    }

    public void setExportrefno(String exportrefno) {
        this.exportrefno = exportrefno;
    }

    public String getEmpcode() {
        return empcode;
    }

    public void setEmpcode(String empcode) {
        this.empcode = empcode;
    }
    
}
