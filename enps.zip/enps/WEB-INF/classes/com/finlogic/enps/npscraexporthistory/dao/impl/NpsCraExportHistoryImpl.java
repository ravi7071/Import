/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npscraexporthistory.dao.impl;

import com.finlogic.enps.npscraexporthistory.dao.NpsCraExportHistory;
import com.finlogic.enps.npscraexporthistory.model.NpsCraExportHistoryModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "NpsCraExportHistory")
public class NpsCraExportHistoryImpl implements NpsCraExportHistory {

    @Override
    public void getInsertExportHistory(NpsCraExportHistoryModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map mp = new HashMap();
        mp.put("FILE_NAME", entbean.getFilename());
        mp.put("IP_ADDRESS", entbean.getIpaddress());
        mp.put("EXPORT_REF_NO", entbean.getExportrefno());
        mp.put("EMP_CODE", entbean.getEmpcode());
        query.append(" INSERT INTO NPS_CRA_EXPORT_HISTORY(ENT_DATE,FILE_NAME,IP_ADDRESS,EXPORT_REF_NO,EMP_CODE) ");
        query.append(" VALUES(SYSDATE(),:FILE_NAME,:IP_ADDRESS,:EXPORT_REF_NO,:EMP_CODE) ");
        sqltran.persist(query.toString(), new MapSqlParameterSource(mp));
    }

}
