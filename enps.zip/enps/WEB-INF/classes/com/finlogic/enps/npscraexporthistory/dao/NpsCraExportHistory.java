/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npscraexporthistory.dao;

import com.finlogic.enps.npscraexporthistory.model.NpsCraExportHistoryModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;

/**
 *
 * @author roshan4
 */
public interface NpsCraExportHistory {

    public void getInsertExportHistory(NpsCraExportHistoryModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException;
}
