/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsregpersonal.dao;

import com.finlogic.enps.npsregpersonal.model.NpsRegPersonalModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;

/**
 *
 * @author roshan4
 */
public interface NpsRegPersonal {
    
     public void getPersonalData(NpsRegPersonalModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException;
}
