/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsregpersonal.model;

/**
 *
 * @author roshan4
 */
public class NpsRegPersonalModel {
    
    private String refno;    
    private String fname;
    private String dob;
    private String gender;
    private String ekycname;
    private String ekycimagename;

    public String getRefno() {
        return refno;
    }

    public void setRefno(String refno) {
        this.refno = refno;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEkycname() {
        return ekycname;
    }

    public void setEkycname(String ekycname) {
        this.ekycname = ekycname;
    }

    public String getEkycimagename() {
        return ekycimagename;
    }

    public void setEkycimagename(String ekycimagename) {
        this.ekycimagename = ekycimagename;
    }
    
    
}
