/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsregpersonal.dao.impl;

import com.finlogic.enps.npsregpersonal.dao.NpsRegPersonal;
import com.finlogic.enps.npsregpersonal.model.NpsRegPersonalModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "NpsRegPersonal")
public class NpsRegPersonalImpl implements NpsRegPersonal {

    @Override
    public void getPersonalData(NpsRegPersonalModel entbean, SQLTranUtility sqltran) throws ClassNotFoundException, SQLException {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();
        map.put("REF_NO", entbean.getRefno());
        query.append(" UPDATE NPS_REG_PERSONAL ");
        query.append(" SET FNAME=NULL,DOB=NULL,GENDER=NULL,EKYC_NAME=NULL,EKYC_IMAGE_NAME=NULL ");
        query.append(" WHERE REF_NO=:REF_NO ");

        sqltran.persist(query.toString(), new MapSqlParameterSource(map));
    }

}
