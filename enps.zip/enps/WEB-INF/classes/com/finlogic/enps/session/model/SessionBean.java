package com.finlogic.enps.session.model;

/**
 *
 * @author ankur mistry<br/>
 * @version 0.1<br/>
 * @since 4-sep-2017
 * <br/>
 * Model for storing session details passed from ACL.<br/>
 * Which will persist as long as request session and exist.
 */
public class SessionBean {
    
    private String username;
    private String userId;
    private String mecode;
    private String aclUrl;
    private String sessionId;
    private String loginName;
    private String type;

    public SessionBean() {
    }
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMecode() {
        return mecode;
    }

    public void setMecode(String mecode) {
        this.mecode = mecode;
    }

    public String getAclUrl() {
        return aclUrl;
    }

    public void setAclUrl(String aclUrl) {
        this.aclUrl = aclUrl;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }    
    
}