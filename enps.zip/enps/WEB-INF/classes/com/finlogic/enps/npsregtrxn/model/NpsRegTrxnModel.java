/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsregtrxn.model;

/**
 *
 * @author roshan4
 */
public class NpsRegTrxnModel {

    private String paymentid;
    private String statusid;
    private String istier2;
    private String prevstatusid;

    public String getPaymentid() {
        return paymentid;
    }

    public void setPaymentid(String paymentid) {
        this.paymentid = paymentid;
    }

    public String getStatusid() {
        return statusid;
    }

    public void setStatusid(String statusid) {
        this.statusid = statusid;
    }

    public String getIstier2() {
        return istier2;
    }

    public void setIstier2(String istier2) {
        this.istier2 = istier2;
    }

    public String getPrevstatusid() {
        return prevstatusid;
    }

    public void setPrevstatusid(String prevstatusid) {
        this.prevstatusid = prevstatusid;
    }
}
