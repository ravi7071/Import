/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.enps.npsregtrxn.dao.impl;

import com.finlogic.enps.npsregtrxn.dao.NpsRegTrxn;
import com.finlogic.enps.npsregtrxn.model.NpsRegTrxnModel;
import com.finlogic.util.persistence.SQLTranUtility;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 *
 * @author roshan4
 */
@Repository(value = "NpsRegTrxn")
public class NpsRegTrxnImpl implements NpsRegTrxn {

    private static String paymentpending;
    private static String paymentfailed;

    @Value("${payment_pending}")
    public void setPaymentPending(String payment_pending) {
        NpsRegTrxnImpl.paymentpending = payment_pending;
    }

    @Value("${payment_failed}")
    public void setPaymentFailed(String payment_failed) {
        NpsRegTrxnImpl.paymentfailed = payment_failed;
    }

    @Override
    public int getUpdateInvoiceNo(NpsRegTrxnModel entbean, SQLTranUtility sqltran) throws Exception {
        StringBuilder query = new StringBuilder();
        Map map = new HashMap();

        map.put("STATUS", entbean.getStatusid());
        map.put("PAYMENTID", entbean.getPaymentid());

        query.append(" UPDATE NPS_REG_TRXN ");
        query.append(" SET STATUS_ID=:STATUS ");

        if (!entbean.getStatusid().equalsIgnoreCase(paymentfailed)) {
            query.append(" , INVOICE_NUM=GEN_NPS_INVOICE_NO() ");
        }
        if (entbean.getPrevstatusid().equalsIgnoreCase(paymentpending)) {
            query.append(" ,TIER_I_RECEIPT_NO=GEN_NPS_SUBSQNT_RECEIPT_NO(12) ");
            if (entbean.getIstier2().equalsIgnoreCase("Y")) {
                query.append(",TIER_II_RECEIPT_NO=GEN_NPS_SUBSQNT_RECEIPT_NO(12) ");
            }
        }
        query.append(" WHERE PAYMENT_ID=:PAYMENTID ");

        return sqltran.persist(query.toString(), new MapSqlParameterSource(map));
    }

}
