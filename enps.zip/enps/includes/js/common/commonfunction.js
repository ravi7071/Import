var loadimg = "<img style='margin:auto' id='loadingImageID' class='imgLoading'>"
function loadAjaxComboData(url, divid, data, sync) {
    showLoadingImg(divid);
    $.ajax({
        url: url,
        data: data,
        type: 'POST',
        async: sync,
        success: function (data) {
            hideLoadingImg();
            if (data.indexOf("Welcome to eNPS") > 0)
            {
                window.location = '';
            } else
            {
                $("#" + divid).html(data);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            hideLoadingImg();
        }
    });
}
/*function loadAjax(url, divid, data, sync) {
 if (divid === "txtPANA")
 {
 $("#imagLbl1").show();
 } else {
 $("#imagLbl2").show();
 }
 $.ajax({
 url: url,
 data: data,
 type: 'POST',
 async: sync,
 success: function (data) {
 if (divid === "txtPANA")
 {
 $("#imagLbl1").hide();
 } else {
 $("#imagLbl2").hide();
 }
 if (data.indexOf("Welcome to CDSL IR | Login") > 0)
 {
 window.location = '';
 } else
 {
 $("#" + divid).html(data);
 }
 },
 error: function (jqXHR, textStatus, errorThrown) {
 if (divid === "txtPANA")
 {
 $("#imagLbl1").hide();
 } else {
 $("#imagLbl2").hide();
 }
 }
 });
 }*/
function getalldata(oForm) {

    var aParams = new Array();
    var sParam = '';

    for (var i = 0; i < oForm.elements.length; i++) {
        if (oForm.elements[i].tagName == "SELECT")
        {
            for (var j = 0; j < oForm.elements[i].options.length; j++)
            {
                if (oForm.elements[i].options[j].selected)
                {
                    sParam = encodeURIComponent(oForm.elements[i].name);
                    sParam += "=";
                    sParam += encodeURIComponent(oForm.elements[i][j].value);
                    aParams.push(sParam);
                }
            }
        }
        if (oForm.elements[i].type == "textarea")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].type == "checkbox" && oForm.elements[i].checked == true)
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].type == "radio" && oForm.elements[i].checked == true)
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].tagName == "INPUT" && oForm.elements[i].type == "text")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].tagName == "INPUT" && oForm.elements[i].type == "hidden")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].tagName == "INPUT" && oForm.elements[i].type == "file")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].tagName == "INPUT" && oForm.elements[i].type == "password")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].tagName == "INPUT" && oForm.elements[i].type == "email")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
    }
    return aParams.join("&");
}
function isNumberKey(event)
{
    var charCode = (event.which) ? event.which : event.keyCode
    if (charCode === 35 || charCode === 36 || charCode === 46 || charCode === 39 || charCode === 37)
        return true;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}
function isNumberKeyWithDash(event)
{
    var charCode = (event.which) ? event.which : event.keyCode
    if (charCode === 35 || charCode === 36 || charCode === 46 || charCode === 39 || charCode === 37 || charCode == 45)
        return true;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}
function isNumberKeyWithSlash(event)
{
    if (event.keyCode == 13)
    {
        return false;
    }
    var charCode = (event.which) ? event.which : event.keyCode
    if (charCode === 35 || charCode === 36 || charCode === 46 || charCode === 39 || charCode === 37 || charCode == 47)
        return true;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}
function isAlphaNumeric(event)
{
    var charCode = (event.which) ? event.which : event.keyCode

    if ((charCode === 35 || charCode === 36 || charCode === 39 || charCode === 46 || charCode === 37 || charCode === 8 || charCode === 31 || charCode === 9) || ((charCode >= 48 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)))
    {
        return true;
    } else
    {
        return false;
    }
}
function isAlphaNumericOnlyLower(event)
{
    var charCode = (event.which) ? event.which : event.keyCode

    if ((charCode === 35 || charCode === 36 || charCode === 39 || charCode === 46 || charCode === 37 || charCode === 8 || charCode === 31 || charCode === 9) || ((charCode >= 48 && charCode <= 57) || (charCode >= 97 && charCode <= 122)))
    {
        return true;
    } else
    {
        return false;
    }
}
function isAlphaNumericWithSpace(event, id)
{
    var charCode = (event.which) ? event.which : event.keyCode

    if ((charCode === 35 || charCode === 36 || charCode === 39 || charCode === 46 || charCode === 37 || charCode === 32 || charCode === 8 || charCode === 31 || charCode === 9) || ((charCode >= 48 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)))
    {
        return true;
    } else
    {
        return false;
    }
}
function replace_special_char(var_id) //D
{
    var objRegExp = /([\~\!\@\#$%\^\&\*\(\)\_\+\|\`\-\=\\[\]\;\'\,\/\{\}\:\"\<\>\?\.]+)/g;
    if (document.getElementById(var_id).value !== (document.getElementById(var_id).value).replace(objRegExp, ''))
    {
        document.getElementById(var_id).value = (document.getElementById(var_id).value).replace(objRegExp, '');
    }
}
function remain_only_number(var_id) //D
{
    var objRegExp = /([\~\!\@\#$%\^\&\*\(\)\_\+\|\`\-\=\\[\]\;\'\,\/\{\}\:\"\<\>\?\. A-Za-z]+)/g;
    if (document.getElementById(var_id).value !== (document.getElementById(var_id).value).replace(objRegExp, ''))
    {
        document.getElementById(var_id).value = (document.getElementById(var_id).value).replace(objRegExp, '');
    }
}
function remain_only_alpha(var_id) //D
{
    var objRegExp = /([\~\!\@\#$%\^\&\*\(\)\_\+\|\`\-\=\\[\]\;\'\,\/\{\}\:\"\<\>\? 0-9]+)/g;
    if (document.getElementById(var_id).value !== (document.getElementById(var_id).value).replace(objRegExp, ''))
    {
        document.getElementById(var_id).value = (document.getElementById(var_id).value).replace(objRegExp, '');
    }
}
function remain_only_alphaSpace(var_id) //D
{
    var objRegExp = /([\~\!\@\#$%\^\&\*\(\)\_\+\|\`\-\=\\[\]\;\'\,\/\{\}\:\"\<\>\?0-9]+)/g;
    if (document.getElementById(var_id).value !== (document.getElementById(var_id).value).replace(objRegExp, ''))
    {
        document.getElementById(var_id).value = (document.getElementById(var_id).value).replace(objRegExp, '');
    }
}
function remain_only_alphasinglquat(var_id) //D
{
    var objRegExp = /([\~\!\@\#$%\^\&\*\(\)\_\+\|\`\-\=\\[\]\;\,\/\{\}\:\"\<\>\?\.0-9]+)/g;
    if (document.getElementById(var_id).value !== (document.getElementById(var_id).value).replace(objRegExp, ''))
    {
        document.getElementById(var_id).value = (document.getElementById(var_id).value).replace(objRegExp, '');
    }
}
function replace_special_char_except_dash(var_id) //D
{
    var objRegExp = /([\~\!\@\#$%\^\&\*\(\)\_\+\|\`\=\\[\]\;\'\,\/\{\}\:\"\<\>\?\. A-Za-z]+)/g;
    if (document.getElementById(var_id).value !== (document.getElementById(var_id).value).replace(objRegExp, ''))
    {
        document.getElementById(var_id).value = (document.getElementById(var_id).value).replace(objRegExp, '');
    }
}
function replace_special_char_for_mail(var_id) //D
{
    var objRegExp = /([\~\!\#$%\^\&\*\(\)\\+\|\`\=\\[\]\;\'\,\/\{\}\:\"\<\>\?]+)/g;
    if (document.getElementById(var_id).value !== (document.getElementById(var_id).value).replace(objRegExp, ''))
    {
        document.getElementById(var_id).value = (document.getElementById(var_id).value).replace(objRegExp, '');
    }
}

function isAlpha(event)
{
    var charCode = (event.which) ? event.which : event.keyCode

    if (charCode === 35 || charCode === 36 || charCode === 39 || charCode === 37 || charCode === 46)
        return true;
    if ((charCode === 8 || charCode === 31 || charCode === 9) || ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)))
    {
        return true;
    } else
    {
        return false;
    }
}
function isAlphaSpace(event)
{
    var charCode = (event.which) ? event.which : event.keyCode

    if (charCode === 35 || charCode === 36 || charCode === 32 || charCode === 39 || charCode === 37 || charCode === 46)
        return true;
    if ((charCode === 8 || charCode === 31 || charCode === 9) || ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)))
    {
        return true;
    } else
    {
        return false;
    }
}
function isValidEmailid(event)
{
    var charCode = (event.which) ? event.which : event.keyCode

    if ((charCode === 35 || charCode === 36 || charCode === 39 || charCode === 37 || charCode === 64 || charCode === 45 || charCode === 46 || charCode === 95 || charCode === 8 || charCode === 31 || charCode === 9) || ((charCode >= 48 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)))
    {
        return true;
    } else
    {
        return false;
    }
}
function dateEditable(event)
{
    var charCode = (event.which) ? event.which : event.keyCode
    if (charCode === 39 || charCode === 37 || charCode === 47)
        return true;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}
// A-Z, a-z, 0-9, _, ,@,#,$,%,^,-,.,*,,
function isPasswordOrAddress(event)
{
    var charCode = (event.which) ? event.which : event.keyCode

    if ((charCode === 39 || charCode === 37 || charCode === 44 || charCode === 42 || charCode === 45 || charCode === 94 || charCode === 37 || charCode === 36 || charCode === 35 || charCode === 32 || charCode === 64 || charCode === 46 || charCode === 95 || charCode === 8 || charCode === 31 || charCode === 9) || ((charCode >= 48 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || charCode === 95))
    {
        return true;
    } else
    {
        return false;
    }
}
// A-Z, a-z, 0-9, _, ,@,#,$,%,^,-,.,*,/,&,(,)
function isAddress(event)
{
    var charCode = (event.which) ? event.which : event.keyCode

    if ((charCode === 13 || charCode === 47 || charCode === 39 || charCode === 37 || charCode === 38 || charCode === 44 || charCode === 42 || charCode === 40 || charCode === 41 || charCode === 45 || charCode === 94 || charCode === 37 || charCode === 36 || charCode === 35 || charCode === 32 || charCode === 64 || charCode === 46 || charCode === 95 || charCode === 8 || charCode === 31 || charCode === 9) || ((charCode >= 48 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || charCode === 95))
    {
        return true;
    } else
    {
        return false;
    }
}
function isOrgApp(event)
{
    var charCode = (event.which) ? event.which : event.keyCode
    if (charCode === 8 || charCode === 31 || charCode === 9 || charCode === 35 || charCode === 36 || charCode === 46 || charCode === 8 || charCode === 39 || charCode === 37)
        return true;
    if ((charCode === 45 || charCode === 47 || charCode === 46) || ((charCode >= 48 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)))
    {
        return true;
    } else
    {
        return false;
    }
}
function replace_special_char_for_Address(var_id) //D
{
    var objRegExp = /([\~\!\+\|\`\=\\[\]\;\'\{\}\:\"\<\>\?]+)/g;
    if (document.getElementById(var_id).value !== (document.getElementById(var_id).value).replace(objRegExp, ''))
    {
        document.getElementById(var_id).value = (document.getElementById(var_id).value).replace(objRegExp, '');
    }
}
function replace_special_char_for_OrgApp(var_id) //D
{
    var objRegExp = /([\~\!\+\|\`\=\\[\]\;\'\{\}\:\"\<\>\?]+)/g;
    if (document.getElementById(var_id).value !== (document.getElementById(var_id).value).replace(objRegExp, ''))
    {
        document.getElementById(var_id).value = (document.getElementById(var_id).value).replace(objRegExp, '');
    }
}
function checkNameWithSpace(value)
{
    var regExp = /^[a-zA-Z0-9_. ]*$/;
    if (!regExp.test(value))
    {
        return false;
    }
    return true;
}
function checkName(value)
{
    var regExp = /^[a-zA-Z0-9_.]*$/;
    if (!regExp.test(value))
    {
        return false;
    }
    return true;
}
function checkRemark(value)
{
    var regExp = /^[a-zA-Z0-9 _.,@#$%^-]*$/;
    if (!regExp.test(value))
    {
        return false;
    }
    return true;
}
function checkNumber(value)
{
    var regExp = /^[0-9]*$/;
    if (!regExp.test(value))
    {
        return false;
    }
    return true;

}
function checkEmail(value)
{
    var regExp = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!regExp.test(value))
    {
        return false;
    }
    return true;

}
function checkIFSC(value)
{
    var reg = /[A-Z|a-z]{4}[0][a-zA-Z0-9]{6}$/;
    if (!reg.test(value))
    {
        return false;
    }
    return true;
}
function checkDate(date1, date2)
{
    var firstValue = date1.split('/');
    var secondValue = date2.split('/');

    var firstDate = new Date();
    firstDate.setFullYear(firstValue[2], (firstValue[1] - 1), firstValue[0]);

    var secondDate = new Date();
    secondDate.setFullYear(secondValue[2], (secondValue[1] - 1), secondValue[0]);

    if (firstDate >= secondDate)
    {
        return false;
    }
    return true;
}
function getalldatawithoutFile(oForm) {

    var aParams = new Array();
    var sParam = '';

    for (var i = 0; i < oForm.elements.length; i++) {
        if (oForm.elements[i].tagName == "SELECT")
        {
            for (var j = 0; j < oForm.elements[i].options.length; j++)
            {
                if (oForm.elements[i].options[j].selected)
                {
                    sParam = encodeURIComponent(oForm.elements[i].name);
                    sParam += "=";
                    sParam += encodeURIComponent(oForm.elements[i][j].value);
                    aParams.push(sParam);
                }
            }
        }
        if (oForm.elements[i].type == "textarea")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].type == "checkbox" && oForm.elements[i].checked == true)
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].type == "radio" && oForm.elements[i].checked == true)
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].tagName == "INPUT" && oForm.elements[i].type == "text")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].tagName == "INPUT" && oForm.elements[i].type == "hidden")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].tagName == "INPUT" && oForm.elements[i].type == "password")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
        if (oForm.elements[i].tagName == "INPUT" && oForm.elements[i].type == "email")
        {
            sParam = encodeURIComponent(oForm.elements[i].name);
            sParam += "=";
            sParam += encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
    }
    return aParams.join("&");
}
function showLoadingImg(divid)
{
    var obj = document.getElementById(divid);
    obj.innerHTML = loadimg;
//    $("#loadingImageID").removeProp('style');
}
function hideLoadingImg()
{
    $("#loadingImageID").prop('style', 'display:none');
}


function mandatoryCheck(id, text)
{
    if ($("#" + id).val() === "")
    {
        $("#" + id + "A").html("");
        $("#" + id + "A").show();
        $("#" + id + "A").html("<label style=\"color: red;\"class=\"error\">Please Enter " + text + "</label>");
        $("#" + id).focus();
        return false;
    }
    return true;
}


function cmbValidation(id, text)
{
    if ($("#" + id).val() === "")
    {
        $("#" + id + "A").html("");
        $("#" + id + "A").show();
        $("#" + id + "A").html("<label style=\"color: red;\"class=\"error\">Please select " + text + "</label>");
        $("#" + id).focus();
        return false;
    }
    return true;
}


function textValidation(id, text, regExp, minLen, maxLen)
{

    if (document.getElementById(id).value != '' && !document.getElementById(id).value.match(regExp))
    {
        $("#" + id + "A").html("");
        $("#" + id + "A").show();
        $("#" + id + "A").html("<label style=\"color: red;\"class=\"error\">Invalid " + text + ".</label>");
        $("#" + id).focus();
        return false;
    } else if (document.getElementById(id).value != '' && minLen != null && maxLen != null && (document.getElementById(id).value.length < minLen || document.getElementById(id).value.length > maxLen))
    {
        $("#" + id + "A").html("");
        $("#" + id + "A").show();
        if (minLen == maxLen)
        {
            $("#" + id + "A").html("<label style=\"color: red;\"class=\"error\"> invalid length of " + text + " [ Expected Length: " + minLen + " ]</label>");
        } else
        {
            $("#" + id + "A").html("<label style=\"color: red;\"class=\"error\">invalid length of " + text + "[ Expected Length: " + minLen + "," + maxLen + " ].</label>");
        }
        $("#" + id).focus();
        document.getElementById(id).focus();
        return false;
    }
    return true;
}

function dateValidation(id, person, text, isEighteenYOld)
{
    if (document.getElementById(id).value != '')
    {
        if (document.getElementById(id).value.match(DATE))
        {
            var d = document.getElementById(id).value.substring(0, 2);
            var m = document.getElementById(id).value.substring(3, 5);
            var y = document.getElementById(id).value.substring(6);
            var dt = new Date(y, (m - 1), d, 0, 0, 0, 0);
            if (navigator.appName == 'Microsoft Internet Explorer')
            {
                var dt_year = dt.getYear();
                if (dt_year < 999)
                {
                    dt_year += 1900;
                }
                if (!(dt_year == y && (dt.getMonth() + 1) == m && dt.getDate() == d))
                {
                    $("#" + id + "A").html("");
                    $("#" + id + "A").show();
                    $("#" + id + "A").html("<label style=\"color: red;\"class=\"error\">Invalid " + text + "</label>");
                    $("#" + id).focus();
                    return false;
                }
            } else
            {
                if (!((dt.getYear() + 1900) == y && (dt.getMonth() + 1) == m && dt.getDate() == d))
                {
                    $("#" + id + "A").html("");
                    $("#" + id + "A").show();
                    $("#" + id + "A").html("<label style=\"color: red;\"class=\"error\">Invalid " + text + "</label>");
                    $("#" + id).focus();
                    return false;
                }
            }
            if (isEighteenYOld)
            {
                var currdate = new Date();
                dt.setFullYear(dt.getFullYear() + 18, m - 1, d);
                if ((currdate - dt) < 0)
                {
                    $("#" + id + "A").html("");
                    $("#" + id + "A").show();
                    $("#" + id + "A").html("<label style=\"color: red;\"class=\"error\">" + person + " must be 18 years old</label>");
                    $("#" + id).focus();
                    return false;
                }
            }
        } else
        {
            $("#" + id + "A").html("");
            $("#" + id + "A").show();
            $("#" + id + "A").html("<label style=\"color: red;\"class=\"error\"> Invalid Date Format</label>");
            $("#" + id).focus();
            return false;
        }
    }
    return true;
}
function replace_special_char_for_orgname(var_id) //D
{
    var objRegExp = /([\~\!\@\#$%\^\&\*\_\+\|\`\=\\[\]\;\'\,\/\{\}\:\"\<\>\?]+)/g;
    if (document.getElementById(var_id).value !== (document.getElementById(var_id).value).replace(objRegExp, ''))
    {
        document.getElementById(var_id).value = (document.getElementById(var_id).value).replace(objRegExp, '');
    }
}

function isAlphaNumericWithSpaceForOrgName(event)
{
    var charCode = (event.which) ? event.which : event.keyCode

    if (charCode === 39 || charCode === 37 || charCode === 8 || charCode === 45 || charCode === 46 || charCode === 40 || charCode === 41 || charCode === 32 || (charCode === 31 || charCode === 9) || ((charCode >= 48 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)))
    {
        return true;
    } else
    {
        return false;
    }
}

function sameDigitValidation(id)
{
    var field = $("#" + id).val();
    if (field != null && field != '')
    {
        var count = 0;
        var text = field[0];
        if (text == 0)
        {
            return false;
        }
        for (var i = 0; i < field.length; i++) {
            if (text !== field[i])
            {
                return true;
            } else {
                count++;
            }
            if (count === field.length)
            {
                return false;
            }
        }
    } else {
        return true;
    }
}
function checkFutureDate(id, text)
{
    var currentDate = new Date();
    var day = currentDate.getDate();
    var month = currentDate.getMonth() + 1;
    var year = currentDate.getFullYear();
    var finalCurDate = new Date(year, month - 1, day);
    var partsBirthDate = ($("#" + id).val()).split("/");
    var finalBirthDate = new Date(partsBirthDate[2], partsBirthDate[1] - 1, partsBirthDate[0]);
    if (finalBirthDate > finalCurDate)
    {
        $("#" + id + "A").html("");
        $("#" + id + "A").show();
        $("#" + id + "A").html("<label style=\"color: red;\"class=\"error\"> " + text + " should not be greater then current date.</label>");
        $("#" + id).focus();
        return false;
    } else {
        return true;
    }
}

function getDifferenceFromToDate(fromdate, todate)
{
    var td_day = todate.split("-")[0];
    var td_month = todate.split("-")[1];
    var td_year = todate.split("-")[2];
    var todt = new Date(td_year, td_month - 1, td_day);
    var prevDate = new Date(td_year, td_month - 1, td_day);
    var fd_day = fromdate.split("-")[0];
    var fd_month = fromdate.split("-")[1];
    var fd_year = fromdate.split("-")[2];
    var fromdt = new Date(fd_year, fd_month - 1, fd_day);

    var fromdate = new Date(fd_year, fd_month - 1, fd_day);
    var todate = new Date(td_year, td_month - 1, td_day);
    var one_day = 1000 * 60 * 60 * 24;
    var difference = Math.floor((todate.getTime() - fromdate.getTime()) / (one_day));
    return difference;
}

function getAjaxData(url, data, sync) {

    var returndata = "";
//    showLoadingImg();
    $.when($.ajax({
        url: url,
        data: data,
        type: 'POST',
        async: sync,
        success: function (data) {
            hideLoadingImg();

            returndata = data;

        },
        error: function (jqXHR, textStatus, errorThrown) {
//            hideLoadingImg();
        }
    })).then(function (data) {
        return returndata;
    });
    return returndata;
}

function check_date_less_or_equal_current_date(id, msg)
{
    var input = document.getElementById(id).value;

    if (!checkValidDate(id, msg))
    {
        return false;
    }

    var dayfield = input.split(/[\/-]/)[0];
    var monthfield = input.split(/[\/-]/)[1];
    var yearfield = input.split(/[\/-]/)[2];

    var dayobj = new Date(yearfield, monthfield - 1, dayfield);
    if ((dayobj.getMonth() + 1 != monthfield) || (dayobj.getDate() != dayfield) || (dayobj.getFullYear() != yearfield))
    {
        setError(id, "Please enter valid date for " + msg);
        return false;
    }

    var currentDate = new Date();
    if (dayobj > currentDate) {
        setError(id, msg + " should be less than current Date.");
        return false;
    }

    return true;
}

function checkValidDate(id, msg)
{
    var input = document.getElementById(id).value;

    if (!validformat2.test((input.trim())))//!validformat1.test(Trim(input.value)) &&
    {//if date entered is not valid
        setError(id, "Please enter valid date for " + msg);
//                    input.focus();
        return false;
    }

    var dayfield = input.split(/[\/-]/)[0];
    var monthfield = input.split(/[\/-]/)[1];
    var yearfield = input.split(/[\/-]/)[2];

    var dayobj = new Date(yearfield, monthfield - 1, dayfield);
    if ((dayobj.getMonth() + 1 != monthfield) || (dayobj.getDate() != dayfield) || (dayobj.getFullYear() != yearfield))
    {
        setError(id, "Please enter valid date for " + msg);
        return false;
    }
    return true;
}

function setError(id, text)
{
    $("#" + id + "_E").html("");
    $("#" + id + "_E").show();
    if (text == "")
    {
        $("#" + id + "_E").html();
    } else
    {
        $("#" + id + "_E").html("<label style=\"color: red;\"class=\"error\"> " + text + "</label>");
    }
    $("#" + id).focus();
    return false;
}

function getClearError(id)
{

    $("#" + id + "_E").html("");

}

function compare_fromdate_todate(from_dt, to_dt)
{
    var from_dt_day = from_dt.split("-")[0];
    var from_dt_mon = from_dt.split("-")[1];
    var from_dt_year = from_dt.split("-")[2];
    var from_date = new Date(from_dt_year, from_dt_mon, from_dt_day);
    var to_dt_day = to_dt.split("-")[0];
    var to_dt_mon = to_dt.split("-")[1];
    var to_dt_year = to_dt.split("-")[2];
    var to_date = new Date(to_dt_year, to_dt_mon, to_dt_day);
    return(from_date > to_date);
}