var validformat2 = /^\d{2}[-]\d{2}[-]\d{4}$/;

function setDateValues()
{
    $('#txtfromdate').datepicker({
        startDate: '-100y',
        endDate: '0d',
        autoclose: true,
        format: 'dd-mm-yyyy',
        todayHighlight: true,
    });

    $('#txttodate').datepicker({
        startDate: '-100y',
        endDate: '0d',
        autoclose: true,
        format: 'dd-mm-yyyy',
        todayHighlight: true,
    });

    $('#txtfromdate').mask('99-99-9999', {placeholder: "DD-MM-YYYY"});
    $('#txttodate').mask('99-99-9999', {placeholder: "DD-MM-YYYY"});

}

function validateform()
{
    if (document.getElementById("txtfromdate").value.trim() == "")
    {
        setError("txtfromdate", "This field is required.");
        return false;
    }
    if (!check_date_less_or_equal_current_date("txtfromdate", "From Date"))
    {
        return false;
    } else
    {
        getClearError("txtfromdate");
    }

    if (document.getElementById("txttodate").value.trim() == "")
    {
        setError("txttodate", "This field is required.");
        return false;
    }
    if (!check_date_less_or_equal_current_date("txttodate", "To Date"))
    {
        return false;
    } else
    {
        getClearError("txttodate");
    }

    if (compare_fromdate_todate(document.getElementById("txtfromdate").value, document.getElementById("txttodate").value))
    {
        setError("txttodate", "To Date should be greater than From Date.");
        return false;
    } else
    {
        getClearError("txttodate");
    }

    if (getDifferenceFromToDate($('#txtfromdate').val(), $('#txttodate').val()) > 180)
    {
        setError("txttodate", "Difference between 'From' and 'To' must be less than 180 Days.");
        return false;
    } else
    {
        getClearError("txttodate");
    }
    return true;
}
function onSubmit(frm)
{
    if (validateform())
    {
        document.getElementById("tableDiv").style.display = 'block';
        document.getElementById('tableDiv').setAttribute("class", "table-responsive");
        loadAjaxComboData('contributionreport.fin?cmdAction=getReportData', 'tableDiv', getalldatawithoutFile(frm), false);

        var oTable = $('#myTable').DataTable({
            "lengthMenu": [[50, 100, 200, -1], [50, 100, 200, "All"]],
//            order: [], //Remove sign of sorting from first column 
            aoColumnDefs: [
                {
                    bSortable: false,
                    aTargets: [7]
                }
            ],
            "bInfo": true,
            scrollY: '75vh',
            "scrollX": true,
            scrollCollapse: true,
            paging: true,
        });
        $('#collapseform').collapse('hide');
    }
    return false;
}

function getReset()
{
    window.location = 'contributionreport.fin';
}
function getCancel()
{
    window.location = 'home.fin';
}

function getGenerateFile()
{
    var chkarray = document.getElementsByName('chkdata');
    var i, isValid = false;
    var refids = "";
    var refcount = 0;
    for (i = 0; i < chkarray.length; i++)
    {
        if (chkarray[i].checked === true)
        {
            if (isValid)
            {
                refids = refids + ",";
            }
            isValid = true;
            refids = refids + chkarray[i].value;
            refcount = refcount + 1;
//            break;
        }
    }

    if (isValid && refids != "")
    {
        window.location.href = "contributionreport.fin?cmdAction=getGenerateFile&refids=" + refids;
    } else
    {
        var ale = bootbox.alert({
            message: "Please select at least one record.",
            size: 'small',
            buttons: {
                ok: {
                    className: 'btn btn-primary btn-sm'
                }
            }
        });
    }
}

function getSelectAll()
{
    if ($('#chkall').prop("checked") === true) {
        $('.checkbox').each(function (i, obj) {
            $(obj).prop("checked", true);
        });
    } else {
        $('.checkbox').each(function (i, obj) {
            $(obj).prop("checked", false);
        });
    }

}

function getSelect()
{
    if ($('.checkbox:checked').length === $('.checkbox').length) {
        $('#chkall').prop('checked', true);
    } else {
        $('#chkall').prop('checked', false);
    }
}