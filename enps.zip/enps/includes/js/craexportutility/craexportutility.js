var PAN = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
var DIGIT = /^[0-9]+$/;
var validformat2 = /^\d{2}[-]\d{2}[-]\d{4}$/;

//$("#CRAExportUtility").validate({
//    rules: {
////        txtinputtext: {
////            required: true,
////        },
////        txtfromdate: {
////            required: true,
////        },
////        txttodate: {
////            required: true,
////        },
//    },
//    submitHandler: function (form) {
//        onSave(form);
//    }
//});
$(document).ready(function () {
    $('.selectpicker').selectpicker({
        style: 'btn-default form-control input-sm',
        size: 5,
    });
});

function setDateValues()
{
    $('#txtfromdate').datepicker({
        startDate: '-100y',
        endDate: '0d',
        autoclose: true,
        format: 'dd-mm-yyyy',
        todayHighlight: true,
    });

    $('#txttodate').datepicker({
        startDate: '-100y',
        endDate: '0d',
        autoclose: true,
        format: 'dd-mm-yyyy',
        todayHighlight: true,
    });

    $('#txtstatusdate').datepicker({
        startDate: '-100y',
//        endDate: '0d',
        autoclose: true,
        format: 'dd-mm-yyyy',
        todayHighlight: true,
    });

    $('#txtfromdate').mask('99-99-9999', {placeholder: "DD-MM-YYYY"});
    $('#txttodate').mask('99-99-9999', {placeholder: "DD-MM-YYYY"});
    $('#txtstatusdate').mask('99-99-9999', {placeholder: "DD-MM-YYYY"});

}

//function hideserachtext(id)
//{
//    document.getElementById("divinputtext").style.display = "block";
//    document.getElementById("divnone").style.display = "none";
//    if (id == "rdorefno")
//    {
//        document.getElementById("divtext").innerHTML = "NPS Reference No";
//        document.getElementById("txtinputtext").value = "";
//        document.getElementById("txtinputtext").setAttribute('maxlength', 12);
//    }
//    if (id == "rdopan")
//    {
//        document.getElementById("divtext").innerHTML = "PAN";
//        document.getElementById("txtinputtext").value = "";
//        document.getElementById("txtinputtext").setAttribute('maxlength', 10);
//    }
//    if (id == "rdouid")
//    {
//        document.getElementById("divtext").innerHTML = "UID";
//        document.getElementById("txtinputtext").value = "";
//        document.getElementById("txtinputtext").setAttribute('maxlength', 12);
//    }
//    if (id == "rdoreceiptno")
//    {
//        document.getElementById("divtext").innerHTML = "Receipt No.";
//        document.getElementById("txtinputtext").value = "";
//        document.getElementById("txtinputtext").setAttribute('maxlength', 17);
//    }
//    if (id == "rdopran")
//    {
//        document.getElementById("divtext").innerHTML = "PRAN";
//        document.getElementById("txtinputtext").value = "";
//        document.getElementById("txtinputtext").setAttribute('maxlength', 12);
//    }
//    if (id == "rdodefault")
//    {
//        document.getElementById("divinputtext").style.display = "none";
//        document.getElementById("divnone").style.display = "block";
//    }
//}

function getReset()
{
    window.location = 'craexportutility.fin';
}

function Space_Checking(val)
{
    l = val;
    var isspace = false;
    if (l != "")
    {
        for (var i = l.length; i >= 0; i--)
        {
            var chr = l.substring(i - 1, i);
            if (chr == " ")
            {
                isspace = true;
                break;
            }
        }
        if (isspace)
        {
            return false;
        }
    }
    return true;
}

function checksize(size, msg)
{
    var txtinputtext = document.getElementById("txtinputtext").value;
    if (txtinputtext.length != size)
    {
        alert("Please enter valid " + msg);
        return false;
    }
    return true;
}

//function checkfordigit(msg)
//{
//    var txtinputtext = document.getElementById("txtinputtext");
//    var nameReg = /^[0-9]+$/;
//
//    if (txtinputtext.value.trim().length == 0)
//    {
//        alert("Please enter value for " + msg);
//        txtinputtext.focus();
//        return false;
//    }
//
//    if (!Space_Checking(txtinputtext.value))
//    {
//        alert("Space is not allowed in " + msg);
//        txtinputtext.focus();
//        return false;
//    }
//    if (!nameReg.test(txtinputtext.value))
//    {
//        alert("Please Enter Valid " + msg);
//        txtinputtext.focus();
//        return false;
//    }
//    return true;
//}

function checkValidDate(id, msg)
{
    var input = document.getElementById(id).value;

    if (!validformat2.test((input.trim())))//!validformat1.test(Trim(input.value)) &&
    {//if date entered is not valid
        setError(id, "Please enter valid date for " + msg);
//                    input.focus();
        return false;
    }

    var dayfield = input.split(/[\/-]/)[0];
    var monthfield = input.split(/[\/-]/)[1];
    var yearfield = input.split(/[\/-]/)[2];

    var dayobj = new Date(yearfield, monthfield - 1, dayfield);
    if ((dayobj.getMonth() + 1 != monthfield) || (dayobj.getDate() != dayfield) || (dayobj.getFullYear() != yearfield))
    {
        setError(id, "Please enter valid date for " + msg);
        return false;
    }
    return true;
}

function check_date_less_or_equal_current_date(id, msg)
{
    var input = document.getElementById(id).value;

    if (!checkValidDate(id, msg))
    {
        return false;
    }

    var dayfield = input.split(/[\/-]/)[0];
    var monthfield = input.split(/[\/-]/)[1];
    var yearfield = input.split(/[\/-]/)[2];

    var dayobj = new Date(yearfield, monthfield - 1, dayfield);
    if ((dayobj.getMonth() + 1 != monthfield) || (dayobj.getDate() != dayfield) || (dayobj.getFullYear() != yearfield))
    {
        setError(id, "Please enter valid date for " + msg);
        return false;
    }

    var currentDate = new Date();
    if (dayobj > currentDate) {
        setError(id, msg + " should be less than current Date.");
        return false;
    }

    return true;
}

function compare_fromdate_todate(from_dt, to_dt)
{
    var from_dt_day = from_dt.split("-")[0];
    var from_dt_mon = from_dt.split("-")[1];
    var from_dt_year = from_dt.split("-")[2];
    var from_date = new Date(from_dt_year, from_dt_mon, from_dt_day);
    var to_dt_day = to_dt.split("-")[0];
    var to_dt_mon = to_dt.split("-")[1];
    var to_dt_year = to_dt.split("-")[2];
    var to_date = new Date(to_dt_year, to_dt_mon, to_dt_day);
    return(from_date > to_date);
}

function onSubmit(frm)
{
    if (validateform())
    {
//        var param = getalldatawithoutFile(frm);
//        loadAjax('craexportutility.fin?cmdAction=getReportData', 'test', param, true);
        document.getElementById("viewContent").style.display = 'none';
        document.getElementById("mainDiv").style.display = 'block';
        document.getElementById("tableDiv").style.display = 'block';
        document.getElementById('tableDiv').setAttribute("class", "table-responsive");
        loadAjaxComboData('craexportutility.fin?cmdAction=getReportData', 'tableDiv', getalldatawithoutFile(frm), false);
        var oTable = $('#myTable').DataTable({
            "lengthMenu": [[50, 100, 200, -1], [50, 100, 200, "All"]],
            order: [], //Remove sign of sorting from first column 
//            columnDefs: [{targets: [0]}],  
            aoColumnDefs: [
                {
                    bSortable: false,
                    aTargets: [0, 1, 2, 3, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26]
                }
            ],
//            rowsGroup: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26],
//            rowsGroup: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
//            rowsGroup: [6],
            "bInfo": true,
            scrollY: '75vh',
            "scrollX": true,
            scrollCollapse: true,
            paging: true,
        });

        var dataRep = document.getElementById("cmbreportcol");

        var opts = [], opt;

        // loop through options in select list

        for (var i = 0, len = dataRep.options.length; i < len; i++) {
            opt = dataRep.options[i];

            if (opt.value == "10" || opt.value == "19" || opt.value == "18" || opt.value == "13" || opt.value == "12" || opt.value == "15" || opt.value == "9"
                    || opt.value == "20" || opt.value == "25" || opt.value == "24" || opt.value == "17" || opt.value == "14" || opt.value == "22" || opt.value == "23")
            {
                if (opt.selected) {
                    oTable.column(opt.value).visible(true);
                } else
                {
                    oTable.column(opt.value).visible(false);
                }
            }
        }
        $('#collapseform').collapse('hide');
    }
    return false;
}

function validateform()
{
//    if (document.getElementById("rdodefault").checked == true)
//    {
    if (document.getElementById("txtinputtext").value.trim() !== "")
    {

    } else
    {
        if (document.getElementById("txttextlike").value.trim() !== "")
        {
            if (!getCountchar("txttextlike"))
            {
                return false;
            }
        }

        if (document.getElementById("txtfromdate").value.trim() == "")
        {
            setError("txtfromdate", "This field is required.");
            return false;
        }
        if (!check_date_less_or_equal_current_date("txtfromdate", "From Date"))
        {
            return false;
        } else
        {
            getClearError("txtfromdate");
        }

        if (document.getElementById("txttodate").value.trim() == "")
        {
            setError("txttodate", "This field is required.");
            return false;
        }
        if (!check_date_less_or_equal_current_date("txttodate", "To Date"))
        {
            return false;
        } else
        {
            getClearError("txttodate");
        }

        if (compare_fromdate_todate(document.getElementById("txtfromdate").value, document.getElementById("txttodate").value))
        {
            setError("txttodate", "To Date should be greater than From Date.");
            return false;
        } else
        {
            getClearError("txttodate");
        }

        if (getDifferenceFromToDate($('#txtfromdate').val(), $('#txttodate').val()) > 90)
        {
            setError("txttodate", "Difference between 'From' and 'To' must be less than 90 Days.");
            return false;
        } else
        {
            getClearError("txttodate");
        }

    }

//    } else if (document.getElementById("rdorefno").checked == true)
//    {
//        if (!Space_Checking(document.getElementById("txtinputtext").value))
//        {
//            setError("txtinputtext", "Space is not allowed.");
//            return false;
//        }
//        if (!DIGIT.test(document.getElementById("txtinputtext").value))
//        {
//            setError("txtinputtext", "only numbers allowed.");
//            return false;
//        }
//        if (document.getElementById("txtinputtext").value.length > 12)
//        {
//            setError("txtinputtext", "Please enter valid NPS Reference Number.");
//            return false;
//        }
//    } else if (document.getElementById("rdopan").checked == true)
//    {
//        if (!Space_Checking(document.getElementById("txtinputtext").value))
//        {
//            setError("txtinputtext", "Space is not allowed.");
//            return false;todayHighlight: true
//        }
//        if (!PAN.test(document.getElementById("txtinputtext").value))
//        {
//            setError("txtinputtext", "Please enter valid PAN.");
//            return false;
//        }
//    } else if (document.getElementById("rdouid").checked == true)
//    {
//        if (!Space_Checking(document.getElementById("txtinputtext").value))
//        {
//            setError("txtinputtext", "Space is not allowed.");
//            return false;
//        }getClearError(id)
//        if (!DIGIT.test(document.getElementById("txtinputtext").value))
//        {
//            setError("txtinputtext", "Please enter only numbers.");
//            return false;
//        }
//        if (document.getElementById("txtinputtext").value.length !== 12)
//        {
//            setError("txtinputtext", "Please enter valid UID.");
//            return false;
//        }
//    } else if (document.getElementById("rdoreceiptno").checked == true)
//    {
//        if (!Space_Checking(document.getElementById("txtinputtext").value))
//        {
//            setError("txtinputtext", "Space is not allowed.");
//            return false;
//        }
//        if (!DIGIT.test(document.getElementById("txtinputtext").value))
//        {
//            setError("txtinputtext", "Please enter only numbers.");
//            return false;
//        }
//        if (document.getElementById("txtinputtext").value.length !== 17)
//        {
//            setError("txtinputtext", "Please enter valid Receipt Number.");
//            return false;
//        }
//    } else if (document.getElementById("rdopran").checked == true)
//    {
//        if (!Space_Checking(document.getElementById("txtinputtext").value))
//        {
//            setError("txtinputtext", "Space is not allowed.");
//            return false;
//        }
//        if (!DIGIT.test(document.getElementById("txtinputtext").value))
//        {
//            setError("txtinputtext", "Please enter only numbers.");
//            return false;
//        }
//        if (document.getElementById("txtinputtext").value.length !== 12)
//        {
//            setError("txtinputtext", "Please enter valid PRAN.");
//            return false;
//        }
//    } else
//    {
//        setError("rdodefault", "Please Make Selection For Search By.");
//        return false;
//
//    }

    return true;
//    return true;
    //alert(f.name);
}

function setError(id, text)
{
    $("#" + id + "_E").html("");
    $("#" + id + "_E").show();
    if (text == "")
    {
        $("#" + id + "_E").html();
    } else
    {
        $("#" + id + "_E").html("<label style=\"color: red;\"class=\"error\"> " + text + "</label>");
    }
    $("#" + id).focus();
    return false;
}

function getRemoveMsg(id)
{
    if ($("#" + id).val().trim() === "")
    {
        $("#" + id + "_E").html("");
    }
}

function getClearError(id)
{

    $("#" + id + "_E").html("");

}

function getCountchar(id)
{
    if ($("#" + id).val().trim() === "")
    {
        getRemoveMsg(id);
    } else if ($("#" + id).val().trim().length < 3)
    {
        setError(id, "Please enter minimum 3 character or digit");
        return false;
    } else
    {
        $("#" + id + "_E").html("");
    }
    return true;
}

function getPartner(frm)
{
    if ($.trim($("#txttextlike").val()) !== "" && $.trim($("#txttextlike").val()).length >= 3)
    {
        var param = getalldatawithoutFile(frm);
        loadAjaxComboData('craexportutility.fin?cmdAction=getPartnerList', 'cmbpartner', param, true);
        setTimeout(function () {
            $('#cmbpartner').selectpicker('refresh');
        }, 500);
    } else
    {
        $('#cmbpartner').find('option').remove();
        setTimeout(function () {
            $('#cmbpartner').selectpicker('refresh')
        }, 500);
    }
}

function viewpopup(refno)
{
    var param = "refno=" + refno;

    var data = getAjaxData('craexportutility.fin?cmdAction=getStatusDtl', param, false);
    if (data != "")
    {
        var dialog = bootbox.dialog({
            title: 'Application Status Change History for Ref. No : ' + refno,
            message: data,
        });
    }

}

function getclickview(refno)
{
    var param = "refno=" + refno;
    loadAjaxComboData('craexportutility.fin?cmdAction=getViewDtl', 'viewContent', param, false);
    $('#mainDiv').hide();
    $('#viewContent').show();
}

function getCancel()
{
    $('#mainDiv').show();
    $('#viewContent').hide();
}

//function getViewBankProof(proof, refno)
//{
//    var param = "refno=" + refno;
//    if (proof == "bankproof1")
//    {
//        loadAjaxComboData('craexportutility.fin?cmdAction=getBankProofTier1', 'viewContent', param, false);
//    }
//    if (proof == "bankproof2")
//    {
//        loadAjaxComboData('craexportutility.fin?cmdAction=getBankProofTier2', 'viewContent', param, false);
//    }
//    if (proof == "panproof2")
//    {
//        loadAjaxComboData('craexportutility.fin?cmdAction=getPanProofTier2', 'viewContent', param, false);
//    }
//}

function getSaveData(frm)
{
    if (document.getElementById("cmbchangestatus").selectedIndex == 0)
    {
        setError("cmbchangestatus", "Please select status.");
        return false;
    } else
    {
        setError("cmbchangestatus", "");
    }

    if (document.getElementById("cmbchangestatus").value == "7" || document.getElementById("cmbchangestatus").value == "8")
    {
        if (document.getElementById("txtstatusdate").value.trim() == "")
        {
            setError("txtstatusdate", "This field is required.");
            return false;
        }
        if (!checkValidDate("txttodate", "Status Change Date"))
        {
            return false;
        }

        if (document.getElementById("txtpaymentid").value == "")
        {
            setError("txtpaymentid", "This field is required.");
            return false;
        }
        if (!Space_Checking(document.getElementById("txtpaymentid").value))
        {
            setError("txtpaymentid", "Space is not allowed.");
            return false;
        }
        if (!DIGIT.test(document.getElementById("txtpaymentid").value))
        {
            setError("txtpaymentid", "Only numeric values allowed.");
            return false;
        }
        if (!validPaymentid("txtpaymentrefno"))
        {
            return false;
        }
    }

    if (document.getElementById("cmbchangestatus").value == "9" || document.getElementById("cmbchangestatus").value == "10")
    {
        if (document.getElementById("txtstatusdate").value.trim() == "")
        {
            setError("txtstatusdate", "This field is required.");
            return false;
        }
        if (!checkValidDate("txtstatusdate", "Status Change Date"))
        {
            return false;
        }
    }


    if (document.getElementById("remark").value.trim() == "")
    {
        setError("remark", "Please enter reason.");
        return false;
    } else
    {
        setError("remark", "");
    }

    if (document.getElementById("remark").value.trim().length > 500)
    {
        setError("remark", "The Length of Reason should not be greater than 500 charaters.");
        return false;
    } else
    {
        setError("remark", "");
    }

//    loadAjax('craexportutility.fin?cmdAction=getDataSave', 'divSave', param, false);
    var param = getalldatawithoutFile(frm);
    var data = getAjaxData('craexportutility.fin?cmdAction=getDataSave', param, false);

    if (data !== "" && data === "S")
    {
        bootbox.alert({
            message: "Status successfully updated.",
            size: 'small',
            buttons: {
                ok: {
                    className: 'btn btn-primary btn-sm'
                }
            }
        });
        onSubmit(document.CRAExportUtility);
    } else if (data !== "" && data === "F")
    {
        setError("cmbchangestatus", "Unable to change status.");
        return false;
    } else
    {
        $("#divSave").html(data);
    }

    return true;
}

//$("#chkall").click(function () {
//    $('input:checkbox').not(this).prop('checked', this.checked);
//});

function getSelectAll()
{
    if ($('#chkall').prop("checked") === true) {
        $('.checkbox').each(function (i, obj) {
            $(obj).prop("checked", true);
        });
    } else {
        $('.checkbox').each(function (i, obj) {
            $(obj).prop("checked", false);
        });
    }

}

function getSelect()
{
    if ($('.checkbox:checked').length === $('.checkbox').length) {
        $('#chkall').prop('checked', true);
    } else {
        $('#chkall').prop('checked', false);
    }
}

function getResetStatusForm()
{
    setError("cmbchangestatus", "");
    setError("remark", "");
    setError("txtpaymentid", "");
    setError("txtstatusdate", "");
    $('#divpaymentreport').html();
    $('#divSave').html("");
    document.getElementById("ChangeStatusForm").reset();
    document.getElementById("divpayment").style.display = 'none';
    document.getElementById("divpaymentreport").style.display = 'none';
    document.getElementById("divStatusDate").style.display = 'none';
}

function getBack()
{
//    bootbox.confirm("Are you sure want to go back?", function (res) {
//        if (res === true)
//        {
//            document.getElementById("tableDiv").style.display = "none";
//        }
//    });

    bootbox.confirm({
        message: "Are you sure want to go back?",
        size: 'small',
        buttons: {
            confirm: {
                label: 'Yes',
                className: 'btn btn-primary btn-sm'
            },
            cancel: {
                label: 'No',
                className: 'btn btn-info btn-sm'
            }
        },
        callback: function (result) {
            if (result === true)
            {
                document.getElementById("tableDiv").style.display = "none";
                $('#collapseform').collapse('show');
            }
        }
    });
}

function validPaymentid(id)
{
    if ($('#' + id).val().trim() === "")
    {
        setError(id, "This field is required.");
        return false;
    } else if (!Space_Checking($('#' + id).val()))
    {
        setError(id, "Space is not allowed.");
        return false;
    } else if (!DIGIT.test($('#' + id).val()))
    {
        setError(id, "Only numeric values allowed.");
        return false;
    } else
    {
        setError(id, "");
    }
    return true;
}

function showPaymenttext(val)
{
    if (document.getElementById("cmbchangestatus").selectedIndex != 0)
    {
        setError("cmbchangestatus", "");
    }

    if (val === "7" || val === "8")
    {
        document.getElementById("divpayment").style.display = "block";
    } else
    {
        document.getElementById("divpayment").style.display = "none";
    }
    if (val === "7" || val === "8" || val === "9" || val === "10" || val === "11")
    {
        document.getElementById("divStatusDate").style.display = "block";
        setDateValues();
    } else {
        document.getElementById("divStatusDate").style.display = "none";
    }
}

function getPaymentDetails(id)
{
    if (validPaymentid(id))
    {
        var param = getalldatawithoutFile(document.ChangeStatusForm);
        document.getElementById("divpaymentreport").style.display = "block";
        loadAjaxComboData('craexportutility.fin?cmdAction=getReportPaymentDtl', 'divpaymentreport', param, false);
        if (document.getElementById("hdnpaymentflag") != null && document.getElementById("hdnpaymentflag").value == "F")
        {
            $("#divpaymentreport").html("<label style=\"color: red;\"class=\"error\">Invalid Payment Ref No.</label>");
            document.getElementById("txtpaymentid").value = "";
            return false;
        }
        return true;
    }
    return false;
}

function rdoReport(id)
{
    if (id == "rdoregi")
    {
        document.getElementById("cmbstatus").disabled = false;
    } else if (id == "rdopayrec" || id == "rdoactivation") {
        document.getElementById("cmbstatus").disabled = true;
    }
}

//function fnShowHideColumn(obj)
//{
//    var oTable = $('#myTable').dataTable();
//    var opt, bVis;
//    var len = obj.options.length;
//    for (var i = 0; i < len; i++) {
//        opt = obj.options[i];
//        var column = oTable.column(opt.value);
//
//        // Toggle the visibility
//        column.visible(!column.visible());
//    }
//}

function getExportFile()
{
    var frm = document.getElementById("CRAExportUtility");
    if (validateform())
    {
        showLoadingImg("divgeneratefile");
        window.location.href = "craexportutility.fin?cmdAction=getExportData&" + getalldatawithoutFile(frm);
        hideLoadingImg();
    }
    return false;
}

function getGenerateFile()
{
    var chkarray = document.getElementsByName('chkdata');
    var i, isValid = false;
    var refids = "";
    var refcount = 0;
    for (i = 0; i < chkarray.length; i++)
    {
        if (chkarray[i].checked === true)
        {
            if (isValid)
            {
                refids = refids + "-";
            }
            isValid = true;
            refids = refids + chkarray[i].value;
            refcount = refcount + 1;
//            break;
        }
    }
    if (refcount > 20)
    {
//        alert("Can not Generate file for more than 20 Application.");
        bootbox.alert({
            message: "Can not Generate file for more than 20 Application.",
            size: 'small'
        });
    } else if (isValid && refids != "")
    {
        showLoadingImg("divgeneratefile");
        window.location.href = "craexportutility.fin?cmdAction=getGenerateData&refids=" + refids;
        hideLoadingImg();
    } else
    {
//        alert("Please select at least one Application.");
        var ale = bootbox.alert({
            message: "Please select at least one Application.",
            size: 'small',
            buttons: {
                ok: {
                    className: 'btn btn-primary btn-sm'
                }
            }
        });
//        ale.find("btn btn-primary").addClass("btn-sm");
    }
}

function checkValExist(id)
{
    var val = document.getElementById(id).value;
    if (val.trim() == "")
    {
        setError(id, "This field is required.");
    } else {

        setError(id, "");
    }
}
