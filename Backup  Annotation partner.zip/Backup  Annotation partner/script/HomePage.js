function AddPartner(){
   getSynchronousData('userEnter.fin','','loadPartner'); 
}

