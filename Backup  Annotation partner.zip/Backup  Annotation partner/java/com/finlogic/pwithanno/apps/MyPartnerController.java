/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.pwithanno.apps;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyPartnerController {

    @RequestMapping("/index.fin")
    public String showUserForm(ModelMap model) {
        
        String finlibpath = finpack.FinPack.getProperty("finlib_path");
        model.addAttribute("finlib_path", finlibpath);
        return "MyHomePage";
    } 

    @RequestMapping("/userEnter.fin")
    public String redirect()
    {    
        return "Welcome";
    }    
    
}
