
package com.finlogic.pwithanno.apps;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

//@Controller
public class UserWelcome {
//    	@RequestMapping("/userEnter.fin")
//	public String redirect()
//	{
//		return "Welcome";
//	}
}
