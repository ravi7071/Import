
package com.finlogic.pwithanno.service;

import com.finlogic.pwithanno.beans.PartnerInfo;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public interface PartnerService {
    public void add(PartnerInfo partner);
    public PartnerInfo get();
    public List getState() throws ClassNotFoundException, SQLException;
    public List getCity(PartnerInfo bean) throws ClassNotFoundException, SQLException;
    public List getCenter(PartnerInfo bean) throws ClassNotFoundException, SQLException;
    public List getPan() throws ClassNotFoundException, SQLException;
    public Hashtable<String,String> insertPartner(PartnerInfo bean) throws ClassNotFoundException,SQLException;
    public String getGridData(PartnerInfo bean) throws ClassNotFoundException,SQLException;
    public List getPartnerData(String pan) throws ClassNotFoundException,SQLException;
    public Map updatePartner(PartnerInfo bean) throws ClassNotFoundException, SQLException;
    public Map deletePartner(PartnerInfo bean) throws ClassNotFoundException, SQLException;
}
