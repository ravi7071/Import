
package com.finlogic.pwithanno.service;

import com.finlogic.pwithanno.beans.PartnerInfo;
import com.finlogic.pwithanno.business.PartnerDataManager;
import com.finlogic.util.datastructure.JSONParser;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class PartnerServiceImpl implements PartnerService{

    PartnerInfo partner;
    PartnerDataManager manager = new PartnerDataManager();
    @Override
    public void add(PartnerInfo partner) {
        this.partner = partner;
        System.out.println("Partner added successfully");
    }
    
    @Override
    public PartnerInfo get(){
        return this.partner;
    }

    @Override
    public List getState() throws ClassNotFoundException, SQLException{
        return manager.getState();
    }

    @Override
    public List getCity(PartnerInfo bean) throws ClassNotFoundException, SQLException {
        return manager.getCity(bean);
    }

    @Override
    public List getCenter(PartnerInfo bean) throws ClassNotFoundException, SQLException {
        return manager.getCenter(bean);
    }

    @Override
    public Hashtable<String, String> insertPartner(PartnerInfo bean) throws ClassNotFoundException, SQLException {
        return manager.insertPartner(bean);
    }

    @Override
    public List getPan() throws ClassNotFoundException, SQLException {
        return manager.getPan();
    }

    @Override
    public String getGridData(PartnerInfo bean) throws ClassNotFoundException, SQLException {
        JSONParser parser = new JSONParser();
        return parser.parse(manager.getGridData(bean),
                "pan", false, false);
    }

    @Override
    public List getPartnerData(String pan) throws ClassNotFoundException, SQLException {
        return manager.getPartnerData(pan);
    }

    @Override
    public Map updatePartner(PartnerInfo bean) throws ClassNotFoundException, SQLException {
        return manager.updatePartner(bean);
    }

    @Override
    public Map deletePartner(PartnerInfo bean) throws ClassNotFoundException, SQLException {
        return manager.deletePartner(bean);
    }


}
