/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.pwithanno.apps;

import com.finlogic.pwithanno.beans.PartnerInfo;
import com.finlogic.pwithanno.service.PartnerService;
import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/index.fin")
public class MyPartnerController {

    private PartnerService partnerService;
    
    @Autowired
    public void setPartnerService(PartnerService partnerService) {
            this.partnerService = partnerService;
    }    
    
    //@RequestMapping("/index.fin")
    @RequestMapping(method = RequestMethod.GET)
    public String showUserForm(ModelMap model) {
        String finlibpath = finpack.FinPack.getProperty("finlib_path");
        PartnerInfo partner = new PartnerInfo();
        model.addAttribute(partner);
        model.addAttribute("finlib_path", finlibpath);
        return "MyHomePage";
    } 

    @RequestMapping(value="/AddPartner.fin", method = RequestMethod.POST, params = "cmdAction=getMenu")
    public String redirect(Model model,PartnerInfo bean)
    {
        model.addAttribute("process", "stateLoad");
        try {
            model.addAttribute("stateList", partnerService.getState());
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MyPartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "AddPartner";    
    }    
    
    @RequestMapping(value = "/AddPartner.fin",method = RequestMethod.POST,params = "cmdAction=cityLoader")
    public String cityLoader(Model model,PartnerInfo bean){
        model.addAttribute("process", "cityLoad");
        try {
            model.addAttribute("cityList", partnerService.getCity(bean));
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MyPartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "AddPartner";
    }
    
    @RequestMapping(value = "/AddPartner.fin",method = RequestMethod.POST,params = "cmdAction=centerLoader")
    public String centerLoader(Model model,PartnerInfo bean){
        model.addAttribute("process", "centerLoad");
        try {
            model.addAttribute("centerList", partnerService.getCenter(bean));
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MyPartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "AddPartner";
    }
    
    @RequestMapping(value="/AddPartner.fin", method = RequestMethod.POST, params = "cmdAction=insertPartner")
    public String onSubmit(Model model,PartnerInfo bean)
    {  
        try {
            model.addAttribute("msg", partnerService.insertPartner(bean).get("msg"));
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MyPartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "PartnerInsert";
    }
    
    @RequestMapping(value="/EditPartner.fin", method = RequestMethod.POST, params = "cmdAction=editMenu")
    public String loadEdit(Model model,@RequestParam("type") String type){
        model.addAttribute("process", "loadPanNo");
        model.addAttribute("type", type);
        try {
            model.addAttribute("panNo", partnerService.getPan());
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MyPartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "EditMenu";
    }
    
    @RequestMapping(value = "/partner.fin", method = RequestMethod.GET, params = "cmdAction=getfillGridReports")
    public String getfillGridReports(Model model,PartnerInfo bean){
        try {
            model.addAttribute("process", "view");
            //System.out.println("...Selected pan..."+partnerService.getGridData(bean));
            model.addAttribute("json", partnerService.getGridData(bean));
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MyPartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "EditMenu";
    }
    @RequestMapping(value="/partner.fin",method=RequestMethod.POST,params="cmdAction=EditPartner")
    public String editPartner(Model model,PartnerInfo bean,@RequestParam("EditPan") String editPan,@RequestParam("type") String type){
        try {
            Map PartnerMap = (Map)(partnerService.getPartnerData(editPan).get(0));
            model.addAttribute("EditPartner", partnerService.getPartnerData(editPan).get(0));
            model.addAttribute("process", type);
            model.addAttribute("stateList", partnerService.getState());
            bean.setDdlstate(""+PartnerMap.get("state"));
            model.addAttribute("cityList", partnerService.getCity(bean));
            bean.setDdlcity(""+PartnerMap.get("loc"));
            model.addAttribute("centerList", partnerService.getCenter(bean));
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MyPartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "AddPartner";
    }
    @RequestMapping(value="/partner.fin",method=RequestMethod.POST,params="cmdAction=updatePartner")
    public String updatePartner(Model model,PartnerInfo bean){
        try {
            model.addAttribute("msg", partnerService.updatePartner(bean).get("msg"));
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MyPartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "PartnerInsert";
    }
    @RequestMapping(value="/partner.fin",method=RequestMethod.POST,params="cmdAction=deletePartner")
    public String deletePartner(Model model,PartnerInfo bean){
        try {
            model.addAttribute("msg", partnerService.deletePartner(bean).get("msg"));
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MyPartnerController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "PartnerInsert";
    }
    
//    @RequestMapping(value={"/partner.fin","gust.fin"},method=RequestMethod.POST,params="cmdAction=getUtility")
//    public String UtilityPartner(Model model,PartnerInfo bean,@RequestParam(value = "paraOne",required = false) String name){
//        //paramMap.get("paraOne");
//        model.addAttribute("para", name);
//        return "TestPartner";
//    }
    
    @RequestMapping(value={"/partner.fin","gust.fin"},method=RequestMethod.POST,params="cmdAction=getUtility")
    public String UtilityPartner(Model model,PartnerInfo bean,@RequestParam Map paramMap){
        //paramMap.get("paraOne");
        model.addAttribute("para", paramMap);
        return "TestPartner";
    } 

    @RequestMapping()
    public String defaultMethod(Model model,PartnerInfo bean){
        model.addAttribute("para", "Default");
        return "TestPartner";
    }
    
    @RequestMapping("*")
    public String fallBack(Model model){
            return "TestPartner";
    }
}
