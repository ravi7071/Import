
package com.finlogic.pwithanno.apps;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author raj8
 */
@Controller
@RequestMapping("/test.fin")
public class PartnerTestController {
    
    @RequestMapping(value = "/xyz.fin",method = RequestMethod.POST)
    public String UtilityPartner(Model model){
        return "TestPartner";
    }
}
