
package com.finlogic.pwithanno.business;

import com.finlogic.pwithanno.beans.PartnerInfo;
import com.finlogic.util.persistence.SQLUtility;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class PartnerDataManager {
    private static final String CONNECTION_ALIAS = "njindiainvest_offline_dev";
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Date date = new Date();
    String curDate = dateFormat.format(date);    
    public List getState() throws ClassNotFoundException, SQLException{
        SQLUtility sqlUtility = new SQLUtility();
        String sql = "SELECT DISTINCT STATE FROM demo_geolocation;";
        List ls = sqlUtility.getList(CONNECTION_ALIAS, sql);
        return ls;
    }
    public List getCity(PartnerInfo bean) throws ClassNotFoundException, SQLException{
        SQLUtility sqlUtility = new SQLUtility();
        String sql = "SELECT LOCATION_ID,CITY FROM demo_geolocation WHERE "
                + "STATE = '"+bean.getDdlstate()+"'";
        List ls = sqlUtility.getList(CONNECTION_ALIAS, sql);
        return ls;
    }
    public List getCenter(PartnerInfo bean) throws ClassNotFoundException, SQLException{
        SQLUtility sQLUtility = new SQLUtility();
        String sql = "SELECT center_id,center_name FROM demo_njcenter WHERE city IN (SELECT city "
                + "FROM demo_geolocation WHERE location_id="+bean.getDdlcity()+") AND status='Active';";
        List ls = sQLUtility.getList(CONNECTION_ALIAS, sql);
        return ls;
    }
    public Hashtable<String,String> insertPartner(PartnerInfo bean) throws ClassNotFoundException, SQLException{
        SQLUtility sqlUtility = new SQLUtility();
        StringBuilder stbSQL = new StringBuilder();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String curDate = dateFormat.format(date);
        String name = bean.getTxtPName()+" "+bean.getTxtPLastName();
        String panNo = bean.getTxtPPAN();
        Hashtable<String,String> htMsg = new Hashtable<>();
        stbSQL.append("select count(*) as total from njindiainvest.demo_partner "
                + "where pan='"+bean.getTxtPPAN()+"' and is_rejected='no';");
        
        int panExsist = sqlUtility.getInt(CONNECTION_ALIAS, stbSQL.toString());
        if(panExsist==0){
            stbSQL.setLength(0);
            stbSQL.append("insert into njindiainvest.demo_partner");
            stbSQL.append("(partner_name,mobile,emailid,gender,dob,pan,state,"
                    + "city,pincode,center_id,spouse_name,pan_scan_copy,"
                    + "existing_house_hold,registration_date,is_rejected,status)");
            stbSQL.append(" values");
            stbSQL.append("('"+name+"','"+bean.getTxtPMobile()+"','"+bean.getTxtPEmail()+"',"
                            + "'"+bean.getRadiogender()+"',str_to_date('"+bean.getDtdob()+"','%d-%m-%Y'),'"+panNo+"',"
                            + "'"+bean.getDdlstate()+"',(select city from njindiainvest.demo_geolocation where location_id="+bean.getDdlcity()+"),'"+bean.getTxtPin()+"',"
                            + "'"+bean.getDdlcenter()+"','"+bean.getTxtPSpouse()+"','xyz.jpg','"+bean.getTxtPHH()+"','"+curDate+"','no','requested');");
            sqlUtility.persist(CONNECTION_ALIAS, stbSQL.toString());
            htMsg.put("msg", "Thank you for showing interest. Our representative will contact you shortly");
        }
        else{
            htMsg.put("msg", "You are already registered with NJ India Invest "
                        + "Pvt. Ltd. For any queries call on Toll Free number 1800-2000-155");
        }
        return htMsg;
    }
    public List getPan() throws ClassNotFoundException, SQLException{
        SQLUtility sQLUtility = new SQLUtility();
        String sql = "SELECT DISTINCT pan FROM njindiainvest.demo_partner;";
        List ls = sQLUtility.getList(CONNECTION_ALIAS, sql);
        return ls;
    }
    public List getGridData(PartnerInfo bean) throws ClassNotFoundException,
            SQLException {
        StringBuilder query = new StringBuilder();
        SQLUtility sqlUtility = new SQLUtility();
        query.append("select partner_name,mobile,emailid, gender,pan,p.state,p.city,"
                + "p.center_id,"
                + "if(spouse_name='' or spouse_name is null, '--',spouse_name) as spouse_name,"
                + "dob,p.pincode,existing_house_hold,"
                + "concat(\"<a href='javascript:onEdit(\\\"\",pan,\"\\\")'>EDIT</a>\"),\n"
                + "concat(\"<a href='javascript:onDelete(\\\"\",pan,\"\\\")'>DELETE</a>\")\n"
                + "from njindiainvest.demo_partner as p,njindiainvest.demo_njcenter as c "
                + "where p.center_id=c.center_id ");
        if(bean.getDdleditpan()!=null && !bean.getDdleditpan().equals("all")){
            query.append(" and pan='"+bean.getDdleditpan()+"' ");
        }
        List ls = sqlUtility.getList(CONNECTION_ALIAS, query.toString());
        return ls;
    }
    public List getPartnerData(String Pan) throws ClassNotFoundException, SQLException{
        SQLUtility sqlUtility = new SQLUtility();
        StringBuilder query = new StringBuilder();
        query.append("select substring_index(partner_name,' ',1) as 'fName',"
                + "substring_index(partner_name,' ',-1) as 'lName',"
                + "mobile,emailid,gender,DATE_FORMAT(dob,'%d-%m-%Y') as dob,p.state as state,"
                + "p.city as city,g.location_id as loc,pincode,c.center_id as c_id,c.center_name,if(spouse_name='null' or spouse_name is null, '',spouse_name) as spouse_name"
                + ",existing_house_hold,pan from "
                + "njindiainvest.demo_partner as p,njindiainvest.demo_njcenter as c,njindiainvest.demo_geolocation g "
                + "where pan ='"+Pan+"' and p.center_id=c.center_id and g.city=p.city and g.state=p.state");
        List ls = sqlUtility.getList(CONNECTION_ALIAS, query.toString());
        return ls;
    }
    public Map updatePartner(PartnerInfo bean) throws ClassNotFoundException, SQLException{
        SQLUtility sqlUtility = new SQLUtility();
        Map<String,String>  map= new HashMap<String,String>();
        
        StringBuilder stbSQL = new StringBuilder();
        String name = bean.getTxtPName()+" "+bean.getTxtPLastName();
        stbSQL.append("Update njindiainvest.demo_partner ");
        stbSQL.append("set ");
        stbSQL.append("partner_name='"+name+"',");
        stbSQL.append("mobile='"+bean.getTxtPMobile()+"',");
        stbSQL.append("gender='"+bean.getRadiogender()+"',");
        stbSQL.append("dob=str_to_date('"+bean.getDtdob()+"','%d-%m-%Y'),");
        stbSQL.append("state='"+bean.getDdlstate()+"',");
        stbSQL.append("city=(select city from njindiainvest.demo_geolocation where location_id = "+bean.getDdlcity()+"),");
        stbSQL.append("pincode='"+bean.getTxtPin()+"',");
        stbSQL.append("center_id='"+bean.getDdlcenter()+"',");
        stbSQL.append("emailid='"+bean.getTxtPEmail()+"',");
        stbSQL.append("spouse_name='"+bean.getTxtPSpouse()+"',");
        stbSQL.append("existing_house_hold='"+bean.getTxtPHH()+"',");
        stbSQL.append("updation_date='"+curDate+"' ");
        stbSQL.append(" where pan='"+bean.getTxtPPAN()+"';");
        sqlUtility.persist(CONNECTION_ALIAS, stbSQL.toString());
        map.put("msg", "Partner Updated successfully");
        return map;
    }
    public Map deletePartner(PartnerInfo bean) throws ClassNotFoundException, SQLException{
        SQLUtility sqlUtility = new SQLUtility();
        Map<String,String>  map= new HashMap<String,String>();
        StringBuilder stbSQL = new StringBuilder();
        stbSQL.setLength(0);
        stbSQL.append("delete from njindiainvest.demo_partner where ");
        stbSQL.append(" pan='"+bean.getTxtPPAN()+"';");
        sqlUtility.persist(CONNECTION_ALIAS, stbSQL.toString());
        map.put("msg", "Partner deleted successfully");
        return map;
    }    
}
