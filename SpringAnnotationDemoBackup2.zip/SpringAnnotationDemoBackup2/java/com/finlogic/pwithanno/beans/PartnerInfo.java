
package com.finlogic.pwithanno.beans;



public class PartnerInfo {
    
    private String txtPName;
    private String txtPLastName;
    private String txtPMobile;
    private String txtPEmail;
    private String radiogender;
    private String dtdob;
    private String ddlstate;
    private String ddlcity;
    private String txtPin;
    private String ddlcenter;
    private String txtPPAN;
    private String txtPSpouse;
    private String txtPHH;
    private String ddleditpan;
    //MultipartFile pImage;

    public String getTxtPName() {
        return txtPName;
    }

    public void setTxtPName(String txtPName) {
        this.txtPName = txtPName;
    }

    public String getTxtPLastName() {
        return txtPLastName;
    }

    public void setTxtPLastName(String txtPLastName) {
        this.txtPLastName = txtPLastName;
    }

    public String getTxtPMobile() {
        return txtPMobile;
    }

    public void setTxtPMobile(String txtPMobile) {
        this.txtPMobile = txtPMobile;
    }

    public String getTxtPEmail() {
        return txtPEmail;
    }

    public void setTxtPEmail(String txtPEmail) {
        this.txtPEmail = txtPEmail;
    }

    public String getRadiogender() {
        return radiogender;
    }

    public void setRadiogender(String radiogender) {
        this.radiogender = radiogender;
    }

    public String getDtdob() {
        return dtdob;
    }

    public void setDtdob(String dtdob) {
        this.dtdob = dtdob;
    }

    public String getDdlstate() {
        return ddlstate;
    }

    public void setDdlstate(String ddlstate) {
        this.ddlstate = ddlstate;
    }

    public String getDdlcity() {
        return ddlcity;
    }

    public void setDdlcity(String ddlcity) {
        this.ddlcity = ddlcity;
    }

    public String getTxtPin() {
        return txtPin;
    }

    public void setTxtPin(String txtPin) {
        this.txtPin = txtPin;
    }

    public String getDdlcenter() {
        return ddlcenter;
    }

    public void setDdlcenter(String ddlcenter) {
        this.ddlcenter = ddlcenter;
    }

    public String getTxtPPAN() {
        return txtPPAN;
    }

    public void setTxtPPAN(String txtPPAN) {
        this.txtPPAN = txtPPAN;
    }

    public String getTxtPSpouse() {
        return txtPSpouse;
    }

    public void setTxtPSpouse(String txtPSpouse) {
        this.txtPSpouse = txtPSpouse;
    }

    public String getTxtPHH() {
        return txtPHH;
    }

    public void setTxtPHH(String txtPHH) {
        this.txtPHH = txtPHH;
    }

    public String getDdleditpan() {
        return ddleditpan;
    }

    public void setDdleditpan(String ddleditpan) {
        this.ddleditpan = ddleditpan;
    }

    @Override
    public String toString() {
        return "PartnerInfo{" + "txtPName=" + txtPName + ", txtPLastName=" + txtPLastName + ", txtPMobile=" + txtPMobile + ", txtPEmail=" + txtPEmail + ", radiogender=" + radiogender + ", dtdob=" + dtdob + ", ddlstate=" + ddlstate + ", ddlcity=" + ddlcity + ", txtPin=" + txtPin + ", ddlcenter=" + ddlcenter + ", txtPPAN=" + txtPPAN + ", txtPSpouse=" + txtPSpouse + ", txtPHH=" + txtPHH + ", ddleditpan=" + ddleditpan + '}';
    }

    
}
