/* global mygrid */
var today = new Date();
var year = today.getFullYear() - 19;
year = "12-12-"+year;
function DhtmlshowReport(rptfor){
    showDetailGridReports(rptfor);
    reArrangeColumns();    
}
function reArrangeColumns()
{
    var col = document.getElementById("col_cmb1");
    var col2 = document.getElementById("col_cmb2");

    if (col2 !== null && col2.length > 0)
    {
        var val = "";
        for (var i = 0; i < col.length; i++)
        {
            val = col[i].value;
            mygrid.setColumnHidden(parseInt(val), true);
        }
    }
}
function showDetailGridReports(rptfor)
{
    var param = getFormData(document.partnerForm);
    mygrid = new dhtmlXGridObject('gridbox');
    mygrid.setImagesPath(getFinLibPath() + "dhtmlxSuite/dhtmlxGrid/codebase/imgs/");

    mygrid.setHeader("<b>Partner Name</b>,<b>Mobile</b>,<b>Email ID</b>,<b>Gender</b>,\n\
               <b>PAN No</b>,<b>State</b>,<b>City</b>,<b>NJ Center</b>,<b>Spouse Name</b>,\n\
               <b>DOB</b>,<b>Pin Code</b>,<b>Existing HouseHold</b>,<b>Edit</b>,\n\
               <b>Delete</b>");
    mygrid.setInitWidths("220,80,210,50,100,90,150,80,80,80,80,40,80,80");
    mygrid.setColAlign("center,left,center,left,center,center,center,center,\n\
                        center,center,center,center,center,center");

    mygrid.setColSorting("na,na,na,na,na,na,na,na,na,na,na,na,na,na");
    mygrid.setColTypes("ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,link,link");
    mygrid.attachHeader(",#numeric_filter,,#select_filter,#select_filter,#select_filter,,,,#select_filter,#select_filter,#select_filter,,");
    

    mygrid.enableAutoWidth(true);
    mygrid.enableAutoHeight(true);
    mygrid.enableMultiline(true);
    mygrid.setDateFormat("%D-%m-%y");
    
    mygrid.enableDragAndDrop(false);
    mygrid.enableColumnMove(true);
    mygrid.enableMultiselect(true);
    mygrid.enableColSpan(true);
    mygrid.setSkin("dhx_web");
    document.getElementById("pagingArea").innerHTML = "";
    document.getElementById("recinfoArea").innerHTML = "";
    mygrid.enablePaging(true, 10, 10, "pagingArea", true, "recinfoArea");
    mygrid.setPagingWTMode(true, true, true, [10, 20, 50]);
    mygrid.setPagingSkin("toolbar", "dhx_web");  
    mygrid.init();

    if (rptfor === "edit")
    {
        mygrid.setColumnHidden(13, true);//hiding delete column if report is of type edit
        //loadAjaxComboData('index.fin/partner.fin?cmdAction=getfillGridReports', 'mygrid', param, false);
        mygrid.load('index.fin/partner.fin?cmdAction=getfillGridReports&'+param, hideLoadingImg(), "json");
        console.log(mygrid);
    }
    if(rptfor == "delete"){
        mygrid.setColumnHidden(12, true);//hiding edit column if report is of type delete
        mygrid.load('index.fin/partner.fin?cmdAction=getfillGridReports&'+param, hideLoadingImg(), "json");        
    }
    
}
function onEdit(panNo){
    //alert("Editing pan no "+panNo);
    document.getElementById('basicReportDiv').style.display = "none";
    var oform = document.getElementById("partnerForm");
    var param = getFormData(oform);    
    getSynchronousData('index.fin/partner.fin?cmdAction=EditPartner&type=edit&EditPan='+panNo, param, 'loadPartner');
    loadDatePicker("dtdob","","","01-01-1945",year);
}
function onDelete(panNo){
    document.getElementById('basicReportDiv').style.display = "none";
    var oform = document.getElementById("partnerForm");
    var param = getFormData(oform);    
    getSynchronousData('index.fin/partner.fin?cmdAction=EditPartner&type=delete&EditPan='+panNo, param, 'loadPartner');
    loadDatePicker("dtdob","","","01-01-1945",year);
}

