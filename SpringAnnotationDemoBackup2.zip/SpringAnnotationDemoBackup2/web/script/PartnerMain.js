var today = new Date();
var year = today.getFullYear() - 19;
year = "12-12-"+year;
function AddPartner(){
    //getSynchronousData('AddPartner.fin?cmdAction=getMenu','','loadPartner');
    document.getElementById('basicReportDiv').style.display = "none";
    var param = getFormData(document.partnerForm);
    loadAjaxComboData('index.fin/AddPartner.fin?cmdAction=getMenu', 'loadPartner', param, false);
    loadDatePicker("dtdob","","","01-01-1945",year);   
}
function loadCity(){//to load city when state is changes
    var oform = document.getElementById("partnerForm");
    var param = getFormData(oform);
    getSynchronousData('index.fin/AddPartner.fin?cmdAction=cityLoader', param, 'ddlcity');
    //loadAjaxComboData('AddPartner.fin?cmdAction=cityLoader', 'ddlcity', param, false);
    loadComboNew('ddlcity');
}
function loadNJCenter(){
    var oform = document.getElementById("partnerForm");
    var param = getFormData(oform);
    getSynchronousData('index.fin/AddPartner.fin?cmdAction=centerLoader',param,'ddlcenter');
}
function EditPartner(){
    document.getElementById('basicReportDiv').style.display = "block";
    var oform = document.getElementById("partnerForm");
    var param = getFormData(oform);
    getSynchronousData('index.fin/EditPartner.fin?cmdAction=editMenu&type=edit',param,'loadPartner');
    DhtmlshowReport('edit');
}
function DeletePartner(){
    document.getElementById('basicReportDiv').style.display = "block";
    var oform = document.getElementById("partnerForm");
    var param = getFormData(oform);
    getSynchronousData('index.fin/EditPartner.fin?cmdAction=editMenu&type=delete',param,'loadPartner');
    DhtmlshowReport('delete');
}
function update_data(){
    var oform = document.getElementById("partnerForm");
    var param = getFormData(oform);
    if (validate_form()){
        getSynchronousData('index.fin/partner.fin?cmdAction=updatePartner',param,'loadPartner');
    }
    else{
        return false;
    }
    
}
function delete_data(){
    var oform = document.getElementById("partnerForm");
    var param = getFormData(oform);
    if(validate_form()){
        getSynchronousData('index.fin/partner.fin?cmdAction=deletePartner',param,'loadPartner');
    }
    else{
        return false;
    }
}
function getUtility(){
    document.getElementById('basicReportDiv').style.display = "none";
    var oform = document.getElementById("partnerForm");
    var param = getFormData(oform);    
    getSynchronousData('index.fin/partner.fin?cmdAction=getUtility&paraOne=Raj&paraTwo=Tandel',param,'loadPartner');
    //getSynchronousData('index.fin/partner.fin?cmdAction=getUtility',param,'loadPartner');
}
function getTest(){
    document.getElementById('basicReportDiv').style.display = "none";
    var oform = document.getElementById("partnerForm");
    var param = getFormData(oform);    
    getSynchronousData('index.fin/gust.fin?cmdAction=getUtility&paraOne=Gust&paraTwo=user',param,'loadPartner');
    //getSynchronousData('index.fin',param,'loadPartner');//For default method in controller
    //getSynchronousData('index.fin/xyz.fin',param,'loadPartner'); // fallbackmethod from controller called
    //getSynchronousData('test.fin/xyz.fin',param,'loadPartner'); // fallbackmethod from controller called
}
function loadAjaxComboData(url, divid, data, sync) {
    //showLoadingImg(divid);
    $.ajax({
        url: url,
        data: data,
        type: 'POST',
        async: sync,
        success: function (data) {
            //hideLoadingImg();
            if (data.indexOf("Welcome to My Partner") > 0)
            {
                window.location = '';
            } else
            {
                $("#" + divid).html(data);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            //hideLoadingImg();
        }
    });
}
function validate_data(){
    //var param = getFormData(document.partnerForm);
    //getSynchronousData('AddPartner.fin?cmdAction=insertPartner','param','loadPartner'); 
    var formObj = $("#partnerForm").get(0);
    var formData = new FormData(formObj);
    if (validate_form())//If form is validate insert data
    {
        loadAjaxComboData('index.fin/AddPartner.fin?cmdAction=insertPartner', 'loadPartner', getalldatawithoutFile(formObj), false);
    } else {
        return false;
    }
}
function validate_form() {

    var oform = document.getElementById("partnerForm");
    //Validating fields for add partner
    if(document.getElementById("ddlcenter").options.length===1){
        alert("No nearest center found, please select different state");
        return false;
    }
    if(!validate_ind(oform,"txtPName","First Name",true)||!validate_ind(oform,"txtPLastName","Last Name",true)
            ||!validate_only_number(oform,"txtPMobile","Mobile",true)||!validate_phonno(oform,"txtPMobile","Mobile",true)
            ||!validate_email(oform,"txtPEmail","Email",true)||!validate_dropdown(oform,"ddlstate","State",true)
            ||!validate_dropdown(oform,"ddlcity","City",true)||!validate_only_number(oform,"txtPin","Pin-code",true)
            ||!validate_pincode(oform,"txtPin","Pin-code",true)||!validate_dropdown(oform,"ddlcenter","NJ center",true)
            ||!validate_panno(oform,"txtPPAN","PAN no",true)||!validate_only_number(oform,"txtPHH","House hold",true)){
        return false;
    }
    else{
        return true;
    }
}
