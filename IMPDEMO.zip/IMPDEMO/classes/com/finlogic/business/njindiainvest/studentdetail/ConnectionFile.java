/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.business.njindiainvest.studentdetail;

/**
 *
 * @author njuser
 */
public class ConnectionFile {
    
    public String getDB_user(String Alias)
    {
        if(Alias.equalsIgnoreCase("amfimonitor_online"))
        {
            return "jdbc:mysql://192.168.3.240:3306/AMFIMONITOR?auto_reconnect=true";
        }    
        return null;
    }
    
    public String getDB_name(String Alias)
    {
        if(Alias.equalsIgnoreCase("amfimonitor_online"))
        {
            return "amfimonitor";
        }
        return null;
    }
    
    public String getDB_pass(String Alias)
    {
        if(Alias.equalsIgnoreCase("amfimonitor_online"))
        {
            return "amfimonitor123";
        }
        return null;
    }
}
