/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.apps.njindiainvest.studentdetail;

import com.finlogic.business.njindiainvest.studentdetail.Debug;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

/**
 *
 * @author Pratik Sanghadia
 */
public class studentDetailController extends MultiActionController{
    
    private final studentDetailService service = new studentDetailService();
    private final studentDetaildataManager dataManager = new studentDetaildataManager();
    
    public List getDegree() throws ClassNotFoundException, SQLException
    {
        return service.getDegree();
    }
    
     public ModelAndView getMenu(HttpServletRequest req, HttpServletResponse res) {

        ModelAndView mv = new ModelAndView("partner/Main");
        String finlib_path;
        finlib_path = finpack.FinPack.getProperty("finlib_path");
        mv.addObject("finlib_path", finlib_path);

        return mv;
    }

    public ModelAndView addLoader(HttpServletRequest req, HttpServletResponse res) {

        ModelAndView mv = new ModelAndView("partner/add");

        mv.addObject("partner_name", req.getParameter("txtpname"));
        mv.addObject("partner_emailid", req.getParameter("txtpemail"));
        mv.addObject("partner_dob", req.getParameter("dtdob"));
        mv.addObject("partner_city", req.getParameter("txtpcity"));
        mv.addObject("partner_state", req.getParameter("txtpstate"));
        mv.addObject("partner_pincode", req.getParameter("txtppincode"));
        mv.addObject("partner_pan", req.getParameter("txtppan"));
        mv.addObject("partner_household", req.getParameter("txtphousehold"));
        return mv;
    }

    public ModelAndView editLoader(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView("partner/edit");
        return mv;
    }

   

    public ModelAndView deleteLoader(final HttpServletRequest req, final HttpServletResponse res) {
        ModelAndView mv = new ModelAndView("partner/delete");

        return mv;
    }

    public ModelAndView ViewLoader(final HttpServletRequest req, final HttpServletResponse res)
    {
        ModelAndView mv = new ModelAndView();
        mv.addObject("process", "getmenu");
        mv.setViewName("studentdetail/View");
        return mv;
    }
    
    public ModelAndView ReportLoader(final HttpServletRequest req, final HttpServletResponse res)
    {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("studentdetail/Report");
        return mv;
    }
    
    public ModelAndView getfillGridReoprts(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        ModelAndView mv = new ModelAndView();
        mv.addObject("process", "getreportGrid");
        mv.addObject("json",service.getReportData(formBean));
        mv.setViewName("studentdetail/View");
        return mv;
    }
    
    public ModelAndView degreeLoader(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        ModelAndView mv = new ModelAndView();
        
        String degree = formBean.getDropdegree();
        String year = formBean.getDropyear();
        
        List lst = new ArrayList();
        lst = service.getYear(degree);
        mv.addObject("year",lst);
        mv.addObject("masterTask","yearload");
        mv.setViewName("studentdetail/Ajax");
        return mv;
    }
    
    public ModelAndView DeleteLoaderMain(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        ModelAndView mv = new ModelAndView();
        mv.addObject("show", service.DeleteLoaderMain(formBean));
        mv.addObject("degree",getDegree());
        mv.setViewName("studentdetail/DeleteMain");
        return mv;
    }
    
    public ModelAndView EditLoaderMain(final HttpServletRequest req, final HttpServletResponse res, studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        ModelAndView mv = new ModelAndView();
        mv.addObject("show",service.EditMainLoader(formBean));
        mv.addObject("degree", getDegree());
        mv.setViewName("studentdetail/EditMain");
        return mv;
    }
    
    public ModelAndView delete_student(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        ModelAndView mv = new ModelAndView();
        mv.addObject("masterTask","delete");
        mv.addObject("DBoperation",service.delete_student(formBean));
        mv.setViewName("studentdetail/Ajax");
        return mv;
    }
    
    public ModelAndView update_student(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        
        String fileName = null;
        String enroll="";
        
        try
        {
            enroll = req.getParameter("primekey");
            fileName = enroll+"_photo.jpg";
            
            Debug.appendLogFile("Upload query file name = "+ fileName);  
        }
        catch(Exception ex)
        {
            Debug.appendLogFile("Exception in File Upload-> " + ex.getMessage());
        }
        
        ModelAndView mv = new ModelAndView();
        mv.addObject("masterTask", "update");
        mv.addObject("DBoperation",service.update_student(formBean, fileName));
        mv.setViewName("studentdetail/Ajax");
        return mv;
    }
    
    
    public void photoUpload(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean)
    {
        String fileName = null;
        
        try
        {
            //String status;
            String enroll="";
            String destiPath = finpack.FinPack.getProperty("tomcat1_path") + "/webapps/StudentMVC/photo";
            File file = new File(destiPath);
            
            
            MultipartFile Mfile = formBean.getFile(); 
            String destinationFileName = Mfile.getOriginalFilename();
            
            if(req.getParameter("primekey")!=null && !req.getParameter("primekey").equalsIgnoreCase(""))
            {
                enroll = req.getParameter("primekey");
                formBean.setEnroll_no(req.getParameter("primekey"));
                
                Debug.appendLogFile("uploadFile = "+ formBean.getFile().getOriginalFilename());
                
                fileName = enroll+"_photo.jpg";
                
                if(destinationFileName != null)
                {
                    File newFile = new File(destiPath + "/" + fileName);
                    if (!file.exists())
                    {
                        file.mkdir();
                    }
                
                    if (Mfile.getSize() > 0)
                    {
                        Mfile.transferTo(newFile);
                        //status = "true";
                    }
                    
                }
                Debug.appendLogFile("enroll no hidden = "+ enroll);  
                Debug.appendLogFile("Prime Key hidden = "+ req.getParameter("primekey"));  
            }
            else
            {
                int eno;
                
                eno = dataManager.getEnroll();
                eno+=1;
                
                fileName = eno+"_photo.jpg";
                File newFile = new File(destiPath + "/" + fileName);
            
                if (!file.exists())
                {
                    file.mkdir();
                }
                
                if (Mfile.getSize() > 0)
                {
                    Mfile.transferTo(newFile);
                    //status = "true";
                }
            
                Debug.appendLogFile("uploadFile Add = "+ formBean.getFile().getOriginalFilename());
                Debug.appendLogFile("enroll no Add  = "+ eno);
                Debug.appendLogFile("File Name === "+ fileName);
                Debug.appendLogFile("Prime Key hidden = "+ req.getParameter("primekey"));
            }
             
        }
        catch(Exception ex)
        {
            Debug.appendLogFile("Exception in File Upload-> " + ex.getMessage());
        }
        //return fileName;
    }
    
    public ModelAndView insert_student(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        String fileName = null;
       
        try
        {
            int eno;
            eno = dataManager.getEnroll();
            eno+=1;
            
            fileName = eno+"_photo.jpg";
//          
        }
        catch(Exception ex)
        {
            Debug.appendLogFile("Exception in File Upload-> " + ex.getMessage());
        }
        
        ModelAndView mv = new ModelAndView();
        mv.addObject("masterTask", "add");
        mv.addObject("DBoperation", service.insert_student(formBean, fileName));
        mv.setViewName("studentdetail/Ajax");
        return mv;
        
    }
    
//    public void generateExcel(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean)
//    {
//    
//        try
//        {
//            ExcelParam epObj = new ExcelParam();
//            Map paramMap = new HashMap();
//            if (formBean.getReportName() != null && formBean.getReportName() != "")
//            {
//                paramMap.put(ExcelParam.EXCELParameter.FILENAME.getExcelParam(), formBean.getReportName());
//            }
//            else
//            {
//                paramMap.put(ExcelParam.EXCELParameter.FILENAME.getExcelParam(), "YourXlsReport");
//            }
//            paramMap.put(ExcelParam.EXCELParameter.GRIDXML.getExcelParam(), req.getParameter("grid_xml"));
//            paramMap.put(ExcelParam.EXCELParameter.HTTPRESPONSE.getExcelParam(), res);
//            epObj.generateExcel(paramMap);
//        }
//        catch(Exception ex)
//        {
//            finutils.errorhandler.ErrorHandler.PrintInFile(ex, req);
//        }
//    }
//    
//    public void generatePDF(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean) throws Throwable
//    {
//        try
//        {
//            PDFParam ppObj = new PDFParam();
//            Map paramMap = new HashMap();
//            String reportTitle = formBean.getReportName();
//            paramMap.put(PDFParam.PDFParameter.FILENAME.getPdfParam(), formBean.getReportName());
//            paramMap.put(PDFParam.PDFParameter.DISPLAYMODE.getPdfParam(), formBean.getDisplayMode());
//            paramMap.put(PDFParam.PDFParameter.REPORTTITLE.getPdfParam(), reportTitle);
//            paramMap.put(PDFParam.PDFParameter.GRIDXML.getPdfParam(), req.getParameter("grid_xml") == null ? "" : req.getParameter("grid_xml"));
//            paramMap.put(PDFParam.PDFParameter.HTTPRESPONSE.getPdfParam(), res);
//            ppObj.generatePDF(paramMap);
//        }
//        catch(Exception ex)
//        {
//            finutils.errorhandler.ErrorHandler.PrintInFile(ex, req);
//        }
//    }
    
    
    public void GenerateServerExcelSheet(final HttpServletRequest req,final HttpServletResponse res,final studentDetailformBean formbean) throws ClassNotFoundException, SQLException, IOException
    {
        service.generateServerSideExcelForDetailReport(req, res, formbean);
    }
    
    public ModelAndView getRptExportFile(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean)
    {
        ModelAndView mv = new ModelAndView();
        try
        {
            String tomcatpath = finpack.FinPack.getProperty("tomcat1_path");
            String fileName;
            fileName= tomcatpath+"/webapps/StudentMVC/WEB-INF/jrxml/studentdetail.jrxml";
            JasperReport jasperreport = JasperCompileManager.compileReport(fileName);
            String outFileName = tomcatpath + "/webapps/Firstmvc/" + formBean.getReportName() + "." + formBean.getRadioreport().toLowerCase(Locale.getDefault());
            JRBeanCollectionDataSource dataSource;
            dataSource = new JRBeanCollectionDataSource(service.getExportData(formBean));
            
            JasperPrint print = JasperFillManager.fillReport(jasperreport, null, dataSource);
            JRExporter exporter = null;
            
            if (formBean.getRadioreport().equals("PDF"))
            {
                exporter = new JRPdfExporter();
            }
            if (formBean.getRadioreport().equals("XLS"))
            {
                exporter = new JRXlsExporter();
            }
            if(formBean.getRadioreport().equals("PDF") || formBean.getRadioreport().equals("XLS"))
            {
                exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, outFileName);
                exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
                
                if(formBean.getRadioreport().equals("XLS"))
                {
                    exporter.setParameter(JRXlsExporterParameter.IS_COLLAPSE_ROW_SPAN, Boolean.TRUE);
                    exporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE);
                    exporter.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE);
                    exporter.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.FALSE);
                    exporter.setParameter(JRXlsExporterParameter.IS_IGNORE_GRAPHICS, Boolean.FALSE);
                    exporter.setParameter(JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.FALSE); 
                }
                
                exporter.exportReport();
            }
            
            ServletOutputStream out1 = res.getOutputStream();
            if(formBean.getRadioreport().equals("PDF"))
            {
                res.setContentType("application/pdf");
            }
            if(formBean.getRadioreport().equals("XLS"))
            {
                res.setContentType("application/vnd.ms-excel");
            }
            res.setHeader("Content-disposition", "attachment; filename=\"" + formBean.getReportName() + "." + formBean.getRadioreport().toLowerCase(Locale.getDefault()));
            BufferedInputStream bis = null;
            BufferedOutputStream bos = null;
            
            try
            {
                bis = new BufferedInputStream(new FileInputStream(outFileName));
                bos = new BufferedOutputStream(out1);
                
                byte[] buff = new byte[2048];
                int bytesRead;
                
                while(-1 != (bytesRead = bis.read(buff,0, buff.length)))
                {
                    bos.write(buff, 0, bytesRead);
                }
                
            }
            catch(Exception ex)
            {
                throw new ServletException(ex);
            }
            finally
            {
                if(bis != null)
                    bis.close();
                
                if(bos != null)
                    bos.close();
            }
            out1.close();
            mv.setViewName("studentdetail/AddAjax");
        }
        catch(Exception e)
        {
            finutils.errorhandler.ErrorHandler.PrintInFile(e, req);
            return mv;
        }
        return null;
    }
}
