/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.apps.njindiainvest.studentdetail;

import com.finlogic.util.datastructure.JSONParser;
import com.finlogic.util.excel.ExcelConfigurationBean;
import com.finlogic.util.excel.ServerSideExcelGeneration;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author njuser
 */
public class studentDetailService {
    
    private final studentDetaildataManager dataManager = new studentDetaildataManager();
    
    public List getDegree() throws ClassNotFoundException, SQLException
    {
        List lst = new ArrayList();
        lst = dataManager.getDegree();
        return lst;
    }
    
    public List getYear(String degree) throws ClassNotFoundException, SQLException
    {
        List lst = new ArrayList();
        lst = dataManager.getYear(degree);
        return lst;
    }
    
    public List getExportData(studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        return dataManager.getGridData(formBean);
    }
    
    public void generateServerSideExcelForDetailReport(final HttpServletRequest req, final HttpServletResponse res, final studentDetailformBean formBean) throws ClassNotFoundException, SQLException, IOException
    {
        ExcelConfigurationBean excelObj = new ExcelConfigurationBean();
        List lst = new ArrayList();
        lst = dataManager.getGridData(formBean);
        ServerSideExcelGeneration sseObj = new ServerSideExcelGeneration();
        
        excelObj.setColumnsId("enroll_no,name,address,city,email,dob,gender,degree,year,hobby");
        
        List<String> attachHeader = new ArrayList<String>();
        attachHeader.add("Student Detail,#cspan,#cspan,#cspan,#cspan,#cspan,#cspan,#cspan,#cspan,#cspan");
        attachHeader.add("Enrollment No, Name, Address, City, Email, Date of Birth, Gender, Degree, Year, Hobby");
        excelObj.setAttachColumns(attachHeader);
        
        excelObj.setColumnType("rotxt,rotxt,rotxt,rotxt,rotxt,rotxt,rotxt,rotxt,rotxt,rotxt");
        excelObj.setColAlign("center,center,center,center,center,center,center,center,center,center");
        excelObj.setRowWidth("80,100,150,100,100,80,60,80,100,150");
        excelObj.setSplitCount(50000);
        

        excelObj.setResponse(res);
        sseObj.generateSSExcel(lst, excelObj);
    }
    
    public String getReportData(studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        List lst = new ArrayList();
        JSONParser jsonParser = new JSONParser();
        lst = dataManager.getGridData(formBean);
        return jsonParser.parse(lst, "enroll_no",true, false);
    }
    
    public List DeleteLoaderMain(studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        return dataManager.DeleteLoaderMain(formBean);
    }
    
    public int insert_student(studentDetailformBean formBean, String fileName) throws ClassNotFoundException, SQLException
    {
        return dataManager.insert_student(formBean, fileName);
    }
    
    public List EditMainLoader(studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        return dataManager.EditMainLoader(formBean);
    }
    
    public int delete_student(studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        return dataManager.delete_student(formBean);
    }
    
    public int update_student(studentDetailformBean formBean, String fileName) throws ClassNotFoundException, SQLException
    {
        return dataManager.update_student(formBean, fileName);
    }
    
}
