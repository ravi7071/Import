
package com.finlogic.mynjpartner.apps;

import com.finlogic.mynjpartner.business.PartnerDataManager;
import com.finlogic.mynjpartner.business.PartnerEntityBean;
import com.finlogic.util.datastructure.JSONParser;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class PartnerService {
    PartnerDataManager dataManager = new PartnerDataManager();
    
    public List getState() throws ClassNotFoundException, SQLException {
        return dataManager.getState();
    }
    public List getCity(PartnerFormBean formBean) throws ClassNotFoundException, SQLException {
        return dataManager.getCity(convertBean(formBean));
    }
    public List getCenter(PartnerFormBean formBean){        
        return dataManager.getCenter(convertBean(formBean));
    }
    public Map insertPartner(PartnerFormBean formBean) throws ClassNotFoundException, SQLException{
        return dataManager.insertPartner(insertBean(formBean));
    }
    public Map updatePartner(PartnerFormBean formBean) throws ClassNotFoundException, SQLException{
        return dataManager.updatePartner(insertBean(formBean));
    }
    public String deletePartner(PartnerFormBean formBean) throws ClassNotFoundException, SQLException{
        PartnerEntityBean partnerEntityBean = new PartnerEntityBean();
        partnerEntityBean.setTxtPPAN(formBean.getTxtPPAN());
        return dataManager.deletePartner(partnerEntityBean);
    }
    public List getPan() throws ClassNotFoundException, SQLException{
        return dataManager.getPan();
    }
    public List getUtilityPan() throws ClassNotFoundException, SQLException{
        return dataManager.getUtilityPan();
    }    
    public String getGridData(PartnerFormBean formBean) throws ClassNotFoundException,
            SQLException {
        JSONParser parser = new JSONParser();

        return parser.parse(dataManager.getGridData(convertEditBean(formBean)),
                "pan", false, false);
    }
    public Map updatePartnerStatus(PartnerFormBean formBean) throws ClassNotFoundException, SQLException{
        PartnerEntityBean partnerEntityBean = new PartnerEntityBean();
        partnerEntityBean.setTxtPPAN(formBean.getTxtPPAN());
        partnerEntityBean.setDdlChangeStatus(formBean.getDdlChangeStatus());
        return dataManager.updatePartnerStatus(partnerEntityBean);
    }    
    public String getGridDataforView() throws ClassNotFoundException,
            SQLException {
        JSONParser parser = new JSONParser();

        return parser.parse(dataManager.getGridDataforView(),
                "Total", false, false);
    }
    public String getGridDataForSelection(PartnerFormBean formBean) throws ClassNotFoundException,
            SQLException {
        JSONParser parser = new JSONParser();
        PartnerEntityBean partnerEntityBean = new PartnerEntityBean();
        partnerEntityBean.setDdlcenter(formBean.getDdlcenter());
        return parser.parse(dataManager.getGridDataForSelection(partnerEntityBean),
                "partner_name", false, false);
    }
    public List getPartnerUtility(PartnerFormBean formBean) throws ClassNotFoundException, SQLException{
        PartnerEntityBean partnerEntityBean = new PartnerEntityBean();
        partnerEntityBean.setTxtPPAN(formBean.getTxtPPAN());
        return dataManager.getPartnerUtility(partnerEntityBean);
    }    
    Map getPartnerData(PartnerFormBean formBean) throws ClassNotFoundException, SQLException {
        PartnerEntityBean partnerEntityBean = new PartnerEntityBean();
        partnerEntityBean.setTxtPPAN(formBean.getTxtPPAN());
        return dataManager.getPartnerDetailFromPAN(partnerEntityBean);
    }    
    public PartnerEntityBean convertBean(PartnerFormBean formBean) {
        PartnerEntityBean partnerEntityBean = new PartnerEntityBean();
        partnerEntityBean.setDdlcity(formBean.getDdlcity());
        partnerEntityBean.setDdlstate(formBean.getDdlstate());
        return partnerEntityBean;
    }
    public PartnerEntityBean convertEditBean(PartnerFormBean formBean) {
        PartnerEntityBean partnerEntityBean = new PartnerEntityBean();
        partnerEntityBean.setDdleditpan(formBean.getDdleditpan());
        partnerEntityBean.setTxtPin(formBean.getTxtPin());
        return partnerEntityBean;
    }    
    public PartnerEntityBean insertBean(PartnerFormBean formBean) {

        PartnerEntityBean partnerEntityBean = new PartnerEntityBean();
        partnerEntityBean.setDdlcity(formBean.getDdlcity());
        partnerEntityBean.setDdlstate(formBean.getDdlstate());
        partnerEntityBean.setDdlcenter(formBean.getDdlcenter());
        partnerEntityBean.setDtdob(formBean.getDtdob());
        partnerEntityBean.setRadiogender(formBean.getRadiogender());
        partnerEntityBean.setTxtPSpouse(formBean.getTxtPSpouse());
        partnerEntityBean.setTxtPEmail(formBean.getTxtPEmail());
        partnerEntityBean.setTxtPPAN(formBean.getTxtPPAN());
        partnerEntityBean.setTxtPin(formBean.getTxtPin());
        partnerEntityBean.setTxtPHH(Integer.parseInt(formBean.getTxtPHH()));
        partnerEntityBean.setTxtPLastName(formBean.getTxtPLastName());
        partnerEntityBean.setTxtPMobile(formBean.getTxtPMobile());
        partnerEntityBean.setTxtPName(formBean.getTxtPName());
        return partnerEntityBean;
    }  
}
