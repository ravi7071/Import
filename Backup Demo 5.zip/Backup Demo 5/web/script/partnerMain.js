var today = new Date();
var year = today.getFullYear() - 19;
year = "12-12-"+year;
function AddPartner(){//Called for loading add partner module
    document.getElementById('basicReportDiv').style.display = "none";
    var param = getFormData(document.partnerForm);
    getSynchronousData('partner.fin?cmdAction=addMenu','param','loadPartner');
    loadComboNew('ddlcity');
    loadDatePicker("dtdob","73","","01-01-1945",year);
    
}
function loadCity(){//to load city when state is changes
    var oform = document.getElementById("partnerForm");
    var params = getFormData(oform);
    getSynchronousData('partner.fin?cmdAction=cityLoader', params, 'ddlcity');
    loadComboNew('ddlcity');
}
function loadNJCenter(){//to load NEAREST NJ center when city is changed
    var oform = document.getElementById("partnerForm");
    var params = getFormData(oform);
    getSynchronousData('partner.fin?cmdAction=centerLoader', params, 'ddlcenter');
    loadComboNew('ddlcenter');
}
function EditPartner(){//To load edit partner module
    document.getElementById('basicReportDiv').style.display = "block";
    var param = getFormData(document.partnerForm);
    getSynchronousData('partner.fin?cmdAction=editMenu&type=edit','param','loadPartner');
    DhtmlshowReport('edit');
}
function DeletePartner(){//To load delete partner module
    document.getElementById('basicReportDiv').style.display = "block";
    var param = getFormData(document.partnerForm);
    getSynchronousData('partner.fin?cmdAction=editMenu&type=delete','param','loadPartner');
    DhtmlshowReport('delete');
}
function ViewPartner(){//TO load view partne module
    document.getElementById('basicReportDiv').style.display = "none";
    getSynchronousData('partner.fin?cmdAction=viewPartner','','loadPartner');
    getPartner();
}
function PartnerUtility(){//To load partner utility module
    document.getElementById('basicReportDiv').style.display = "block";
    var param = getFormData(document.partnerForm);
    getSynchronousData('partner.fin?cmdAction=partnerUtility&type=utility','param','loadPartner');
    DhtmlshowReport('utility');
}
function PartnerReport(){
    document.getElementById('basicReportDiv').style.display = "none";
    var param = getFormData(document.partnerForm);
    getSynchronousData('partner.fin?cmdAction=partnerReport','param','loadPartner');
}
